import os
from PIL import Image, ImageEnhance, ImageFilter

SRC_DIR = r"C:\Users\Admin\.gemini\antigravity-ide\brain\261f2d11-26d0-479d-bb25-895fdbe4923b\.user_uploaded"
OUT_DIRS = [
    r"c:\BTLJAVA\CoffeLand_JavaSwing_Full\CoffeLand_JavaSwing\src\main\resources\images\products",
    r"c:\BTLJAVA\CoffeLand_JavaSwing_Full\CoffeLand_JavaSwing\target\classes\images\products"
]

for d in OUT_DIRS:
    os.makedirs(d, exist_ok=True)

# Mapping: source image -> output filename
# Based on user-approved mapping:
#   - Nước cam vắt         -> nuoc_cam.png        (media_1789008184755.jpg / media_1789010472110.jpg)
#   - Nước dưa hấu         -> nuoc_duahau.png     (media_1789008272131.jpg)
#   - Nước ép táo cà rốt   -> nuoc_tao_carot.png  (media_1789008184784.jpg / media_1789010472131.jpg)
#   - Nước ổi hồng chanh leo -> nuoc_oi_hong.png   (media_1789008184743.jpg / media_1789010472137.jpg)
#   - Soda việt quất        -> soda_vietquat.png   (media_1789008184777.jpg / media_1789010472160.jpg)
#   - Chanh tuyết bạc hà    -> chanh_tuyet.png     (media_1789008184724.jpg / media_1789010472203.jpg)

IMAGE_MAP = {
    "media_1789008184755.jpg": "nuoc_cam.png",
    "media_1789008272131.jpg": "nuoc_duahau.png",
    "media_1789008184784.jpg": "nuoc_tao_carot.png",
    "media_1789008184743.jpg": "nuoc_oi_hong.png",
    "media_1789008184777.jpg": "soda_vietquat.png",
    "media_1789008184724.jpg": "chanh_tuyet.png",
}

TARGET_W = 240
TARGET_H = 160

def process_and_save(src_path, filename):
    img = Image.open(src_path)
    
    # Convert to RGB if needed
    if img.mode in ("RGBA", "P"):
        rgb_img = Image.new("RGB", img.size, (255, 255, 255))
        if img.mode == "RGBA":
            rgb_img.paste(img, mask=img.split()[3])
        else:
            rgb_img.paste(img)
        img = rgb_img
    elif img.mode != "RGB":
        img = img.convert("RGB")
    
    # Subtle color & contrast enhancement for appetizing look
    enhancer_color = ImageEnhance.Color(img)
    enhanced = enhancer_color.enhance(1.08)
    enhancer_contrast = ImageEnhance.Contrast(enhanced)
    enhanced = enhancer_contrast.enhance(1.05)
    
    # Smart crop to fit 240x160 (3:2 ratio) - center crop
    src_w, src_h = enhanced.size
    target_ratio = TARGET_W / TARGET_H  # 1.5
    src_ratio = src_w / src_h
    
    if src_ratio > target_ratio:
        # Source is wider, crop sides
        new_w = int(src_h * target_ratio)
        left = (src_w - new_w) // 2
        enhanced = enhanced.crop((left, 0, left + new_w, src_h))
    else:
        # Source is taller, crop top/bottom (focus on center-upper area for drinks)
        new_h = int(src_w / target_ratio)
        top = max(0, (src_h - new_h) // 3)  # Slightly biased toward top for drink photos
        enhanced = enhanced.crop((0, top, src_w, top + new_h))
    
    # Resize with high-quality Lanczos filter
    resized = enhanced.resize((TARGET_W, TARGET_H), Image.Resampling.LANCZOS)
    
    # Sharpen for crisp look
    resized = resized.filter(ImageFilter.UnsharpMask(radius=1.2, percent=110, threshold=3))
    
    for d in OUT_DIRS:
        out_path = os.path.join(d, filename)
        resized.save(out_path, format="PNG", optimize=True)
    print(f"[OK] Saved: {filename} ({TARGET_W}x{TARGET_H}) from {os.path.basename(src_path)}")

# Process all juice images
for src_name, out_name in IMAGE_MAP.items():
    src_path = os.path.join(SRC_DIR, src_name)
    if os.path.exists(src_path):
        process_and_save(src_path, out_name)
    else:
        print(f"[MISS] Not found: {src_name}")

print("\n[DONE] All juice menu images replaced successfully!")

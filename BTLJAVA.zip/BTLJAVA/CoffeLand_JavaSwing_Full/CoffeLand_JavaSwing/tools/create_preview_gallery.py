import os
from PIL import Image, ImageDraw, ImageFont

art_dir = r'C:\Users\Admin\.gemini\antigravity-ide\brain\a88d2fee-dd3a-451b-b240-f4ceeff888a8'
prod_dir = r'c:\BTLJAVA\CoffeLand_JavaSwing_Full\CoffeLand_JavaSwing\src\main\resources\images\products'

items = [
    # Image 1 (Bánh - Kem)
    ('panna_cotta.png', 'Panna Cotta dâu (32k)'),
    ('mousse_chanhleo.png', 'Passion cheese (32k)'),
    ('matcha_mousse.png', 'Matcha mousse (32k)'),
    ('tiramisu.png', 'Tiramisu Ý (38k)'),
    ('kem_dua.png', 'Kem dừa (30k)'),
    ('kem_dau.png', 'Kem dâu (30k)'),
    # Image 2 (Italian / Frappuccino / VN)
    ('cf_den.png', 'Cà phê đen VN (25k)'),
    ('espresso.png', 'Espresso Ý (30k)'),
    ('cappuccino.png', 'Cappuccino (45k)'),
    ('latte.png', 'Vanilla Latte (48k)'),
    ('mocha.png', 'Mocha Socola (49k)'),
    ('caramel_macchiato.png', 'Caramel Macchiato (52k)'),
    ('frap_hazelnut.png', 'Frap Hazelnut (45k)'),
    ('frap_caramel.png', 'Frap Caramel (45k)'),
    ('frap_tiramisu.png', 'Frap Tiramisu (48k)'),
    ('frap_chocolate.png', 'Frap Chocolate (45k)'),
    # Image 3 (Grid Specialty)
    ('hazelnut_macchiato.png', 'Hazelnut Macchiato (38k)'),
    ('ristretto_bianco.png', 'Ristretto Bianco (35k)'),
    ('asian_dolce_latte.png', 'Asian Dolce Latte (40k)'),
    ('americano.png', 'Americano đá (35k)'),
    ('cf_sua.png', 'Cà phê sữa đá (30k)'),
    ('espresso_con_panna.png', 'Espresso Con Panna (35k)'),
    # Image 4 (Specialty Drinks)
    ('espresso_nutella.png', 'Espresso Nutella (45k)'),
    ('cafe_irlandes.png', 'Café Irlandês (48k)'),
    ('ice_cappuccino.png', 'Ice Cappuccino (45k)'),
    ('cafe_shake.png', 'Café Shake (48k)'),
    ('chocolate_quente.png', 'Socola nóng Ý (35k)'),
    ('cha_gelado.png', 'Trà đen đá (30k)'),
    # Image 5 (Winter Menu Hunufa)
    ('tra_hoa_nhai.png', 'Trà hoa nhài (35k)'),
    ('tra_chanh_gung.png', 'Trà chanh gừng (35k)'),
    ('tra_tao_que.png', 'Trà táo quế (40k)'),
    ('cacao_nong.png', 'Cacao nóng (35k)'),
    ('socola_bac_ha.png', 'Socola bạc hà (38k)'),
    ('socola_cam_que.png', 'Socola cam quế (40k)'),
    ('tra_tao_mat_ong.png', 'Trà táo mật ong (35k)'),
    ('nuoc_cam_que.png', 'Nước cam quế (38k)'),
    ('nuoc_le_gung.png', 'Nước ép lê gừng (38k)')
]

cols = 6
rows = (len(items) + cols - 1) // cols
cell_w, cell_h = 200, 160
thumb_w, thumb_h = 180, 120

gallery = Image.new('RGB', (cols * cell_w + 20, rows * cell_h + 30), color=(25, 25, 28))
draw = ImageDraw.Draw(gallery)

for idx, (img_name, label) in enumerate(items):
    r = idx // cols
    c = idx % cols
    x = 15 + c * cell_w
    y = 15 + r * cell_h

    fp = os.path.join(prod_dir, img_name)
    if os.path.exists(fp):
        im = Image.open(fp).resize((thumb_w, thumb_h), Image.Resampling.LANCZOS)
        gallery.paste(im, (x + (cell_w - thumb_w)//2, y))

    draw.text((x + 10, y + thumb_h + 8), label, fill=(230, 230, 230))

out_path = os.path.join(art_dir, 'menu_cropped_gallery.png')
gallery.save(out_path, format='PNG')
print('Gallery saved successfully to:', out_path)

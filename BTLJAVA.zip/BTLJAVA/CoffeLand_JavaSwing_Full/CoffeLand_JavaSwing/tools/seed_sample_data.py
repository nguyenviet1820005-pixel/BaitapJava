import mysql.connector
from datetime import datetime, timedelta

def seed():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="coffeeland"
    )
    cursor = conn.cursor()

    # Lấy mapping mã sản phẩm -> id thực tế
    cursor.execute("SELECT code, id FROM products")
    p_map = {row[0]: row[1] for row in cursor.fetchall()}
    print(f"Loaded {len(p_map)} products from database.")

    # 1. Kiểm tra stock_receipts
    cursor.execute("SELECT COUNT(*) FROM stock_receipts")
    receipt_count = cursor.fetchone()[0]
    if receipt_count == 0:
        print("Seeding stock receipts...")
        now = datetime.now()
        receipts = [
            (1, 'PN260908001', 1, 'Nhập hạt cà phê Arabica/Robusta và sữa tươi đầu tuần', now - timedelta(days=5)),
            (2, 'PN260910002', 1, 'Nhập trà trái cây, bột matcha và siro hoa quả', now - timedelta(days=3)),
            (3, 'PN260912003', 2, 'Nhập bánh tươi Tiramisu, Croissant và đồ ăn vặt', now - timedelta(days=1))
        ]
        cursor.executemany(
            "INSERT INTO stock_receipts(id, code, employee_id, note, created_at) VALUES (%s, %s, %s, %s, %s)",
            receipts
        )

        raw_receipt_items = [
            # receipt_id, product_code, quantity, cost_price
            (1, 'CF001', 100, 15000),
            (1, 'CF002', 100, 18000),
            (1, 'CF003', 80, 20000),
            (1, 'CF009', 70, 22000),
            (2, 'TR001', 60, 25000),
            (2, 'TR006', 80, 24000),
            (2, 'TR008', 60, 26000),
            (2, 'DX001', 50, 30000),
            (3, 'BN001', 30, 26000),
            (3, 'BN005', 40, 20000),
            (3, 'BN007', 100, 9000)
        ]
        receipt_items = []
        for r_id, p_code, qty, cost in raw_receipt_items:
            if p_code in p_map:
                receipt_items.append((r_id, p_map[p_code], qty, cost))

        cursor.executemany(
            "INSERT INTO stock_receipt_items(receipt_id, product_id, quantity, cost_price) VALUES (%s, %s, %s, %s)",
            receipt_items
        )
        print("Stock receipts seeded successfully!")
    else:
        print(f"Stock receipts already have {receipt_count} rows.")

    # 2. Kiểm tra invoices
    cursor.execute("SELECT COUNT(*) FROM invoices")
    invoice_count = cursor.fetchone()[0]
    if invoice_count == 0:
        print("Seeding invoices...")
        now = datetime.now()
        invoices = [
            (1, 'HD260907001', 1, 2, 2, now - timedelta(days=6), 105000, 0, 105000, 'Tiền mặt'),
            (2, 'HD260908002', 2, 1, 3, now - timedelta(days=5), 142000, 10000, 132000, 'Chuyển khoản QR'),
            (3, 'HD260909003', 3, 2, 6, now - timedelta(days=4), 93000, 0, 93000, 'Tiền mặt'),
            (4, 'HD260910004', 1, 1, 10, now - timedelta(days=3), 185000, 15000, 170000, 'Chuyển khoản QR'),
            (5, 'HD260911005', 2, 2, 4, now - timedelta(days=2), 127000, 0, 127000, 'Thẻ ATM / Visa'),
            (6, 'HD260912006', 1, 2, 2, now - timedelta(days=1), 215000, 20000, 195000, 'Tiền mặt'),
            (7, 'HD260913007', 3, 1, 5, now - timedelta(hours=3), 125000, 0, 125000, 'Chuyển khoản QR'),
            (8, 'HD260913008', 1, 2, 1, now - timedelta(hours=1), 77000, 0, 77000, 'Tiền mặt')
        ]
        cursor.executemany(
            "INSERT INTO invoices(id, code, customer_id, employee_id, table_id, created_at, subtotal, discount, total, payment_method) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            invoices
        )

        raw_invoice_items = [
            (1, 'CF001', 1, 25000, 25000, 'Ít đường'),
            (1, 'CF003', 1, 35000, 35000, 'Nhiều sữa'),
            (1, 'BN001', 1, 45000, 45000, ''),
            (2, 'TR001', 2, 45000, 90000, 'Ít đá 50%'),
            (2, 'CF008', 1, 52000, 52000, 'Nóng'),
            (3, 'CF009', 1, 38000, 38000, 'Ít đá'),
            (3, 'DX001', 1, 55000, 55000, 'Thêm kem'),
            (4, 'TR006', 2, 42000, 84000, '70% đường, 100% đá'),
            (4, 'DX005', 1, 50000, 50000, ''),
            (4, 'BN005', 1, 35000, 35000, 'Hâm nóng'),
            (4, 'BN007', 1, 16000, 16000, ''),
            (5, 'CF011', 1, 48000, 48000, ''),
            (5, 'CF007', 1, 48000, 48000, 'Không đường'),
            (5, 'BN011', 1, 31000, 31000, ''),
            (6, 'CF009', 2, 38000, 76000, 'Đậm vị muối'),
            (6, 'TR008', 2, 46000, 92000, 'Trân châu trắng'),
            (6, 'BN002', 1, 47000, 47000, ''),
            (7, 'CF002', 1, 30000, 30000, 'Ít ngọt'),
            (7, 'CF003', 1, 35000, 35000, ''),
            (7, 'DX001', 1, 60000, 60000, 'Nhiều whipping cream'),
            (8, 'CF001', 1, 25000, 25000, 'Đá riêng'),
            (8, 'CF008', 1, 52000, 52000, 'Nóng')
        ]
        invoice_items = []
        for inv_id, p_code, qty, unit_price, line_total, note in raw_invoice_items:
            if p_code in p_map:
                invoice_items.append((inv_id, p_map[p_code], qty, unit_price, line_total, note))

        cursor.executemany(
            "INSERT INTO invoice_items(invoice_id, product_id, quantity, unit_price, line_total, note) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            invoice_items
        )
        print("Invoices seeded successfully!")
    else:
        print(f"Invoices already have {invoice_count} rows.")

    conn.commit()
    conn.close()
    print("Database seeding completed successfully!")

if __name__ == "__main__":
    seed()

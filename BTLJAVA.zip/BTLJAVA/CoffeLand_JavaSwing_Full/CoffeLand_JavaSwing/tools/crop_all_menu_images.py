import os
from PIL import Image, ImageEnhance, ImageFilter, ImageDraw

SRC_DIR = r"C:\Users\Admin\.gemini\antigravity-ide\brain\a88d2fee-dd3a-451b-b240-f4ceeff888a8\.user_uploaded"
OUT_DIRS = [
    r"c:\BTLJAVA\CoffeLand_JavaSwing_Full\CoffeLand_JavaSwing\src\main\resources\images\products",
    r"c:\BTLJAVA\CoffeLand_JavaSwing_Full\CoffeLand_JavaSwing\target\classes\images\products"
]

for d in OUT_DIRS:
    os.makedirs(d, exist_ok=True)

# Image paths
im1_path = os.path.join(SRC_DIR, "media_1788827372908.jpg")
im2_path = os.path.join(SRC_DIR, "media_1788827372952.jpg")
im3_path = os.path.join(SRC_DIR, "media_1788827373019.jpg")
im4_path = os.path.join(SRC_DIR, "media_1788827373037.jpg")
im5_path = os.path.join(SRC_DIR, "media_1788827584812.png")

im1 = Image.open(im1_path)
im2 = Image.open(im2_path)
im3 = Image.open(im3_path)
im4 = Image.open(im4_path)
im5 = Image.open(im5_path)

def process_and_save(cropped_img, filename, target_w=240, target_h=160, sharpen=True):
    # Convert to RGB if RGBA/P
    if cropped_img.mode in ("RGBA", "P"):
        rgb_img = Image.new("RGB", cropped_img.size, (255, 255, 255))
        if cropped_img.mode == "RGBA":
            rgb_img.paste(cropped_img, mask=cropped_img.split()[3])
        else:
            rgb_img.paste(cropped_img)
        cropped_img = rgb_img

    # Subtle contrast & color enhancement for appetizing food photo look
    enhancer_color = ImageEnhance.Color(cropped_img)
    enhanced = enhancer_color.enhance(1.08)
    enhancer_contrast = ImageEnhance.Contrast(enhanced)
    enhanced = enhancer_contrast.enhance(1.05)

    # Resize with high-quality Lanczos filter
    resized = enhanced.resize((target_w, target_h), Image.Resampling.LANCZOS)
    if sharpen:
        resized = resized.filter(ImageFilter.UnsharpMask(radius=1.2, percent=110, threshold=3))

    for d in OUT_DIRS:
        out_path = os.path.join(d, filename)
        resized.save(out_path, format="PNG", optimize=True)
    print(f"Saved: {filename} ({target_w}x{target_h})")

# ==========================================
# 1. BÁNH & KEM (Image 1: media_1788827372908.jpg)
# ==========================================
process_and_save(im1.crop((58, 57, 153, 146)), "panna_cotta.png")
process_and_save(im1.crop((175, 57, 273, 146)), "mousse_chanhleo.png")
process_and_save(im1.crop((58, 187, 153, 276)), "matcha_mousse.png")
process_and_save(im1.crop((175, 187, 273, 276)), "tiramisu.png")
process_and_save(im1.crop((58, 318, 153, 407)), "kem_dua.png")
process_and_save(im1.crop((175, 318, 273, 407)), "kem_dau.png")

# ==========================================
# 2. CÀ PHÊ VIỆT NAM & ITALIAN & FRAPPUCCINO (Image 2: media_1788827372952.jpg)
# ==========================================
# Vietnamese coffee cup with roasted beans
process_and_save(im2.crop((32, 350, 205, 520)), "cf_den.png")
# Italian coffee items
process_and_save(im2.crop((515, 165, 638, 258)), "espresso.png")
process_and_save(im2.crop((414, 318, 486, 385)), "cappuccino.png")
process_and_save(im2.crop((568, 318, 642, 385)), "latte.png")
process_and_save(im2.crop((418, 428, 492, 495)), "mocha.png")
process_and_save(im2.crop((575, 418, 645, 498)), "caramel_macchiato.png")

# Frappuccinos (crop tightly around cup)
def make_frap_card(cup_crop, target_w=240, target_h=160):
    bg_color = (48, 25, 15) # Warm dark coffee theme matching original menu
    canvas = Image.new("RGB", (target_w, target_h), bg_color)
    h = target_h - 10
    w = int(cup_crop.width * (h / cup_crop.height))
    resized = cup_crop.resize((w, h), Image.Resampling.LANCZOS)
    canvas.paste(resized, ((target_w - w) // 2, 5))
    return canvas

process_and_save(make_frap_card(im2.crop((928, 140, 978, 248))), "frap_hazelnut.png")
process_and_save(make_frap_card(im2.crop((698, 208, 760, 318))), "frap_caramel.png")
process_and_save(make_frap_card(im2.crop((928, 280, 978, 388))), "frap_tiramisu.png")
process_and_save(make_frap_card(im2.crop((698, 358, 762, 468))), "frap_chocolate.png")

# ==========================================
# 3. SPECIALTY COFFEE GRID (Image 3: media_1788827373019.jpg)
# ==========================================
process_and_save(im3.crop((13, 16, 116, 119)), "hazelnut_macchiato.png")
process_and_save(im3.crop((167, 16, 271, 119)), "ristretto_bianco.png")
process_and_save(im3.crop((320, 16, 422, 119)), "asian_dolce_latte.png")
process_and_save(im3.crop((473, 16, 575, 119)), "americano.png")
process_and_save(im3.crop((14, 153, 117, 255)), "cf_sua.png")
process_and_save(im3.crop((167, 153, 269, 255)), "mocha_cream.png")
process_and_save(im3.crop((473, 300, 576, 403)), "espresso_con_panna.png")

# ==========================================
# 4. SIGNATURE BEVERAGES (Image 4: media_1788827373037.jpg)
# ==========================================
# Nutella cup (pure cup without side text)
process_and_save(im4.crop((3, 310, 150, 485)), "espresso_nutella.png")
process_and_save(im4.crop((190, 412, 300, 585)), "cafe_irlandes.png")
process_and_save(im4.crop((495, 28, 585, 180)), "ice_cappuccino.png")
process_and_save(im4.crop((315, 205, 510, 395)), "cafe_shake.png")
process_and_save(im4.crop((28, 465, 110, 585)), "chocolate_quente.png")
process_and_save(im4.crop((315, 440, 398, 585)), "cha_gelado.png")

# ==========================================
# 5. WINTER WARM DRINKS & TEAS (Image 5: media_1788827584812.png)
# ==========================================
def make_circular_card(circle_crop, target_w=240, target_h=160):
    mask = Image.new("L", circle_crop.size, 0)
    draw_mask = ImageDraw.Draw(mask)
    draw_mask.ellipse((2, 2, circle_crop.width - 3, circle_crop.height - 3), fill=255)
    
    clean_circle = Image.new("RGB", circle_crop.size, (255, 255, 255))
    clean_circle.paste(circle_crop, mask=mask)
    
    canvas = Image.new("RGB", (target_w, target_h), (255, 255, 255))
    h = target_h - 10
    w = h
    resized = clean_circle.resize((w, h), Image.Resampling.LANCZOS)
    canvas.paste(resized, ((target_w - w) // 2, 5))
    return canvas

# Row 1 (Teas)
process_and_save(make_circular_card(im5.crop((74, 240, 150, 318))), "tra_hoa_nhai.png")
process_and_save(make_circular_card(im5.crop((195, 240, 271, 318))), "tra_chanh_gung.png")
process_and_save(make_circular_card(im5.crop((316, 240, 392, 318))), "tra_tao_que.png")

# Row 2 (Chocolate & Cocoa)
process_and_save(make_circular_card(im5.crop((74, 380, 150, 458))), "cacao_nong.png")
process_and_save(make_circular_card(im5.crop((195, 380, 271, 458))), "socola_bac_ha.png")
process_and_save(make_circular_card(im5.crop((316, 380, 392, 458))), "socola_cam_que.png")

# Row 3 (Winter Juices & Honey Tea)
process_and_save(make_circular_card(im5.crop((74, 520, 150, 598))), "tra_tao_mat_ong.png")
process_and_save(make_circular_card(im5.crop((195, 520, 271, 598))), "nuoc_cam_que.png")
process_and_save(make_circular_card(im5.crop((316, 520, 392, 598))), "nuoc_le_gung.png")

print("All menu images successfully cropped and saved!")

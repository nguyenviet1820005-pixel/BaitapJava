CREATE DATABASE IF NOT EXISTS coffeeland CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE coffeeland;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS stock_receipt_items;
DROP TABLE IF EXISTS stock_receipts;
DROP TABLE IF EXISTS invoice_items;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS dining_tables;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS employees;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(120),
    position VARCHAR(50) DEFAULT 'Nhân viên',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    role ENUM('ADMIN','STAFF') NOT NULL DEFAULT 'STAFF',
    employee_id INT NULL,
    active BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_users_employee FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    category_id INT NOT NULL,
    unit VARCHAR(30) DEFAULT 'Ly',
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    image VARCHAR(255) DEFAULT 'default_drink.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dining_tables (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(50) NOT NULL,
    area VARCHAR(50) DEFAULT 'Tầng 1',
    status ENUM('EMPTY','OCCUPIED','RESERVED') NOT NULL DEFAULT 'EMPTY',
    active BOOLEAN DEFAULT TRUE
);

CREATE TABLE invoices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(30) NOT NULL UNIQUE,
    customer_id INT NULL,
    employee_id INT NULL,
    table_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(12,2) NOT NULL,
    discount DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL,
    payment_method VARCHAR(30) DEFAULT 'Tiền mặt',
    CONSTRAINT fk_invoices_customer FOREIGN KEY (customer_id) REFERENCES customers(id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_invoices_employee FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_invoices_table FOREIGN KEY (table_id) REFERENCES dining_tables(id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE invoice_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    line_total DECIMAL(12,2) NOT NULL,
    note VARCHAR(255) NULL DEFAULT '',
    CONSTRAINT fk_invoice_items_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_invoice_items_product FOREIGN KEY (product_id) REFERENCES products(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE stock_receipts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(30) NOT NULL UNIQUE,
    employee_id INT NULL,
    note VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_receipts_employee FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE stock_receipt_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    receipt_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    cost_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_receipt_items_receipt FOREIGN KEY (receipt_id) REFERENCES stock_receipts(id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_receipt_items_product FOREIGN KEY (product_id) REFERENCES products(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- DỮ LIỆU MẪU (SAMPLE DATA)
INSERT INTO employees(code, full_name, phone, email, position) VALUES
('NV001','Nguyễn Văn An','0901000001','an@coffeeland.local','Quản lý'),
('NV002','Trần Minh Hoa','0901000002','hoa@coffeeland.local','Thu ngân');

-- admin123 / nv123 (SHA-256)
INSERT INTO users(username, password_hash, role, employee_id) VALUES
('admin','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','ADMIN',1),
('nhanvien','70ae1c421727d20eb63385ae5763f2d798dc4c0bd66663bdf0f13e7512f5767f','STAFF',2);

-- DANH MỤC SẢN PHẨM (CATEGORIES)
INSERT INTO categories(id, name, description) VALUES
(1, 'Cà phê', 'Cà phê truyền thống Việt Nam và cà phê máy Espresso Ý'),
(2, 'Trà & Đồ uống ấm', 'Trà trái cây nhiệt đới, trà sữa đậm vị và các loại trà nóng mùa đông'),
(3, 'Đá xay & Sinh tố', 'Thức uống Frappuccino đá xay béo ngậy và sinh tố trái cây tươi mát'),
(4, 'Nước ép & Giải khát', 'Nước ép trái cây tươi nguyên chất, soda sảng khoái và nước ép nóng'),
(5, 'Bánh ngọt & Tráng miệng', 'Bánh ngọt kiểu Âu, Mousse, Panna Cotta, Kem ly và đồ ăn vặt'),
(6, 'Sữa chua', 'Sữa chua dẻo thơm ngon kết hợp trái cây và topping'),
(7, 'Cacao & Socola nóng', 'Thức uống Cacao nóng nguyên chất, Socola bạc hà Marshmallow và Socola Ý');

-- MENU ĐỒ UỐNG & MÓN ĂN PHONG PHÚ (77 MÓN THỰC TẾ)
INSERT INTO products(code, name, category_id, unit, price, stock, active, image) VALUES
-- 1. CÀ PHÊ (19 món)
('CF001', 'Cà phê đen đá', 1, 'Ly', 25000, 60, 1, 'cf_den.png'),
('CF002', 'Cà phê sữa đá', 1, 'Ly', 30000, 60, 1, 'cf_sua.png'),
('CF003', 'Bạc xỉu Sài Gòn', 1, 'Ly', 35000, 50, 1, 'bac_xiu.png'),
('CF004', 'Espresso Đậm Đà', 1, 'Ly', 30000, 45, 1, 'espresso.png'),
('CF005', 'Americano Đá', 1, 'Ly', 35000, 50, 1, 'americano.png'),
('CF006', 'Cappuccino Bọt Sữa', 1, 'Ly', 45000, 40, 1, 'cappuccino.png'),
('CF007', 'Latte Vanilla', 1, 'Ly', 48000, 40, 1, 'latte.png'),
('CF008', 'Caramel Macchiato', 1, 'Ly', 52000, 35, 1, 'caramel_macchiato.png'),
('CF009', 'Cà phê muối xứ Huế', 1, 'Ly', 38000, 55, 1, 'cf_muoi.png'),
('CF010', 'Cà phê cốt dừa', 1, 'Ly', 45000, 40, 1, 'cf_cot_dua.png'),
('CF011', 'Cold Brew Cam Sả', 1, 'Ly', 48000, 30, 1, 'cold_brew.png'),
('CF012', 'Mocha Socola Đá', 1, 'Ly', 49000, 35, 1, 'mocha.png'),
('CF013', 'Hazelnut Macchiato', 1, 'Ly', 38000, 40, 1, 'hazelnut_macchiato.png'),
('CF014', 'Ristretto Bianco', 1, 'Ly', 35000, 40, 1, 'ristretto_bianco.png'),
('CF015', 'Asian Dolce Latte', 1, 'Ly', 40000, 35, 1, 'asian_dolce_latte.png'),
('CF016', 'Espresso Con Panna', 1, 'Ly', 35000, 35, 1, 'espresso_con_panna.png'),
('CF017', 'Espresso Nutella Đặc Biệt', 1, 'Ly', 45000, 30, 1, 'espresso_nutella.png'),
('CF018', 'Cà phê Ái Nhĩ Lan (Café Irlandês)', 1, 'Ly', 48000, 25, 1, 'cafe_irlandes.png'),
('CF019', 'Ice Cappuccino Gelado', 1, 'Ly', 45000, 35, 1, 'ice_cappuccino.png'),

-- 2. TRÀ & ĐỒ UỐNG ẤM (15 món)
('TR001', 'Trà đào cam sả', 2, 'Ly', 45000, 50, 1, 'tra_dao.png'),
('TR002', 'Trà vải hoa hồng', 2, 'Ly', 45000, 45, 1, 'tra_vai.png'),
('TR003', 'Trà dâu tây ổi hồng', 2, 'Ly', 48000, 40, 1, 'tra_dau_oi.png'),
('TR004', 'Trà xoài Macchiato', 2, 'Ly', 48000, 35, 1, 'tra_xoai.png'),
('TR005', 'Trà bưởi hồng mật ong', 2, 'Ly', 45000, 35, 1, 'tra_buoi_hong.png'),
('TR006', 'Trà sữa trân châu hoàng gia', 2, 'Ly', 42000, 60, 1, 'tra_sua_tc.png'),
('TR007', 'Trà sữa Matcha đậu đỏ', 2, 'Ly', 48000, 40, 1, 'tra_sua_matcha.png'),
('TR008', 'Trà sữa Ô Long nướng', 2, 'Ly', 46000, 50, 1, 'tra_sua_olong.png'),
('TR009', 'Hồng trà kem cheese', 2, 'Ly', 45000, 45, 1, 'hong_tra_cheese.png'),
('TR010', 'Trà sen vàng long nhãn', 2, 'Ly', 49000, 35, 1, 'tra_sen_vang.png'),
('TR011', 'Trà hoa nhài mật ong ấm', 2, 'Ly', 35000, 40, 1, 'tra_hoa_nhai.png'),
('TR012', 'Trà chanh gừng nóng hổi', 2, 'Ly', 35000, 45, 1, 'tra_chanh_gung.png'),
('TR013', 'Trà táo quế ngọt ấm', 2, 'Ly', 40000, 40, 1, 'tra_tao_que.png'),
('TR014', 'Trà táo mật ong nóng', 2, 'Ly', 35000, 40, 1, 'tra_tao_mat_ong.png'),
('TR015', 'Trà đen đá Chá Gelado', 2, 'Ly', 30000, 50, 1, 'cha_gelado.png'),

-- 3. ĐÁ XAY & SINH TỐ (13 món)
('DX001', 'Matcha đá xay kem tuyết', 3, 'Ly', 55000, 35, 1, 'matcha_ice.png'),
('DX002', 'Socola chip đá xay', 3, 'Ly', 55000, 35, 1, 'choco_ice.png'),
('DX003', 'Cookie kem đá xay (Oreo)', 3, 'Ly', 55000, 40, 1, 'cookie_ice.png'),
('DX004', 'Cà phê đá xay Caramel', 3, 'Ly', 52000, 30, 1, 'cf_ice.png'),
('DX005', 'Sinh tố bơ sáp cốt dừa', 3, 'Ly', 50000, 30, 1, 'sinh_to_bo.png'),
('DX006', 'Sinh tố xoài cát thơm ngon', 3, 'Ly', 45000, 35, 1, 'sinh_to_xoai.png'),
('DX007', 'Sinh tố việt quất chuối', 3, 'Ly', 52000, 25, 1, 'sinh_to_vietquat.png'),
('DX008', 'Sinh tố dâu tây sữa chua', 3, 'Ly', 48000, 30, 1, 'sinh_to_dau.png'),
('DX009', 'Frappuccino Hazelnut Hạt Phỉ', 3, 'Ly', 45000, 35, 1, 'frap_hazelnut.png'),
('DX010', 'Frappuccino Caramel Sốt Vàng', 3, 'Ly', 45000, 35, 1, 'frap_caramel.png'),
('DX011', 'Frappuccino Bánh Tiramisu', 3, 'Ly', 48000, 30, 1, 'frap_tiramisu.png'),
('DX012', 'Frappuccino Socola Đậm Đà', 3, 'Ly', 45000, 35, 1, 'frap_chocolate.png'),
('DX013', 'Café Shake Frappe Kem Béo', 3, 'Ly', 48000, 30, 1, 'cafe_shake.png'),

-- 4. NƯỚC ÉP & GIẢI KHÁT (8 món)
('NE001', 'Nước cam vắt nguyên chất', 4, 'Ly', 40000, 40, 1, 'nuoc_cam.png'),
('NE002', 'Nước ép dưa hấu mát lạnh', 4, 'Ly', 35000, 45, 1, 'nuoc_duahau.png'),
('NE003', 'Nước ép ổi hồng chanh leo', 4, 'Ly', 42000, 35, 1, 'nuoc_oi_hong.png'),
('NE004', 'Nước ép táo cà rốt tươi', 4, 'Ly', 45000, 30, 1, 'nuoc_tao_carot.png'),
('NE005', 'Nước chanh tuyết bạc hà', 4, 'Ly', 35000, 40, 1, 'chanh_tuyet.png'),
('NE006', 'Soda việt quất đại dương', 4, 'Ly', 38000, 40, 1, 'soda_vietquat.png'),
('NE007', 'Nước cam quế ấm nóng', 4, 'Ly', 38000, 35, 1, 'nuoc_cam_que.png'),
('NE008', 'Nước ép lê gừng nóng ấm', 4, 'Ly', 38000, 35, 1, 'nuoc_le_gung.png'),

-- 5. BÁNH NGỌT & TRÁNG MIỆNG (12 món)
('BN001', 'Bánh Tiramisu Cacao Ý', 5, 'Phần', 45000, 25, 1, 'tiramisu.png'),
('BN002', 'Bánh phô mai nướng Basque', 5, 'Phần', 48000, 20, 1, 'cheesecake.png'),
('BN003', 'Mousse chanh leo tươi', 5, 'Phần', 42000, 25, 1, 'mousse_chanhleo.png'),
('BN004', 'Bánh mì bơ tỏi phô mai', 5, 'Phần', 38000, 30, 1, 'banh_mi_bo_toi.png'),
('BN005', 'Bánh sừng bò Croissant', 5, 'Phần', 35000, 30, 1, 'croissant.png'),
('BN006', 'Bánh Crepe sầu riêng tươi', 5, 'Phần', 50000, 20, 1, 'crepe_saurien.png'),
('BN007', 'Hướng dương vị dừa giòn', 5, 'Gói', 18000, 50, 1, 'huong_duong.png'),
('BN008', 'Khô bò cháy tỏi lá chanh', 5, 'Phần', 45000, 30, 1, 'kho_bo.png'),
('BN009', 'Panna Cotta sốt dâu mọng', 5, 'Phần', 32000, 30, 1, 'panna_cotta.png'),
('BN010', 'Bánh Matcha Mousse Nhật Bản', 5, 'Phần', 32000, 30, 1, 'matcha_mousse.png'),
('BN011', 'Kem dừa non béo ngậy', 5, 'Ly', 30000, 35, 1, 'kem_dua.png'),
('BN012', 'Kem dâu tây ngọt mát', 5, 'Ly', 30000, 35, 1, 'kem_dau.png'),

-- 6. SỮA CHUA (4 món)
('SC001', 'Sữa chua dẻo trái cây', 6, 'Phần', 40000, 35, 1, 'sua_chua_traicay.png'),
('SC002', 'Sữa chua trân châu đường đen', 6, 'Phần', 38000, 40, 1, 'sua_chua_duongden.png'),
('SC003', 'Sữa chua thạch lá nếp', 6, 'Phần', 35000, 35, 1, 'sua_chua_lanep.png'),
('SC004', 'Sữa chua hạt đác rim thơm', 6, 'Phần', 42000, 30, 1, 'sua_chua_hatdac.png'),

-- 7. CACAO & SOCOLA NÓNG (4 món)
('CC001', 'Cacao nóng nguyên chất', 7, 'Ly', 35000, 40, 1, 'cacao_nong.png'),
('CC002', 'Socola bạc hà nóng Marshmallow', 7, 'Ly', 38000, 35, 1, 'socola_bac_ha.png'),
('CC003', 'Socola cam quế nóng đậm đà', 7, 'Ly', 40000, 35, 1, 'socola_cam_que.png'),
('CC004', 'Socola nóng cổ điển (Chocolate Quente)', 7, 'Ly', 35000, 35, 1, 'chocolate_quente.png');

INSERT INTO customers(code, full_name, phone, address, points) VALUES
('KH001','Khách lẻ','', '',0),
('KH002','Lê Thu Trang','0912345678','Quảng Ngãi',120),
('KH003','Phạm Quốc Huy','0987654321','Đà Nẵng',80);

-- Dữ liệu mẫu Sơ đồ Bàn quán CoffeLand
INSERT INTO dining_tables(code, name, area, status) VALUES
('TB00','Mang về (Takeaway)','Quầy thu ngân','EMPTY'),
('TB01','Bàn 01','Tầng 1','EMPTY'),
('TB02','Bàn 02','Tầng 1','EMPTY'),
('TB03','Bàn 03','Tầng 1','EMPTY'),
('TB04','Bàn 04','Tầng 1','EMPTY'),
('TB05','Bàn 05','Tầng 2','EMPTY'),
('TB06','Bàn 06','Tầng 2','EMPTY'),
('TB07','Bàn 07','Tầng 2','EMPTY'),
('TB08','Bàn 08','Tầng 2','EMPTY'),
('TB09','Bàn Sân Vườn 01','Sân vườn','EMPTY'),
('TB10','Bàn Sân Vườn 02','Sân vườn','EMPTY'),
('TB11','Bàn Sân Vườn 03','Sân vườn','EMPTY');

-- DỮ LIỆU MẪU: PHIẾU NHẬP KHO (STOCK RECEIPTS)
INSERT INTO stock_receipts(id, code, employee_id, note, created_at) VALUES
(1, 'PN260908001', 1, 'Nhập hạt cà phê Arabica/Robusta và sữa tươi đầu tuần', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(2, 'PN260910002', 1, 'Nhập trà trái cây, bột matcha và siro hoa quả', DATE_SUB(NOW(), INTERVAL 3 DAY)),
(3, 'PN260912003', 2, 'Nhập bánh tươi Tiramisu, Croissant và đồ ăn vặt', DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO stock_receipt_items(receipt_id, product_id, quantity, cost_price) VALUES
-- Phiếu 1
(1, 1, 100, 15000), -- Cà phê đen
(1, 2, 100, 18000), -- Cà phê sữa
(1, 3, 80, 20000),  -- Bạc xỉu
(1, 9, 70, 22000),  -- Cà phê muối
-- Phiếu 2
(2, 20, 60, 25000), -- Trà đào cam sả
(2, 25, 80, 24000), -- Trà sữa trân châu hoàng gia
(2, 27, 60, 26000), -- Trà sữa Ô Long nướng
(2, 35, 50, 30000), -- Matcha đá xay
-- Phiếu 3
(3, 56, 30, 26000), -- Bánh Tiramisu
(3, 60, 40, 20000), -- Bánh Croissant
(3, 62, 100, 9000); -- Hướng dương vị dừa

-- DỮ LIỆU MẪU: HÓA ĐƠN BÁN HÀNG 7 NGÀY GẦN NHẤT (INVOICES & ITEMS)
INSERT INTO invoices(id, code, customer_id, employee_id, table_id, created_at, subtotal, discount, total, payment_method) VALUES
(1, 'HD260907001', 1, 2, 2, DATE_SUB(NOW(), INTERVAL 6 DAY), 105000, 0, 105000, 'Tiền mặt'),
(2, 'HD260908002', 2, 1, 3, DATE_SUB(NOW(), INTERVAL 5 DAY), 142000, 10000, 132000, 'Chuyển khoản QR'),
(3, 'HD260909003', 3, 2, 6, DATE_SUB(NOW(), INTERVAL 4 DAY), 93000, 0, 93000, 'Tiền mặt'),
(4, 'HD260910004', 1, 1, 10, DATE_SUB(NOW(), INTERVAL 3 DAY), 185000, 15000, 170000, 'Chuyển khoản QR'),
(5, 'HD260911005', 2, 2, 4, DATE_SUB(NOW(), INTERVAL 2 DAY), 127000, 0, 127000, 'Thẻ ATM / Visa'),
(6, 'HD260912006', 1, 2, 2, DATE_SUB(NOW(), INTERVAL 1 DAY), 215000, 20000, 195000, 'Tiền mặt'),
(7, 'HD260913007', 3, 1, 5, DATE_SUB(NOW(), INTERVAL 3 HOUR), 125000, 0, 125000, 'Chuyển khoản QR'),
(8, 'HD260913008', 1, 2, 1, DATE_SUB(NOW(), INTERVAL 1 HOUR), 77000, 0, 77000, 'Tiền mặt');

INSERT INTO invoice_items(invoice_id, product_id, quantity, unit_price, line_total, note) VALUES
-- HD 1 (6 ngày trước): 1 CF đen (25k), 1 Bạc xỉu (35k), 1 Tiramisu (45k) = 105k
(1, 1, 1, 25000, 25000, 'Ít đường'),
(1, 3, 1, 35000, 35000, 'Nhiều sữa'),
(1, 56, 1, 45000, 45000, ''),

-- HD 2 (5 ngày trước): 2 Trà đào cam sả (90k), 1 Caramel Macchiato (52k) = 142k
(2, 20, 2, 45000, 90000, 'Ít đá 50%'),
(2, 8, 1, 52000, 52000, 'Nóng'),

-- HD 3 (4 ngày trước): 1 Cà phê muối (38k), 1 Matcha đá xay (55k) = 93k
(3, 9, 1, 38000, 38000, 'Ít đá'),
(3, 35, 1, 55000, 55000, 'Thêm kem'),

-- HD 4 (3 ngày trước): 2 Trà sữa trân châu (84k), 1 Sinh tố bơ (50k), 1 Bánh croissant (35k), 1 Hướng dương (16k) ~ 185k
(4, 25, 2, 42000, 84000, '70% đường, 100% đá'),
(4, 39, 1, 50000, 50000, ''),
(4, 60, 1, 35000, 35000, 'Hâm nóng'),
(4, 62, 1, 16000, 16000, ''),

-- HD 5 (2 ngày trước): 1 Cold Brew (48k), 1 Latte Vanilla (48k), 1 Kem dừa non (31k) = 127k
(5, 11, 1, 48000, 48000, ''),
(5, 7, 1, 48000, 48000, 'Không đường'),
(5, 66, 1, 31000, 31000, ''),

-- HD 6 (Hôm qua): 2 Cà phê muối (76k), 2 Trà sữa Ô long (92k), 1 Bánh phô mai (47k) = 215k
(6, 9, 2, 38000, 76000, 'Đậm vị muối'),
(6, 27, 2, 46000, 92000, 'Trân châu trắng'),
(6, 57, 1, 47000, 47000, ''),

-- HD 7 (Hôm nay): 1 Cà phê sữa đá (30k), 1 Bạc xỉu (35k), 1 Matcha đá xay (60k) = 125k
(7, 2, 1, 30000, 30000, 'Ít ngọt'),
(7, 3, 1, 35000, 35000, ''),
(7, 35, 1, 60000, 60000, 'Nhiều whipping cream'),

-- HD 8 (Hôm nay): 1 Cà phê đen (25k), 1 Caramel Macchiato (52k) = 77k
(8, 1, 1, 25000, 25000, 'Đá riêng'),
(8, 8, 1, 52000, 52000, 'Nóng');


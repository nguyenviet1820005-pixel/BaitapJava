# CoffeLand - Hệ Thống Quản Lý Bán Cà Phê & Kho Hàng (Java Swing)

Đồ án môn học **Công nghệ Java** / **Lập trình Java Nâng cao**
Ứng dụng desktop hoàn chỉnh quản lý hoạt động bán hàng, quản lý thực đơn đồ uống, quản lý khách hàng & điểm tích lũy, nhập xuất tồn kho và báo cáo doanh thu cho chuỗi quán cà phê **CoffeLand**.

---

## 🌟 Tính Năng Nổi Bật

1. **Giao diện Hiện đại & Trực quan (Modern Coffee UI)**:
   - Tích hợp FlatLaf Look & Feel kết hợp bảng màu cà phê sang trọng (`#6F4E37` / `#D4A373`).
   - Bảng biểu bo góc, dòng xen kẽ (Zebra rows), thẻ thống kê KPI Dashboard sinh động.
   - Đồng hồ thời gian thực, huy hiệu phân quyền và nút đổi mật khẩu nhanh.

2. **Bán Hàng Tại Quầy (POS - Point of Sale)**:
   - Thêm món nhanh vào giỏ hàng, kiểm tra tồn kho tức thời.
   - Chọn khách hàng hoặc thêm nhanh khách hàng mới ngay tại quầy thu ngân.
   - Hỗ trợ chiết khấu/giảm giá, tự động tính tiền thối lại cho khách.
   - **Tự động xuất & in hóa đơn bán lẻ (Bill Preview)** chuẩn mẫu phiếu thanh toán quán cà phê.

3. **Quản Lý Thực Đơn & Danh Mục**:
   - Quản lý danh mục (Cà phê, Trà, Đá xay, Bánh ngọt...).
   - Quản lý sản phẩm / đồ uống: mã món, tên món, đơn vị tính, giá bán, tồn kho, trạng thái kinh doanh.
   - Tìm kiếm nhanh theo từ khóa hoặc lọc theo danh mục.

4. **Quản Lý Khách Hàng & Điểm Tích Lũy**:
   - Tự động tích điểm khi mua hàng (10.000 ₫ = 1 điểm).
   - Tra cứu khách hàng theo số điện thoại, họ tên hoặc mã khách hàng.

5. **Quản Lý Kho Hàng & Nhập Kho (Inventory)**:
   - Lập phiếu nhập kho nhanh, tự động cộng tồn kho sản phẩm bằng Transaction an toàn.
   - Xem lại **lịch sử các phiếu nhập kho** và tra cứu chi tiết từng mặt hàng trong phiếu nhập.

6. **Tra Cứu Hóa Đơn & Báo Cáo Doanh Thu**:
   - Lọc hóa đơn theo từ khóa, theo ngày (Hôm nay, 7 ngày qua, Tháng này).
   - Thống kê tổng số đơn và tổng doanh thu theo bộ lọc.
   - **Xem lại & In lại chi tiết từng hóa đơn cũ** bất cứ lúc nào.

7. **Quản Lý Nhân Sự & Phân Quyền (ADMIN)**:
   - Quản lý danh sách nhân viên, chức vụ, trạng thái làm việc.
   - Phân quyền: Chỉ tài khoản `ADMIN` mới có quyền truy cập tab Quản lý nhân viên.

8. **Bảo Mật & Quản Trị Tài Khoản**:
   - Mật khẩu được mã hóa an toàn bằng thuật toán băm **SHA-256**.
   - Hộp thoại đổi mật khẩu tài khoản trực tiếp trong ứng dụng.

---

## 🛠 Công Nghệ Sử Dụng

- **Ngôn ngữ**: Java 17+ (OOP, Swing, JDBC, Collections, Lambda Expressions)
- **Giao diện**: Java Swing + FlatLaf Modern Flat UI + Custom Components
- **Cơ sở dữ liệu**: MySQL 8.x
- **Build Tool**: Apache Maven

---

## 📁 Cấu Trúc Mã Nguồn (MVC Pattern)

```
CoffeLand_JavaSwing/
├── database/
│   └── coffeeland.sql                 # Kịch bản khởi tạo CSDL và dữ liệu mẫu
├── src/main/java/com/coffeeland/
│   ├── App.java                       # Điểm khởi chạy chương trình (Main)
│   ├── config/
│   │   └── DBConnection.java          # Kết nối CSDL MySQL (UTF-8, Timezone)
│   ├── model/                         # Các lớp đối tượng (Entities)
│   │   ├── User.java
│   │   ├── Employee.java
│   │   ├── Customer.java
│   │   ├── Category.java
│   │   ├── Product.java
│   │   ├── CartItem.java
│   │   ├── Invoice.java
│   │   ├── InvoiceItem.java
│   │   ├── StockReceipt.java
│   │   └── StockReceiptItem.java
│   ├── dao/                           # Data Access Object (Truy vấn CSDL)
│   │   ├── UserDAO.java
│   │   ├── EmployeeDAO.java
│   │   ├── CustomerDAO.java
│   │   ├── CategoryDAO.java
│   │   ├── ProductDAO.java
│   │   ├── InvoiceDAO.java
│   │   ├── InventoryDAO.java
│   │   ├── StatsDAO.java
│   │   └── ReportDAO.java
│   ├── util/                          # Tiện ích giao diện & bảo mật
│   │   ├── UIUtils.java               # Hệ màu, bảng biểu, button, format tiền/ngày
│   │   └── PasswordUtils.java         # Mã hóa SHA-256
│   └── ui/                            # Giao diện người dùng Swing
│       ├── LoginFrame.java            # Màn hình Đăng nhập
│       ├── MainFrame.java             # Cửa sổ chính & Thanh điều hướng
│       ├── DashboardPanel.java        # Tab Tổng quan & Thống kê KPI
│       ├── SalesPanel.java            # Tab Bán hàng & Thu ngân (POS)
│       ├── ProductPanel.java          # Tab Quản lý Sản phẩm / Menu
│       ├── CategoryPanel.java         # Tab Quản lý Danh mục
│       ├── CustomerPanel.java         # Tab Quản lý Khách hàng
│       ├── InventoryPanel.java        # Tab Quản lý Kho & Nhập kho
│       ├── InvoicePanel.java          # Tab Quản lý Hóa đơn
│       ├── EmployeePanel.java         # Tab Quản lý Nhân viên (Admin)
│       ├── ChangePasswordDialog.java  # Hộp thoại Đổi mật khẩu
│       ├── InvoiceDetailDialog.java   # Hộp thoại Phiếu thanh toán / In hóa đơn
│       └── StockReceiptDetailDialog.java # Hộp thoại Chi tiết phiếu nhập
├── pom.xml                            # Quản lý thư viện Maven
└── README.md
```

---

## 🚀 Hướng Dẫn Cài Đặt & Chạy Ứng Dụng

### Bước 1: Chuẩn bị Môi trường
- Cài đặt **JDK 17** hoặc mới hơn.
- Cài đặt **MySQL Server** (hoặc XAMPP / WampServer).

### Bước 2: Import Cơ Sở Dữ Liệu
1. Mở **MySQL Workbench**, **phpMyAdmin** hoặc **HeidiSQL**.
2. Mở file `database/coffeeland.sql` và thực thi toàn bộ script để tạo bảng và dữ liệu mẫu.

### Bước 3: Cấu hình Kết nối CSDL
Nếu tài khoản MySQL `root` của bạn có mật khẩu, hãy mở file:
`src/main/java/com/coffeeland/config/DBConnection.java` và chỉnh sửa biến `PASSWORD`:
```java
private static final String PASSWORD = "mat_khau_cua_ban";
```

### Bước 4: Chạy Chương Trình

**Cách 1: Chạy bằng dòng lệnh (Maven)**
```bash
mvn clean compile
mvn exec:java
```

**Cách 2: Mở bằng IDE (NetBeans / IntelliJ IDEA / Eclipse / VS Code)**
- Mở IDE -> Chọn **Open Project** -> Trỏ vào thư mục `CoffeLand_JavaSwing`.
- Chuột phải vào file `App.java` -> Chọn **Run File** (hoặc nhấn phím tắt `Shift + F6` trên NetBeans).

---

## 🔑 Tài Khoản Thử Nghiệm

| Vai trò | Tên đăng nhập | Mật khẩu | Quyền hạn |
| :--- | :--- | :--- | :--- |
| **Quản trị viên** | `admin` | `admin123` | Toàn quyền quản trị hệ thống + Quản lý nhân viên |
| **Thu ngân** | `nhanvien` | `nv123` | Bán hàng, quản lý món, kho hàng, khách hàng, hóa đơn |

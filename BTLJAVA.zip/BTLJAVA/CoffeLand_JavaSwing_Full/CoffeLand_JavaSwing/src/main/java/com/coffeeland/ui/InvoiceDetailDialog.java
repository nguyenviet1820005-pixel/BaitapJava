package com.coffeeland.ui;

import com.coffeeland.dao.InvoiceDAO;
import com.coffeeland.model.Invoice;
import com.coffeeland.model.InvoiceItem;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Hộp thoại hiển thị chi tiết hóa đơn theo mẫu Phiếu thanh toán CoffeLand chuyên nghiệp.
 */
public class InvoiceDetailDialog extends JDialog {

    private final Invoice invoice;
    private final InvoiceDAO invoiceDAO = new InvoiceDAO();

    public InvoiceDetailDialog(Window parent, Invoice invoice) {
        super(parent, "Chi tiết hóa đơn - " + (invoice != null ? invoice.getCode() : ""), ModalityType.APPLICATION_MODAL);
        this.invoice = invoice;

        setSize(580, 700);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        initUI();
    }

    public InvoiceDetailDialog(Window parent, String invoiceCode) {
        this(parent, loadInvoiceByCode(invoiceCode));
    }

    private static Invoice loadInvoiceByCode(String code) {
        try {
            return new InvoiceDAO().getInvoiceByCode(code);
        } catch (Exception e) {
            return null;
        }
    }

    private void initUI() {
        if (invoice == null) {
            JLabel err = new JLabel("Không tìm thấy thông tin hóa đơn.", SwingConstants.CENTER);
            add(err, BorderLayout.CENTER);
            return;
        }

        JPanel mainPanel = new JPanel(new BorderLayout(0, 10));
        mainPanel.setBackground(UIUtils.BG_MAIN);
        mainPanel.setBorder(new EmptyBorder(14, 16, 14, 16));

        // Khung hóa đơn giấy màu trắng
        JPanel receiptCard = new JPanel(new BorderLayout(0, 8));
        receiptCard.setBackground(Color.WHITE);
        receiptCard.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(18, 20, 18, 20)
        ));

        // 1. Header quán cà phê
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        JLabel lblBrand = new JLabel("☕ COFFEELAND SPECIALTY", SwingConstants.CENTER);
        lblBrand.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblBrand.setForeground(UIUtils.PRIMARY_COLOR);
        lblBrand.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSub = new JLabel("Đ/C: 123 Đường Cà Phê, Quận Nam Từ Liêm, TP.Hà Nội  |  Hotline: 1900 1234", SwingConstants.CENTER);
        lblSub.setFont(UIUtils.FONT_SMALL);
        lblSub.setForeground(UIUtils.TEXT_MUTED);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblTitle = new JLabel("--- HÓA ĐƠN BÁN HÀNG ---", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(UIUtils.TEXT_DARK);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(lblBrand);
        headerPanel.add(Box.createVerticalStrut(2));
        headerPanel.add(lblSub);
        headerPanel.add(Box.createVerticalStrut(10));
        headerPanel.add(lblTitle);
        headerPanel.add(Box.createVerticalStrut(12));

        // 2. Thông tin chung hóa đơn
        JPanel infoGrid = new JPanel(new GridLayout(4, 2, 4, 4));
        infoGrid.setOpaque(false);

        infoGrid.add(createMetaLabel("Mã hóa đơn: ", invoice.getCode()));
        infoGrid.add(createMetaLabel("Ngày lập: ", UIUtils.formatDateTime(invoice.getCreatedAt())));
        infoGrid.add(createMetaLabel("Khách hàng: ", invoice.getCustomerName() != null ? invoice.getCustomerName() : "Khách lẻ"));
        infoGrid.add(createMetaLabel("Thu ngân: ", invoice.getEmployeeName() != null ? invoice.getEmployeeName() : "-"));
        infoGrid.add(createMetaLabel("Thanh toán: ", invoice.getPaymentMethod()));
        infoGrid.add(createMetaLabel("SĐT khách: ", invoice.getCustomerPhone() != null ? invoice.getCustomerPhone() : "-"));

        headerPanel.add(infoGrid);
        headerPanel.add(Box.createVerticalStrut(10));

        receiptCard.add(headerPanel, BorderLayout.NORTH);

        // 3. Bảng danh sách món
        String[] cols = {"STT", "Tên món", "Tùy chọn / Ghi chú", "SL", "Đơn giá", "Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(UIUtils.FONT_BODY);
        table.setShowGrid(false);
        table.getTableHeader().setFont(UIUtils.FONT_BODY_BOLD);
        table.getTableHeader().setBackground(new Color(240, 240, 240));
        table.getTableHeader().setForeground(UIUtils.TEXT_DARK);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(32);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setPreferredWidth(38);
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(4).setPreferredWidth(75);
        table.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        table.getColumnModel().getColumn(5).setPreferredWidth(85);
        table.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);

        table.getColumnModel().getColumn(1).setPreferredWidth(125);
        table.getColumnModel().getColumn(2).setPreferredWidth(125);

        // Load món vào bảng
        loadItems(model);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIUtils.BORDER_COLOR));
        receiptCard.add(scrollPane, BorderLayout.CENTER);

        // 4. Tổng kết tiền và Footer
        JPanel summaryPanel = new JPanel();
        summaryPanel.setOpaque(false);
        summaryPanel.setLayout(new BoxLayout(summaryPanel, BoxLayout.Y_AXIS));
        summaryPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        summaryPanel.add(createSummaryRow("Tạm tính:", UIUtils.money(invoice.getSubtotal()), false));
        if (invoice.getDiscount() > 0) {
            summaryPanel.add(createSummaryRow("Giảm giá / Chiết khấu:", "- " + UIUtils.money(invoice.getDiscount()), false));
        }
        summaryPanel.add(createSummaryRow("TỔNG THANH TOÁN:", UIUtils.money(invoice.getTotal()), true));
        summaryPanel.add(Box.createVerticalStrut(12));

        JLabel lblFooter = new JLabel("Cảm ơn Quý khách & Hẹn gặp lại!", SwingConstants.CENTER);
        lblFooter.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblFooter.setForeground(UIUtils.TEXT_MUTED);
        lblFooter.setAlignmentX(Component.CENTER_ALIGNMENT);
        summaryPanel.add(lblFooter);

        receiptCard.add(summaryPanel, BorderLayout.SOUTH);
        mainPanel.add(receiptCard, BorderLayout.CENTER);

        // 5. Thanh nút bấm dưới cùng
        JPanel bottomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bottomButtons.setOpaque(false);

        JButton btnPrint = UIUtils.createPrimaryButton("🖨 In hóa đơn");
        JButton btnClose = UIUtils.createSecondaryButton("Đóng");

        btnPrint.addActionListener(e -> {
            UIUtils.info(this, "Đã gửi lệnh in hóa đơn [" + invoice.getCode() + "] ra máy in POS thành công!");
        });
        btnClose.addActionListener(e -> dispose());

        bottomButtons.add(btnPrint);
        bottomButtons.add(btnClose);
        mainPanel.add(bottomButtons, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void loadItems(DefaultTableModel model) {
        try {
            List<InvoiceItem> items = invoice.getItems();
            if (items == null || items.isEmpty()) {
                items = invoiceDAO.getInvoiceItems(invoice.getId());
            }

            int stt = 1;
            for (InvoiceItem item : items) {
                String note = (item.getNote() != null && !item.getNote().trim().isEmpty()) ? item.getNote().trim() : "-";
                model.addRow(new Object[]{
                        stt++,
                        item.getProductName(),
                        note,
                        item.getQuantity(),
                        UIUtils.money(item.getUnitPrice()),
                        UIUtils.money(item.getLineTotal())
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private JPanel createMetaLabel(String title, String value) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        p.setOpaque(false);
        JLabel lblT = new JLabel(title);
        lblT.setFont(UIUtils.FONT_SMALL);
        lblT.setForeground(UIUtils.TEXT_MUTED);

        JLabel lblV = new JLabel(value != null ? value : "");
        lblV.setFont(UIUtils.FONT_BODY_BOLD);
        lblV.setForeground(UIUtils.TEXT_DARK);

        p.add(lblT);
        p.add(lblV);
        return p;
    }

    private JPanel createSummaryRow(String title, String value, boolean isBold) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(2, 0, 2, 0));

        JLabel lblT = new JLabel(title);
        lblT.setFont(isBold ? new Font("Segoe UI", Font.BOLD, 15) : UIUtils.FONT_BODY);
        lblT.setForeground(isBold ? UIUtils.PRIMARY_COLOR : UIUtils.TEXT_DARK);

        JLabel lblV = new JLabel(value);
        lblV.setFont(isBold ? new Font("Segoe UI", Font.BOLD, 16) : UIUtils.FONT_BODY_BOLD);
        lblV.setForeground(isBold ? UIUtils.DANGER_COLOR : UIUtils.TEXT_DARK);

        p.add(lblT, BorderLayout.WEST);
        p.add(lblV, BorderLayout.EAST);
        return p;
    }
}

package com.coffeeland.dao;
import com.coffeeland.config.DBConnection;
import com.coffeeland.model.Category;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Danh mục sản phẩm (Categories).
 */
public class CategoryDAO {

    /**
     * Lấy toàn bộ danh mục sản phẩm kèm số lượng món hiện có.
     */
    public List<Category> findAll() throws SQLException {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT c.id, c.name, c.description, COUNT(p.id) AS product_count " +
                     "FROM categories c " +
                     "LEFT JOIN products p ON c.id = p.category_id " +
                     "GROUP BY c.id, c.name, c.description " +
                     "ORDER BY c.name ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Category cat = new Category();
                cat.setId(rs.getInt("id"));
                cat.setName(rs.getString("name"));
                cat.setDescription(rs.getString("description"));
                cat.setProductCount(rs.getInt("product_count"));
                list.add(cat);
            }
        }
        return list;
    }

    /**
     * Thêm danh mục mới vào CSDL.
     */
    public void insert(Category category) throws SQLException {
        String sql = "INSERT INTO categories(name, description) VALUES(?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, category.getName().trim());
            ps.setString(2, category.getDescription() != null ? category.getDescription().trim() : "");
            ps.executeUpdate();
        }
    }

    /**
     * Cập nhật thông tin danh mục theo ID.
     */
    public void update(Category category) throws SQLException {
        String sql = "UPDATE categories SET name = ?, description = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, category.getName().trim());
            ps.setString(2, category.getDescription() != null ? category.getDescription().trim() : "");
            ps.setInt(3, category.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Xóa danh mục theo ID (nếu chưa có sản phẩm nào tham chiếu tới).
     */
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM categories WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

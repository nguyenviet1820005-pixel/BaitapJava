package com.coffeeland.ui;

import com.coffeeland.dao.DiningTableDAO;
import com.coffeeland.model.DiningTable;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Màn hình Quản lý Sơ đồ Bàn & Khu vực:
 * - Tab 1: Sơ đồ bàn trực quan (Visual Floor Plan) có màu sắc trạng thái, đổi nhanh trạng thái 1-click.
 * - Tab 2: Quản lý danh sách bàn (Thêm, Sửa, Xóa bàn và Khu vực).
 */
public class TableManagementPanel extends JPanel {

    private final DiningTableDAO tableDAO = new DiningTableDAO();

    // Tab 1: Visual Floor Plan components
    private final JPanel visualGridPanel = new JPanel();
    private final JComboBox<String> cboVisualAreaFilter = new JComboBox<>(new String[]{"-- Tất cả khu vực --", "Tầng 1", "Tầng 2", "Sân vườn", "Quầy thu ngân"});
    private final JLabel lblStatTotal = new JLabel("Tổng: 0 bàn");
    private final JLabel lblStatEmpty = new JLabel("Trống: 0");
    private final JLabel lblStatOccupied = new JLabel("Có khách: 0");
    private final JLabel lblStatReserved = new JLabel("Đã đặt: 0");

    // Tab 2: Table List & CRUD Form components
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Mã bàn", "Tên bàn", "Khu vực", "Trạng thái phục vụ"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);
    private final JComboBox<String> cboAreaFilter = new JComboBox<>(new String[]{"-- Tất cả khu vực --", "Tầng 1", "Tầng 2", "Sân vườn", "Quầy thu ngân"});

    // Form
    private final JTextField txtCode = new JTextField();
    private final JTextField txtName = new JTextField();
    private final JComboBox<String> cboArea = new JComboBox<>(new String[]{"Tầng 1", "Tầng 2", "Sân vườn", "Quầy thu ngân"});
    private final JComboBox<String> cboStatus = new JComboBox<>(new String[]{"EMPTY", "OCCUPIED", "RESERVED"});
    private int selectedTableId = 0;

    public TableManagementPanel() {
        setLayout(new BorderLayout(14, 12));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(14, 16, 14, 16));

        initUI();
        loadTables();
    }

    private void initUI() {
        // Tiêu đề
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        JLabel lblTitle = new JLabel("QUẢN LÝ SƠ ĐỒ BÀN & KHU VỰC");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        topPanel.add(lblTitle, BorderLayout.WEST);
        add(topPanel, BorderLayout.NORTH);

        // Tabbed container
        JTabbedPane subTabs = new JTabbedPane(JTabbedPane.TOP);
        subTabs.setFont(UIUtils.FONT_BODY_BOLD);
        subTabs.setBackground(Color.WHITE);

        // Tab 1: Sơ đồ bàn trực quan
        JPanel visualTab = createVisualMapTab();
        subTabs.addTab("Sơ đồ bàn trực quan", visualTab);

        // Tab 2: Quản lý danh sách bàn
        JPanel crudTab = createCrudTab();
        subTabs.addTab("Danh sách & Thiết lập bàn", crudTab);

        add(subTabs, BorderLayout.CENTER);
    }

    private JPanel createVisualMapTab() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(10, 8, 8, 8));

        // Thanh bộ lọc và Thống kê nhanh
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JPanel leftFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftFilter.setOpaque(false);
        leftFilter.add(new JLabel("Lọc theo khu vực:"));
        cboVisualAreaFilter.setPreferredSize(new Dimension(160, 32));
        cboVisualAreaFilter.addActionListener(e -> loadVisualMap());
        leftFilter.add(cboVisualAreaFilter);

        JButton btnReload = UIUtils.createSecondaryButton("Tải lại");
        btnReload.addActionListener(e -> loadVisualMap());
        leftFilter.add(btnReload);

        // Thống kê nhanh
        JPanel rightStats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        rightStats.setOpaque(false);

        lblStatTotal.setFont(UIUtils.FONT_BODY_BOLD);
        lblStatEmpty.setFont(UIUtils.FONT_BODY_BOLD);
        lblStatEmpty.setForeground(UIUtils.SUCCESS_COLOR);
        lblStatOccupied.setFont(UIUtils.FONT_BODY_BOLD);
        lblStatOccupied.setForeground(UIUtils.DANGER_COLOR);
        lblStatReserved.setFont(UIUtils.FONT_BODY_BOLD);
        lblStatReserved.setForeground(UIUtils.WARNING_COLOR);

        rightStats.add(lblStatTotal);
        rightStats.add(new JLabel("|"));
        rightStats.add(lblStatEmpty);
        rightStats.add(lblStatOccupied);
        rightStats.add(lblStatReserved);

        topBar.add(leftFilter, BorderLayout.WEST);
        topBar.add(rightStats, BorderLayout.EAST);
        p.add(topBar, BorderLayout.NORTH);

        // Lưới thẻ bàn
        visualGridPanel.setBackground(UIUtils.BG_MAIN);
        visualGridPanel.setLayout(new GridLayout(0, 4, 12, 12)); // 4 cột bàn

        JScrollPane scroll = new JScrollPane(visualGridPanel);
        scroll.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(12, 12, 12, 12)
        ));
        scroll.setBackground(UIUtils.BG_MAIN);
        scroll.getViewport().setBackground(UIUtils.BG_MAIN);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel createCrudTab() {
        JPanel p = new JPanel(new BorderLayout(14, 10));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(10, 8, 8, 8));

        // Thanh lọc danh sách
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filterBar.setOpaque(false);
        filterBar.add(new JLabel("Lọc khu vực:"));
        cboAreaFilter.setPreferredSize(new Dimension(160, 32));
        filterBar.add(cboAreaFilter);
        cboAreaFilter.addActionListener(e -> loadTables());

        p.add(filterBar, BorderLayout.NORTH);

        // Bảng dữ liệu bàn bên trái
        JPanel centerCard = UIUtils.createCardPanel("DANH SÁCH BÀN PHỤC VỤ");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(45);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(center);
        table.getColumnModel().getColumn(4).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setCellRenderer(center);

        table.getSelectionModel().addListSelectionListener(e -> handleSelectRow());
        centerCard.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(centerCard, BorderLayout.CENTER);

        // Form thông tin bàn bên phải
        JPanel rightCard = UIUtils.createCardPanel("THÔNG TIN BÀN");
        rightCard.setPreferredSize(new Dimension(360, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        formBody.add(UIUtils.formRow("Mã bàn *:", txtCode));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Tên bàn *:", txtName));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Khu vực:", cboArea));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Trạng thái:", cboStatus));
        formBody.add(Box.createVerticalStrut(18));

        // Nút thao tác
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 8, 8));
        buttonPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Lưu");
        JButton btnClear = UIUtils.createSecondaryButton("+ Mới");
        JButton btnDelete = UIUtils.createDangerButton("Xóa");

        btnSave.addActionListener(e -> handleSave());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> handleDelete());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnDelete);

        formBody.add(buttonPanel);
        rightCard.add(formBody, BorderLayout.CENTER);
        p.add(rightCard, BorderLayout.EAST);

        return p;
    }

    public void loadTables() {
        loadVisualMap();
        try {
            tableModel.setRowCount(0);
            String area = String.valueOf(cboAreaFilter.getSelectedItem());
            if (area.contains("-- Tất cả")) area = null;

            List<DiningTable> list = tableDAO.findAll(area);
            for (DiningTable t : list) {
                tableModel.addRow(new Object[]{
                        t.getId(),
                        t.getCode(),
                        t.getName(),
                        t.getArea(),
                        t.getStatusDisplay()
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void loadVisualMap() {
        try {
            visualGridPanel.removeAll();
            String area = String.valueOf(cboVisualAreaFilter.getSelectedItem());
            if (area.contains("-- Tất cả")) area = null;

            List<DiningTable> list = tableDAO.findAll(area);

            int total = list.size();
            int empty = 0;
            int occupied = 0;
            int reserved = 0;

            for (DiningTable t : list) {
                if (t.isOccupied()) {
                    occupied++;
                } else if (t.isReserved()) {
                    reserved++;
                } else {
                    empty++;
                }
                visualGridPanel.add(createVisualTableCard(t));
            }

            lblStatTotal.setText("Tổng: " + total + " bàn");
            lblStatEmpty.setText("Trống: " + empty);
            lblStatOccupied.setText("Có khách: " + occupied);
            lblStatReserved.setText("Đã đặt: " + reserved);

            visualGridPanel.revalidate();
            visualGridPanel.repaint();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private JPanel createVisualTableCard(DiningTable t) {
        Color statusColor;
        Color statusBg;
        Color statusTextColor;
        String statusText;
        String statusIcon;

        if (t.isOccupied()) {
            statusColor = UIUtils.DANGER_COLOR;
            statusBg = new Color(255, 235, 235);
            statusTextColor = UIUtils.DANGER_COLOR;
            statusText = "Có khách";
            statusIcon = "👨";
        } else if (t.isReserved()) {
            statusColor = UIUtils.WARNING_COLOR;
            statusBg = new Color(255, 245, 220);
            statusTextColor = UIUtils.WARNING_COLOR;
            statusText = "Đã đặt";
            statusIcon = "📌";
        } else {
            statusColor = UIUtils.SUCCESS_COLOR;
            statusBg = new Color(230, 248, 235);
            statusTextColor = UIUtils.SUCCESS_COLOR;
            statusText = "Trống";
            statusIcon = "✅";
        }

        JPanel card = new JPanel(new BorderLayout(0, 4)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBackground(statusBg);
        card.setPreferredSize(new Dimension(185, 150));
        card.setBorder(new CompoundBorder(
                new LineBorder(statusColor, 2, true),
                new EmptyBorder(10, 12, 10, 12)
        ));

        // Header: Mã bàn (trái) & Badge khu vực (phải)
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel lblCode = new JLabel(t.getCode());
        lblCode.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblCode.setForeground(UIUtils.TEXT_MUTED);

        JLabel lblArea = UIUtils.createBadge(t.getArea(), new Color(240, 240, 245), UIUtils.TEXT_DARK);
        header.add(lblCode, BorderLayout.WEST);
        header.add(lblArea, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        // Center: Icon + Tên bàn
        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        JLabel lblIcon = new JLabel("🛋️", SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 32));
        lblIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblName = new JLabel(t.getName(), SwingConstants.CENTER);
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblName.setForeground(UIUtils.TEXT_DARK);
        lblName.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(Box.createVerticalGlue());
        center.add(lblIcon);
        center.add(Box.createVerticalStrut(2));
        center.add(lblName);
        center.add(Box.createVerticalGlue());
        card.add(center, BorderLayout.CENTER);

        // Footer: Badge trạng thái
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        footer.setOpaque(false);
        JLabel lblStatus = UIUtils.createBadge(statusIcon + " " + statusText, statusTextColor, Color.WHITE);
        footer.add(lblStatus);
        card.add(footer, BorderLayout.SOUTH);

        // Hover effect & click
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBorder(new CompoundBorder(
                        new LineBorder(statusColor.darker(), 3, true),
                        new EmptyBorder(9, 11, 9, 11)
                ));
                card.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                card.setBorder(new CompoundBorder(
                        new LineBorder(statusColor, 2, true),
                        new EmptyBorder(10, 12, 10, 12)
                ));
                card.repaint();
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                showQuickStatusPopup(t, card);
            }
        });

        return card;
    }

    private void showQuickStatusPopup(DiningTable t, Component parent) {
        String[] options = {"Đặt làm TRỐNG", "Đặt làm CÓ KHÁCH", "Đặt làm ĐÃ ĐẶT", "Hủy"};
        int choice = JOptionPane.showOptionDialog(
                parent,
                "Chọn trạng thái mới cho bàn [" + t.getName() + " - " + t.getArea() + "]:",
                "Cập nhật trạng thái bàn",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        String newStatus = null;
        if (choice == 0) newStatus = "EMPTY";
        else if (choice == 1) newStatus = "OCCUPIED";
        else if (choice == 2) newStatus = "RESERVED";

        if (newStatus != null) {
            try {
                tableDAO.updateStatus(t.getId(), newStatus);
                loadTables();
            } catch (Exception ex) {
                UIUtils.error(this, ex);
            }
        }
    }

    private void handleSelectRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        selectedTableId = (int) tableModel.getValueAt(row, 0);
        txtCode.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        txtName.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        cboArea.setSelectedItem(String.valueOf(tableModel.getValueAt(row, 3)));

        String statusDisplay = String.valueOf(tableModel.getValueAt(row, 4));
        if (statusDisplay.contains("Có khách")) {
            cboStatus.setSelectedItem("OCCUPIED");
        } else if (statusDisplay.contains("Đã đặt")) {
            cboStatus.setSelectedItem("RESERVED");
        } else {
            cboStatus.setSelectedItem("EMPTY");
        }
    }

    private void handleSave() {
        String code = txtCode.getText().trim();
        String name = txtName.getText().trim();
        String area = String.valueOf(cboArea.getSelectedItem());
        String status = String.valueOf(cboStatus.getSelectedItem());

        if (code.isEmpty() || name.isEmpty()) {
            UIUtils.warning(this, "Vui lòng nhập đầy đủ Mã bàn và Tên bàn.");
            return;
        }

        try {
            DiningTable t = new DiningTable();
            t.setId(selectedTableId);
            t.setCode(code);
            t.setName(name);
            t.setArea(area);
            t.setStatus(status);
            t.setActive(true);

            if (selectedTableId == 0) {
                tableDAO.insert(t);
                UIUtils.info(this, "Thêm bàn mới vào sơ đồ thành công!");
            } else {
                tableDAO.update(t);
                UIUtils.info(this, "Cập nhật thông tin bàn thành công!");
            }

            clearForm();
            loadTables();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleDelete() {
        if (selectedTableId == 0) {
            UIUtils.warning(this, "Vui lòng chọn một bàn cần xóa từ bảng.");
            return;
        }

        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn xóa bàn này khỏi sơ đồ?", "Xác nhận xóa")) {
            try {
                tableDAO.delete(selectedTableId);
                UIUtils.info(this, "Xóa bàn thành công!");
                clearForm();
                loadTables();
            } catch (Exception e) {
                UIUtils.error(this, new Exception("Không thể xóa bàn đã phát sinh hóa đơn bán hàng."));
            }
        }
    }

    private void clearForm() {
        selectedTableId = 0;
        txtCode.setText("");
        txtName.setText("");
        cboArea.setSelectedIndex(0);
        cboStatus.setSelectedIndex(0);
        table.clearSelection();
        txtCode.requestFocus();
    }
}

package com.coffeeland.util;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableModel;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Tiện ích xuất dữ liệu từ bảng JTable ra tệp Excel (CSV UTF-8).
 */
public final class ExcelExporter {

    private ExcelExporter() {
    }

    /**
     * Xuất dữ liệu từ JTable ra file CSV hỗ trợ tiếng Việt trên Microsoft Excel.
     * @param parent Cửa sổ cha để hiển thị hộp thoại
     * @param table JTable chứa dữ liệu cần xuất
     * @param defaultFileName Tên tệp mặc định (Ví dụ: "Danh_sach_hoa_don")
     */
    public static void exportTableToExcel(Component parent, JTable table, String defaultFileName) {
        if (table.getRowCount() == 0) {
            UIUtils.warning(parent, "Bảng dữ liệu đang trống, không có dữ liệu để xuất.");
            return;
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String initialName = defaultFileName + "_" + timeStamp + ".csv";

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn vị trí lưu tệp Excel / CSV");
        fileChooser.setSelectedFile(new File(initialName));
        fileChooser.setFileFilter(new FileNameExtensionFilter("Tệp Excel / CSV (*.csv)", "csv"));

        int userSelection = fileChooser.showSaveDialog(parent);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".csv");
            }

            try (FileOutputStream fos = new FileOutputStream(fileToSave);
                 OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                 PrintWriter pw = new PrintWriter(osw)) {

                // Ghi byte UTF-8 BOM để Microsoft Excel tự động nhận diện đúng tiếng Việt
                fos.write(0xEF);
                fos.write(0xBB);
                fos.write(0xBF);

                TableModel model = table.getModel();
                int colCount = model.getColumnCount();
                int rowCount = model.getRowCount();

                // 1. Ghi dòng Header
                for (int c = 0; c < colCount; c++) {
                    String colName = table.getColumnName(c);
                    pw.print(escapeCsv(colName));
                    if (c < colCount - 1) pw.print(",");
                }
                pw.println();

                // 2. Ghi từng dòng dữ liệu
                for (int r = 0; r < rowCount; r++) {
                    for (int c = 0; c < colCount; c++) {
                        Object val = model.getValueAt(r, c);
                        String strVal = (val != null) ? val.toString() : "";
                        pw.print(escapeCsv(strVal));
                        if (c < colCount - 1) pw.print(",");
                    }
                    pw.println();
                }

                pw.flush();

                int opt = JOptionPane.showConfirmDialog(
                        parent,
                        "Xuất tệp Excel thành công!\nĐường dẫn: " + fileToSave.getAbsolutePath() + "\n\nBạn có muốn mở tệp ngay bây giờ?",
                        "Xuất Excel thành công",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE
                );

                if (opt == JOptionPane.YES_OPTION && Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(fileToSave);
                }

            } catch (Exception e) {
                UIUtils.error(parent, new Exception("Lỗi khi xuất tệp: " + e.getMessage()));
            }
        }
    }

    private static String escapeCsv(String value) {
        if (value == null) return "\"\"";
        // Thay thế ký tự nháy kép " thành ""
        String escaped = value.replace("\"", "\"\"");
        return "\"" + escaped + "\"";
    }
}

package com.coffeeland.ui;

import com.coffeeland.dao.CategoryDAO;
import com.coffeeland.dao.CustomerDAO;
import com.coffeeland.dao.DiningTableDAO;
import com.coffeeland.dao.InvoiceDAO;
import com.coffeeland.dao.ProductDAO;
import com.coffeeland.model.CartItem;
import com.coffeeland.model.Category;
import com.coffeeland.model.Customer;
import com.coffeeland.model.DiningTable;
import com.coffeeland.model.Product;
import com.coffeeland.model.User;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Màn hình Bán hàng tại quầy (POS) hiện đại:
 * - Lưới thẻ món ăn / đồ uống trực quan (Product Card Grid 1-touch).
 * - Bộ lọc danh mục dạng nút bấm tròn (Pills).
 * - Tìm kiếm món nhanh tức thì.
 * - Quản lý giỏ hàng theo từng bàn & đổi điểm tích lũy.
 */
public class SalesPanel extends JPanel {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();
    private final InvoiceDAO invoiceDAO = new InvoiceDAO();
    private final DiningTableDAO tableDAO = new DiningTableDAO();

    private final User currentUser;
    private final Runnable afterSaleCallback;

    // Giỏ hàng theo từng bàn: Map<TableID, List<CartItem>>
    private final Map<Integer, List<CartItem>> tableCarts = new HashMap<>();

    // Danh sách dữ liệu bộ nhớ đệm
    private List<Product> cachedProducts = new ArrayList<>();
    private List<Category> cachedCategories = new ArrayList<>();
    private int selectedCategoryId = 0; // 0 = Tất cả

    // Component bàn & tìm kiếm
    private final JComboBox<DiningTable> cboTables = new JComboBox<>();
    private final JButton btnSwitchTable = UIUtils.createSecondaryButton("Chuyển bàn");
    private final JTextField txtSearchProduct = new JTextField(16);

    // Component vùng chọn món (Cards Grid)
    private final JPanel categoryPillPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
    private final JPanel productGridPanel = new JPanel();
    private final JScrollPane productGridScroll = new JScrollPane(productGridPanel);

    // Bảng giỏ hàng
    private final DefaultTableModel cartTableModel = new DefaultTableModel(
            new String[]{"STT", "Tên món", "Tùy chọn / Ghi chú", "Đơn giá", "SL", "Thành tiền"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable cartTable = new JTable(cartTableModel);

    // Component thanh toán
    private final JComboBox<Customer> cboCustomers = new JComboBox<>();
    private final JCheckBox chkUsePoints = new JCheckBox("Dùng điểm tích lũy (0 ₫)");
    private final JLabel lblSubtotal = new JLabel("0 ₫");
    private final JTextField txtDiscount = new JTextField("0");
    private final JComboBox<String> cboPaymentMethod = new JComboBox<>(new String[]{"Tiền mặt", "Chuyển khoản QR", "Thẻ ATM / Visa"});
    private final JTextField txtCustomerMoney = new JTextField();
    private final JLabel lblChangeTitle = new JLabel("Tiền thối:");
    private final JLabel lblChangeMoney = new JLabel("0 ₫");
    private final JLabel lblTotal = new JLabel("0 ₫");
    private final JLabel lblCartHeader = new JLabel("GIỎ HÀNG");
    private double currentCalculatedTotal = 0;

    public SalesPanel(User user, Runnable afterSaleCallback) {
        this.currentUser = user;
        this.afterSaleCallback = afterSaleCallback;

        setLayout(new BorderLayout(14, 12));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(14, 16, 14, 16));

        initUI();
        loadData();
    }

    private void initUI() {
        // 1. Header trên cùng: Tiêu đề + Chọn bàn + Tìm kiếm món
        JPanel topBar = new JPanel(new BorderLayout(12, 0));
        topBar.setOpaque(false);

        JLabel lblTitle = new JLabel("BÁN HÀNG & THU NGÂN (POS)");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        topBar.add(lblTitle, BorderLayout.WEST);

        // Khung điều khiển bàn & tìm kiếm bên phải
        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        topControls.setOpaque(false);

        JLabel lblTable = new JLabel("Bàn:");
        lblTable.setFont(UIUtils.FONT_BODY_BOLD);
        topControls.add(lblTable);

        cboTables.setPreferredSize(new Dimension(190, 34));
        topControls.add(cboTables);
        topControls.add(btnSwitchTable);

        topControls.add(Box.createHorizontalStrut(8));
        JLabel lblSearch = new JLabel("🔍");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        topControls.add(lblSearch);
        txtSearchProduct.setPreferredSize(new Dimension(180, 34));
        txtSearchProduct.putClientProperty("JTextField.placeholderText", "Tìm món đồ uống...");
        topControls.add(txtSearchProduct);

        topBar.add(topControls, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // 2. Vùng trung tâm: Bên trái là Menu Thẻ Món (Grid), Bên phải là Giỏ hàng & Thanh toán
        JPanel centerContainer = new JPanel(new BorderLayout(14, 0));
        centerContainer.setOpaque(false);

        // --- CỘT TRÁI: LƯỚI THẺ MÓN & BỘ LỌC DANH MỤC ---
        JPanel menuContainer = new JPanel(new BorderLayout(0, 8));
        menuContainer.setOpaque(false);

        // Thanh Pill Buttons danh mục
        categoryPillPanel.setOpaque(false);
        JScrollPane pillScroll = new JScrollPane(categoryPillPanel);
        pillScroll.setBorder(null);
        pillScroll.setOpaque(false);
        pillScroll.getViewport().setOpaque(false);
        pillScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        pillScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        pillScroll.setPreferredSize(new Dimension(0, 44));
        menuContainer.add(pillScroll, BorderLayout.NORTH);

        // Lưới thẻ món ăn
        productGridPanel.setBackground(UIUtils.BG_MAIN);
        productGridPanel.setLayout(new GridLayout(0, 3, 10, 10)); // 3 cột thẻ

        productGridScroll.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(8, 8, 8, 8)
        ));
        productGridScroll.setBackground(UIUtils.BG_MAIN);
        productGridScroll.getViewport().setBackground(UIUtils.BG_MAIN);
        productGridScroll.getVerticalScrollBar().setUnitIncrement(16);

        menuContainer.add(productGridScroll, BorderLayout.CENTER);
        centerContainer.add(menuContainer, BorderLayout.CENTER);

        // --- CỘT PHẢI: GIỎ HÀNG & THANH TOÁN (POS BILLING) ---
        JPanel rightContainer = new JPanel(new BorderLayout(0, 10));
        rightContainer.setOpaque(false);
        rightContainer.setPreferredSize(new Dimension(460, 0));

        // 2.1. Thẻ Giỏ hàng
        JPanel cartCard = UIUtils.createCardPanel(null);
        cartCard.setLayout(new BorderLayout(0, 8));

        JPanel cartHeader = new JPanel(new BorderLayout());
        cartHeader.setOpaque(false);
        lblCartHeader.setFont(UIUtils.FONT_HEADER);
        lblCartHeader.setForeground(UIUtils.PRIMARY_COLOR);
        cartHeader.add(lblCartHeader, BorderLayout.WEST);

        cartCard.add(cartHeader, BorderLayout.NORTH);

        UIUtils.styleTable(cartTable);
        cartTable.setRowHeight(30);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        cartTable.getColumnModel().getColumn(0).setPreferredWidth(32);
        cartTable.getColumnModel().getColumn(0).setCellRenderer(center);
        cartTable.getColumnModel().getColumn(4).setPreferredWidth(40);
        cartTable.getColumnModel().getColumn(4).setCellRenderer(center);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        cartTable.getColumnModel().getColumn(3).setPreferredWidth(75);
        cartTable.getColumnModel().getColumn(3).setCellRenderer(right);
        cartTable.getColumnModel().getColumn(5).setPreferredWidth(90);
        cartTable.getColumnModel().getColumn(5).setCellRenderer(right);

        cartTable.getColumnModel().getColumn(1).setPreferredWidth(125);
        cartTable.getColumnModel().getColumn(2).setPreferredWidth(120);

        // Nhấp đúp vào dòng món để mở tùy chọn pha chế
        cartTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && cartTable.getSelectedRow() >= 0) {
                    openItemNoteDialog();
                }
            }
        });

        JScrollPane cartScroll = new JScrollPane(cartTable);
        cartScroll.setPreferredSize(new Dimension(0, 160));
        cartCard.add(cartScroll, BorderLayout.CENTER);

        // Nút thao tác nhanh giỏ hàng (+, -, tùy chọn, xóa)
        JPanel cartActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        cartActions.setOpaque(false);

        JButton btnNote = UIUtils.createCustomButton("Tùy chọn món", new Color(180, 100, 30), new Color(150, 80, 20), Color.WHITE);
        btnNote.setToolTipText("Chọn mức đường, đá hoặc ghi chú pha chế cho món (hoặc nhấp đúp dòng)");
        JButton btnInc = UIUtils.createSecondaryButton("+ Tăng");
        JButton btnDec = UIUtils.createSecondaryButton("- Giảm");
        JButton btnRemove = UIUtils.createDangerButton("Xóa món");
        JButton btnClear = UIUtils.createSecondaryButton("Xóa hết");

        btnNote.addActionListener(e -> openItemNoteDialog());
        btnInc.addActionListener(e -> adjustCartQuantity(1));
        btnDec.addActionListener(e -> adjustCartQuantity(-1));
        btnRemove.addActionListener(e -> removeSelectedCartItem());
        btnClear.addActionListener(e -> clearCurrentCart());

        cartActions.add(btnNote);
        cartActions.add(btnInc);
        cartActions.add(btnDec);
        cartActions.add(btnRemove);
        cartActions.add(btnClear);
        cartCard.add(cartActions, BorderLayout.SOUTH);

        rightContainer.add(cartCard, BorderLayout.CENTER);

        // 2.2. Thẻ Thanh toán (Billing Form)
        JPanel payCard = UIUtils.createCardPanel("THANH TOÁN ĐƠN HÀNG");
        payCard.setPreferredSize(new Dimension(0, 340));

        JPanel payForm = new JPanel();
        payForm.setOpaque(false);
        payForm.setLayout(new BoxLayout(payForm, BoxLayout.Y_AXIS));

        // Hàng chọn khách hàng
        JPanel custRow = new JPanel(new BorderLayout(6, 0));
        custRow.setOpaque(false);
        custRow.add(cboCustomers, BorderLayout.CENTER);
        JButton btnQuickCust = UIUtils.createSecondaryButton("+ Mới");
        btnQuickCust.setToolTipText("Thêm nhanh khách hàng mới");
        btnQuickCust.addActionListener(e -> handleQuickAddCustomer());
        custRow.add(btnQuickCust, BorderLayout.EAST);

        payForm.add(UIUtils.formRow("Khách hàng:", custRow));
        payForm.add(Box.createVerticalStrut(4));

        // Tích chọn đổi điểm tích lũy
        chkUsePoints.setOpaque(false);
        chkUsePoints.setFont(UIUtils.FONT_BODY_BOLD);
        chkUsePoints.setForeground(UIUtils.PRIMARY_COLOR);
        chkUsePoints.addActionListener(e -> calculateTotals());
        payForm.add(chkUsePoints);
        payForm.add(Box.createVerticalStrut(4));

        // Tạm tính & Giảm giá
        JPanel rowCalc1 = new JPanel(new GridLayout(1, 2, 8, 0));
        rowCalc1.setOpaque(false);
        lblSubtotal.setFont(UIUtils.FONT_BODY_BOLD);
        rowCalc1.add(UIUtils.formRow("Tạm tính:", lblSubtotal));
        rowCalc1.add(UIUtils.formRow("Giảm giá:", txtDiscount));
        payForm.add(rowCalc1);
        payForm.add(Box.createVerticalStrut(4));

        // Hình thức thanh toán & Tiền khách đưa
        JPanel rowCalc2 = new JPanel(new GridLayout(1, 2, 8, 0));
        rowCalc2.setOpaque(false);
        rowCalc2.add(UIUtils.formRow("Hình thức:", cboPaymentMethod));
        rowCalc2.add(UIUtils.formRow("Tiền khách đưa:", txtCustomerMoney));
        payForm.add(rowCalc2);
        payForm.add(Box.createVerticalStrut(4));

        // Dãy nút bấm nhanh mệnh giá tiền mặt
        JPanel quickCashRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        quickCashRow.setOpaque(false);

        JButton btnExact = UIUtils.createSecondaryButton("Đúng tiền");
        btnExact.setToolTipText("Khách trả vừa đủ tổng tiền đơn");
        btnExact.setPreferredSize(new Dimension(72, 24));
        btnExact.setFont(UIUtils.FONT_SMALL);

        JButton btn50k = UIUtils.createSecondaryButton("50k");
        btn50k.setPreferredSize(new Dimension(48, 24));
        btn50k.setFont(UIUtils.FONT_SMALL);

        JButton btn100k = UIUtils.createSecondaryButton("100k");
        btn100k.setPreferredSize(new Dimension(54, 24));
        btn100k.setFont(UIUtils.FONT_SMALL);

        JButton btn200k = UIUtils.createSecondaryButton("200k");
        btn200k.setPreferredSize(new Dimension(54, 24));
        btn200k.setFont(UIUtils.FONT_SMALL);

        JButton btn500k = UIUtils.createSecondaryButton("500k");
        btn500k.setPreferredSize(new Dimension(54, 24));
        btn500k.setFont(UIUtils.FONT_SMALL);

        btnExact.addActionListener(e -> txtCustomerMoney.setText(String.valueOf((long) currentCalculatedTotal)));
        btn50k.addActionListener(e -> txtCustomerMoney.setText("50000"));
        btn100k.addActionListener(e -> txtCustomerMoney.setText("100000"));
        btn200k.addActionListener(e -> txtCustomerMoney.setText("200000"));
        btn500k.addActionListener(e -> txtCustomerMoney.setText("500000"));

        quickCashRow.add(btnExact);
        quickCashRow.add(btn50k);
        quickCashRow.add(btn100k);
        quickCashRow.add(btn200k);
        quickCashRow.add(btn500k);
        payForm.add(quickCashRow);
        payForm.add(Box.createVerticalStrut(4));

        // Tổng tiền & Tiền thối
        JPanel rowCalc3 = new JPanel(new GridLayout(1, 2, 8, 0));
        rowCalc3.setOpaque(false);
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblTotal.setForeground(UIUtils.DANGER_COLOR);
        rowCalc3.add(UIUtils.formRow("TỔNG TIỀN:", lblTotal));

        lblChangeTitle.setFont(UIUtils.FONT_BODY_BOLD);
        lblChangeMoney.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblChangeMoney.setForeground(UIUtils.SUCCESS_COLOR);

        JPanel changeRow = new JPanel(new BorderLayout(6, 0));
        changeRow.setOpaque(false);
        changeRow.add(lblChangeTitle, BorderLayout.WEST);
        changeRow.add(lblChangeMoney, BorderLayout.CENTER);
        rowCalc3.add(changeRow);

        payForm.add(rowCalc3);
        payForm.add(Box.createVerticalStrut(8));

        // Nút Thanh toán to rõ nổi bật
        JButton btnCheckout = UIUtils.createPrimaryButton("THANH TOÁN & IN HÓA ĐƠN");
        btnCheckout.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCheckout.setPreferredSize(new Dimension(280, 42));
        btnCheckout.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCheckout.addActionListener(e -> handleCheckout());
        payForm.add(btnCheckout);

        payCard.add(payForm, BorderLayout.CENTER);
        rightContainer.add(payCard, BorderLayout.SOUTH);

        centerContainer.add(rightContainer, BorderLayout.EAST);
        add(centerContainer, BorderLayout.CENTER);

        // --- GÁN SỰ KIỆN ---
        cboTables.addActionListener(e -> handleTableSelectionChange());
        btnSwitchTable.addActionListener(e -> handleSwitchTable());
        cboCustomers.addActionListener(e -> updatePointsDiscountDisplay());

        txtSearchProduct.addActionListener(e -> renderProductCards());
        txtSearchProduct.getDocument().addDocumentListener(new SimpleDocumentListener(this::renderProductCards));

        txtDiscount.getDocument().addDocumentListener(new SimpleDocumentListener(this::calculateTotals));
        txtCustomerMoney.getDocument().addDocumentListener(new SimpleDocumentListener(this::calculateTotals));
    }

    public void loadData() {
        try {
            // 1. Tải danh sách bàn
            DiningTable currentTable = (DiningTable) cboTables.getSelectedItem();
            cboTables.removeAllItems();
            for (DiningTable t : tableDAO.findAll()) {
                cboTables.addItem(t);
            }
            if (currentTable != null) {
                for (int i = 0; i < cboTables.getItemCount(); i++) {
                    if (cboTables.getItemAt(i).getId() == currentTable.getId()) {
                        cboTables.setSelectedIndex(i);
                        break;
                    }
                }
            }

            // 2. Tải danh mục
            cachedCategories = categoryDAO.findAll();
            renderCategoryPills();

            // 3. Tải danh sách món đang bán
            cachedProducts = productDAO.findActive();
            renderProductCards();

            // 4. Tải danh sách khách hàng
            Customer currentCust = (Customer) cboCustomers.getSelectedItem();
            cboCustomers.removeAllItems();
            for (Customer c : customerDAO.findAll()) {
                cboCustomers.addItem(c);
            }
            if (currentCust != null) {
                for (int i = 0; i < cboCustomers.getItemCount(); i++) {
                    if (cboCustomers.getItemAt(i).getId() == currentCust.getId()) {
                        cboCustomers.setSelectedIndex(i);
                        break;
                    }
                }
            }

            renderCartTable();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    /**
     * Vẽ thanh nút danh mục kiểu Pill
     */
    private void renderCategoryPills() {
        categoryPillPanel.removeAll();

        // Nút "Tất cả"
        JButton btnAll = UIUtils.createPillButton("Tất cả", selectedCategoryId == 0);
        btnAll.addActionListener(e -> {
            selectedCategoryId = 0;
            renderCategoryPills();
            renderProductCards();
        });
        categoryPillPanel.add(btnAll);

        for (Category c : cachedCategories) {
            boolean isSel = (c.getId() == selectedCategoryId);
            JButton btnCat = UIUtils.createPillButton(c.getName(), isSel);
            btnCat.addActionListener(e -> {
                selectedCategoryId = c.getId();
                renderCategoryPills();
                renderProductCards();
            });
            categoryPillPanel.add(btnCat);
        }

        categoryPillPanel.revalidate();
        categoryPillPanel.repaint();
    }

    /**
     * Vẽ lưới thẻ các món ăn / đồ uống
     */
    private void renderProductCards() {
        productGridPanel.removeAll();

        String keyword = txtSearchProduct.getText().trim().toLowerCase();

        List<Product> filtered = new ArrayList<>();
        for (Product p : cachedProducts) {
            if (selectedCategoryId > 0 && p.getCategoryId() != selectedCategoryId) {
                continue;
            }
            if (!keyword.isEmpty()) {
                boolean matchCode = p.getCode().toLowerCase().contains(keyword);
                boolean matchName = p.getName().toLowerCase().contains(keyword);
                if (!matchCode && !matchName) continue;
            }
            filtered.add(p);
        }

        if (filtered.isEmpty()) {
            productGridPanel.setLayout(new BorderLayout());
            JLabel lblEmpty = new JLabel("Không tìm thấy món phù hợp", SwingConstants.CENTER);
            lblEmpty.setFont(UIUtils.FONT_BODY);
            lblEmpty.setForeground(UIUtils.TEXT_MUTED);
            productGridPanel.add(lblEmpty, BorderLayout.CENTER);
        } else {
            productGridPanel.setLayout(new GridLayout(0, 3, 10, 10));
            for (Product p : filtered) {
                productGridPanel.add(createProductCard(p));
            }
        }

        productGridPanel.revalidate();
        productGridPanel.repaint();
    }

    /**
     * Tạo thẻ Card cho từng món đồ uống (Giao diện 1 chạm POS với hình ảnh thực đơn sắc nét)
     */
    private JPanel createProductCard(Product p) {
        JPanel card = new JPanel(new BorderLayout(0, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 12));
                g2.fillRoundRect(2, 3, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(8, 8, 8, 8)
        ));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setPreferredSize(new Dimension(175, 215));

        // 1. Nửa trên: Hình ảnh minh họa món + Tồn kho badge overlay
        JPanel imageWrapper = new JPanel(new BorderLayout());
        imageWrapper.setOpaque(false);
        imageWrapper.setPreferredSize(new Dimension(160, 100));

        // Load ảnh món (hoặc fallback)
        ImageIcon imgIcon = UIUtils.loadProductImage(p.getImage(), 158, 100);
        JLabel lblImage = new JLabel(imgIcon, SwingConstants.CENTER);
        lblImage.setLayout(new BorderLayout());
        imageWrapper.add(lblImage, BorderLayout.CENTER);

        // Badge tình trạng tồn kho góc trên bên phải
        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 4));
        badgePanel.setOpaque(false);

        JLabel lblStock;
        if (p.getStock() <= 0) {
            lblStock = UIUtils.createBadge("❌ Hết", UIUtils.DANGER_COLOR, Color.WHITE);
        } else if (p.getStock() <= 10) {
            lblStock = UIUtils.createBadge("⚠️ " + p.getStock(), UIUtils.WARNING_COLOR, Color.WHITE);
        } else {
            lblStock = UIUtils.createBadge("✔ " + p.getStock(), UIUtils.SUCCESS_COLOR, Color.WHITE);
        }
        badgePanel.add(lblStock);
        lblImage.add(badgePanel, BorderLayout.NORTH);

        card.add(imageWrapper, BorderLayout.NORTH);

        // 2. Nửa dưới: Tên món + Mã món + Giá bán + Nút +
        JPanel infoPanel = new JPanel(new BorderLayout(4, 4));
        infoPanel.setOpaque(false);

        // Tên món (tối đa 2 dòng)
        JLabel lblName = new JLabel("<html><div style='line-height:1.2; padding-top:2px;'><b>" + p.getName() + "</b></div></html>");
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblName.setForeground(UIUtils.TEXT_DARK);
        lblName.setVerticalAlignment(SwingConstants.TOP);
        infoPanel.add(lblName, BorderLayout.CENTER);

        // Footer: Mã món (trái), Giá tiền (giữa) và Nút + (phải)
        JPanel footer = new JPanel(new BorderLayout(4, 0));
        footer.setOpaque(false);

        JLabel lblCode = new JLabel(p.getCode());
        lblCode.setFont(UIUtils.FONT_SMALL);
        lblCode.setForeground(UIUtils.TEXT_MUTED);

        JLabel lblPrice = new JLabel(UIUtils.money(p.getPrice()));
        lblPrice.setOpaque(true);
        lblPrice.setBackground(new Color(255, 243, 230));
        lblPrice.setForeground(new Color(165, 75, 15));
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPrice.setBorder(new CompoundBorder(
                new LineBorder(new Color(230, 195, 160), 1, true),
                new EmptyBorder(2, 5, 2, 5)
        ));

        // Nút + tròn cam nhanh
        JButton btnAdd = new JButton("+") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? UIUtils.ACCENT_COLOR.darker() : UIUtils.ACCENT_COLOR);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth("+")) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString("+", x, y);
                g2.dispose();
            }
        };
        btnAdd.setPreferredSize(new Dimension(26, 26));
        btnAdd.setContentAreaFilled(false);
        btnAdd.setBorderPainted(false);
        btnAdd.setFocusPainted(false);
        btnAdd.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnAdd.addActionListener(e -> addProductToCart(p, 1));
        btnAdd.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnAdd.repaint(); }
            public void mouseExited(MouseEvent e) { btnAdd.repaint(); }
        });

        footer.add(lblCode, BorderLayout.WEST);
        footer.add(lblPrice, BorderLayout.CENTER);
        footer.add(btnAdd, BorderLayout.EAST);
        infoPanel.add(footer, BorderLayout.SOUTH);

        card.add(infoPanel, BorderLayout.CENTER);

        // Hiệu ứng Hover & Sự kiện click 1 chạm thêm vào giỏ hàng
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBackground(new Color(255, 248, 238));
                card.setBorder(new CompoundBorder(
                        new LineBorder(UIUtils.ACCENT_COLOR, 2, true),
                        new EmptyBorder(7, 7, 7, 7)
                ));
                card.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBackground(Color.WHITE);
                card.setBorder(new CompoundBorder(
                        new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                        new EmptyBorder(8, 8, 8, 8)
                ));
                card.repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() != btnAdd) {
                    addProductToCart(p, 1);
                }
            }
        });

        return card;
    }

    private String getCategoryIcon(String categoryName) {
        if (categoryName == null) return "☕";
        String lower = categoryName.toLowerCase();
        if (lower.contains("cà phê") || lower.contains("coffee")) return "☕";
        if (lower.contains("trà sữa") || lower.contains("milk tea")) return "🧋";
        if (lower.contains("trà") || lower.contains("tea")) return "🍵";
        if (lower.contains("đá xay") || lower.contains("ice")) return "🍧";
        if (lower.contains("sinh tố") || lower.contains("smoothie")) return "🥤";
        if (lower.contains("nước ép") || lower.contains("juice") || lower.contains("giải khát")) return "🍹";
        if (lower.contains("bánh") || lower.contains("cake") || lower.contains("snack") || lower.contains("ăn vặt")) return "🍰";
        if (lower.contains("sữa chua") || lower.contains("yogurt")) return "🥣";
        return "☕";
    }

    private List<CartItem> getCurrentCart() {
        DiningTable table = (DiningTable) cboTables.getSelectedItem();
        int tableId = (table != null) ? table.getId() : 0;
        return tableCarts.computeIfAbsent(tableId, k -> new ArrayList<>());
    }

    private void handleTableSelectionChange() {
        DiningTable table = (DiningTable) cboTables.getSelectedItem();
        if (table != null) {
            lblCartHeader.setText("GIỎ HÀNG (" + table.getName() + " - " + table.getArea() + ")");
        } else {
            lblCartHeader.setText("GIỎ HÀNG");
        }
        renderCartTable();
    }

    private void handleSwitchTable() {
        DiningTable currentTable = (DiningTable) cboTables.getSelectedItem();
        if (currentTable == null) return;

        List<CartItem> currentCart = getCurrentCart();
        if (currentCart.isEmpty()) {
            UIUtils.warning(this, "Bàn hiện tại chưa có món nào trong giỏ để chuyển.");
            return;
        }

        try {
            List<DiningTable> allTables = tableDAO.findAll();
            JComboBox<DiningTable> targetTableCombo = new JComboBox<>(allTables.toArray(new DiningTable[0]));

            int res = JOptionPane.showConfirmDialog(
                    this,
                    new Object[]{"Chọn bàn đích muốn chuyển đến:", targetTableCombo},
                    "Chuyển bàn",
                    JOptionPane.OK_CANCEL_OPTION
            );

            if (res == JOptionPane.OK_OPTION) {
                DiningTable targetTable = (DiningTable) targetTableCombo.getSelectedItem();
                if (targetTable == null || targetTable.getId() == currentTable.getId()) {
                    UIUtils.warning(this, "Vui lòng chọn bàn đích khác với bàn hiện tại.");
                    return;
                }

                // Gộp giỏ hàng sang bàn mới
                List<CartItem> targetCart = tableCarts.computeIfAbsent(targetTable.getId(), k -> new ArrayList<>());
                targetCart.addAll(currentCart);
                currentCart.clear();

                // Cập nhật CSDL
                tableDAO.updateStatus(currentTable.getId(), "EMPTY");
                tableDAO.updateStatus(targetTable.getId(), "OCCUPIED");

                loadData();
                cboTables.setSelectedItem(targetTable);
                UIUtils.info(this, "Đã chuyển toàn bộ món sang [" + targetTable.getName() + "] thành công!");
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void addProductToCart(Product p, int qty) {
        if (p.getStock() <= 0) {
            UIUtils.warning(this, "Món '" + p.getName() + "' hiện đã hết hàng trong kho!");
            return;
        }

        List<CartItem> cartItems = getCurrentCart();

        for (CartItem item : cartItems) {
            // Chỉ cộng dồn nếu cùng món và là món tiêu chuẩn (chưa có ghi chú tùy chỉnh)
            if (item.getProduct().getId() == p.getId() && (item.getNote() == null || item.getNote().trim().isEmpty())) {
                if (item.getQuantity() + qty > p.getStock()) {
                    UIUtils.warning(this, "Tổng số lượng (" + (item.getQuantity() + qty) + ") vượt quá tồn kho (" + p.getStock() + ").");
                    return;
                }
                item.setQuantity(item.getQuantity() + qty);
                renderCartTable();
                updateTableOccupied();
                return;
            }
        }

        cartItems.add(new CartItem(p, qty));
        renderCartTable();
        updateTableOccupied();
    }

    private void openItemNoteDialog() {
        int row = cartTable.getSelectedRow();
        if (row < 0) {
            UIUtils.warning(this, "Vui lòng chọn một dòng món trong giỏ hàng để tùy chỉnh công thức pha chế (Đường, đá, ghi chú).");
            return;
        }

        List<CartItem> cartItems = getCurrentCart();
        if (row >= cartItems.size()) return;

        CartItem item = cartItems.get(row);
        Window parent = SwingUtilities.getWindowAncestor(this);
        ItemNoteDialog dlg = new ItemNoteDialog(parent, item);
        dlg.setVisible(true);

        if (dlg.isConfirmed()) {
            item.setNote(dlg.getResultNote());
            renderCartTable();
            if (row < cartTable.getRowCount()) {
                cartTable.setRowSelectionInterval(row, row);
            }
        }
    }

    private void updateTableOccupied() {
        DiningTable table = (DiningTable) cboTables.getSelectedItem();
        if (table != null && !table.isOccupied()) {
            try {
                tableDAO.updateStatus(table.getId(), "OCCUPIED");
                table.setStatus("OCCUPIED");
                cboTables.repaint();
            } catch (Exception ignored) {}
        }
    }

    private void adjustCartQuantity(int delta) {
        int row = cartTable.getSelectedRow();
        if (row < 0) {
            UIUtils.warning(this, "Vui lòng chọn một dòng món trong giỏ hàng.");
            return;
        }

        List<CartItem> cartItems = getCurrentCart();
        CartItem item = cartItems.get(row);
        int newQty = item.getQuantity() + delta;

        if (newQty <= 0) {
            cartItems.remove(row);
        } else if (newQty > item.getProduct().getStock()) {
            UIUtils.warning(this, "Số lượng vượt quá tồn kho hiện tại (" + item.getProduct().getStock() + ").");
            return;
        } else {
            item.setQuantity(newQty);
        }

        renderCartTable();
    }

    private void removeSelectedCartItem() {
        int row = cartTable.getSelectedRow();
        if (row >= 0) {
            getCurrentCart().remove(row);
            renderCartTable();
        } else {
            UIUtils.warning(this, "Vui lòng chọn một món trong giỏ để xóa.");
        }
    }

    private void clearCurrentCart() {
        List<CartItem> cart = getCurrentCart();
        if (!cart.isEmpty()) {
            cart.clear();
            renderCartTable();
        }
    }

    private void renderCartTable() {
        cartTableModel.setRowCount(0);
        List<CartItem> cartItems = getCurrentCart();
        int stt = 1;
        for (CartItem item : cartItems) {
            String note = (item.getNote() != null && !item.getNote().trim().isEmpty()) ? item.getNote().trim() : "-";
            cartTableModel.addRow(new Object[]{
                    stt++,
                    item.getProduct().getName(),
                    note,
                    UIUtils.money(item.getProduct().getPrice()),
                    item.getQuantity(),
                    UIUtils.money(item.getLineTotal())
            });
        }
        updatePointsDiscountDisplay();
        calculateTotals();
    }

    private void updatePointsDiscountDisplay() {
        Customer c = (Customer) cboCustomers.getSelectedItem();
        if (c != null && c.getPoints() > 0) {
            chkUsePoints.setText("Dùng " + c.getPoints() + " điểm (Giảm " + UIUtils.money(c.getPoints() * 1000.0) + ")");
            chkUsePoints.setEnabled(true);
        } else {
            chkUsePoints.setText("Dùng điểm tích lũy (0 ₫)");
            chkUsePoints.setSelected(false);
            chkUsePoints.setEnabled(false);
        }
    }

    private double getDiscountValue() {
        try {
            String txt = txtDiscount.getText().replaceAll("[^0-9.]", "").trim();
            return txt.isEmpty() ? 0 : Double.parseDouble(txt);
        } catch (Exception e) {
            return 0;
        }
    }

    private int getUsedPoints() {
        if (!chkUsePoints.isSelected()) return 0;
        Customer c = (Customer) cboCustomers.getSelectedItem();
        return (c != null) ? c.getPoints() : 0;
    }

    private double getCustomerGivenMoney() {
        try {
            String txt = txtCustomerMoney.getText().replaceAll("[^0-9.]", "").trim();
            return txt.isEmpty() ? 0 : Double.parseDouble(txt);
        } catch (Exception e) {
            return 0;
        }
    }

    private void calculateTotals() {
        List<CartItem> cartItems = getCurrentCart();
        double subtotal = cartItems.stream().mapToDouble(CartItem::getLineTotal).sum();
        double discount = getDiscountValue();
        double pointDiscount = getUsedPoints() * 1000.0;
        double total = Math.max(0, subtotal - discount - pointDiscount);
        currentCalculatedTotal = total;

        lblSubtotal.setText(UIUtils.money(subtotal));
        lblTotal.setText(UIUtils.money(total));

        double given = getCustomerGivenMoney();
        if (given <= 0) {
            lblChangeTitle.setText("Tiền thối:");
            lblChangeTitle.setForeground(UIUtils.TEXT_MUTED);
            lblChangeMoney.setText("0 ₫");
            lblChangeMoney.setForeground(UIUtils.TEXT_MUTED);
        } else if (given < total) {
            lblChangeTitle.setText("Khách thiếu:");
            lblChangeTitle.setForeground(UIUtils.DANGER_COLOR);
            lblChangeMoney.setText(UIUtils.money(total - given));
            lblChangeMoney.setForeground(UIUtils.DANGER_COLOR);
        } else {
            lblChangeTitle.setText("Tiền thối:");
            lblChangeTitle.setForeground(UIUtils.SUCCESS_COLOR);
            lblChangeMoney.setText(UIUtils.money(given - total));
            lblChangeMoney.setForeground(UIUtils.SUCCESS_COLOR);
        }
    }

    private void handleCheckout() {
        List<CartItem> cartItems = getCurrentCart();
        if (cartItems.isEmpty()) {
            UIUtils.warning(this, "Giỏ hàng của bàn đang trống! Vui lòng chọn món trước khi thanh toán.");
            return;
        }

        Customer selectedCust = (Customer) cboCustomers.getSelectedItem();
        Integer customerId = selectedCust != null ? selectedCust.getId() : null;
        DiningTable selectedTable = (DiningTable) cboTables.getSelectedItem();
        Integer tableId = selectedTable != null ? selectedTable.getId() : null;
        String paymentMethod = String.valueOf(cboPaymentMethod.getSelectedItem());
        double discount = getDiscountValue();
        int usedPoints = getUsedPoints();

        try {
            String invoiceCode = invoiceDAO.createInvoice(
                    customerId,
                    currentUser.getEmployeeId(),
                    tableId,
                    cartItems,
                    discount,
                    usedPoints,
                    paymentMethod
            );

            // Mở dialog xem & in hóa đơn
            Window parent = SwingUtilities.getWindowAncestor(this);
            new InvoiceDetailDialog(parent, invoiceCode).setVisible(true);

            // Xóa giỏ hàng bàn này
            cartItems.clear();
            txtDiscount.setText("0");
            txtCustomerMoney.setText("");
            lblChangeMoney.setText("0 ₫");
            chkUsePoints.setSelected(false);

            renderCartTable();
            loadData();

            if (afterSaleCallback != null) {
                afterSaleCallback.run();
            }

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleQuickAddCustomer() {
        String name = JOptionPane.showInputDialog(this, "Nhập họ tên khách hàng mới:", "Thêm nhanh khách hàng", JOptionPane.PLAIN_MESSAGE);
        if (name == null || name.trim().isEmpty()) return;

        String phone = JOptionPane.showInputDialog(this, "Nhập số điện thoại:", "Thêm nhanh khách hàng", JOptionPane.PLAIN_MESSAGE);

        try {
            Customer c = new Customer();
            c.setCode("KH" + System.currentTimeMillis() % 100000);
            c.setFullName(name.trim());
            c.setPhone(phone != null ? phone.trim() : "");
            c.setAddress("");
            c.setPoints(0);

            customerDAO.insert(c);
            loadData();

            for (int i = 0; i < cboCustomers.getItemCount(); i++) {
                if (cboCustomers.getItemAt(i).getCode().equals(c.getCode())) {
                    cboCustomers.setSelectedIndex(i);
                    break;
                }
            }

            UIUtils.info(this, "Đã thêm khách hàng mới thành công!");

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {
        private final Runnable callback;

        SimpleDocumentListener(Runnable callback) {
            this.callback = callback;
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) { callback.run(); }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) { callback.run(); }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) { callback.run(); }
    }
}

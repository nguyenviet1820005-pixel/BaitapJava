package com.coffeeland.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Model đại diện cho thông tin phiếu nhập kho.
 */
public class StockReceipt {
    private int id;
    private String code;
    private Integer employeeId;
    private String employeeName;
    private String note;
    private Timestamp createdAt;
    private double totalAmount;
    private int totalQuantity;
    private List<StockReceiptItem> items = new ArrayList<>();

    public StockReceipt() {
    }

    public StockReceipt(int id, String code, Integer employeeId, String employeeName, String note, Timestamp createdAt, double totalAmount, int totalQuantity) {
        this.id = id;
        this.code = code;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.note = note;
        this.createdAt = createdAt;
        this.totalAmount = totalAmount;
        this.totalQuantity = totalQuantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public List<StockReceiptItem> getItems() {
        return items;
    }

    public void setItems(List<StockReceiptItem> items) {
        this.items = items;
    }
}

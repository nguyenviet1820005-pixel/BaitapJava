package com.coffeeland.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Tiện ích tự động tạo bộ ảnh minh họa đồ uống & món ăn chất lượng cao cho CoffeLand.
 */
public class GenerateProductImages {

    public static void main(String[] args) {
        File outDir = new File("src/main/resources/images/products");
        if (!outDir.exists()) {
            outDir.mkdirs();
        }
        File resImagesDir = new File("src/main/resources/images");
        if (!resImagesDir.exists()) {
            resImagesDir.mkdirs();
        }

        // Danh sách thông tin vẽ ảnh cho từng món
        // Filename -> [Category, Title Line 1, Title Line 2, IconType, Color1, Color2]
        Map<String, String[]> items = new HashMap<>();

        // 1. Cà phê
        items.put("cf_den.png", new String[]{"Cà phê", "CÀ PHÊ", "ĐEN ĐÁ", "COFFEE_CUP", "#2E1A0F", "#4A2E1B"});
        items.put("cf_sua.png", new String[]{"Cà phê", "CÀ PHÊ", "SỮA ĐÁ", "COFFEE_GLASS", "#653C1F", "#A06B42"});
        items.put("bac_xiu.png", new String[]{"Cà phê", "BẠC XỈU", "SÀI GÒN", "COFFEE_GLASS", "#C49A6C", "#EAD8C0"});
        items.put("espresso.png", new String[]{"Cà phê", "ESPRESSO", "ĐẬM VỊ", "COFFEE_CUP", "#1F1209", "#3D2413"});
        items.put("americano.png", new String[]{"Cà phê", "AMERICANO", "ĐÁ", "COFFEE_GLASS", "#3A2618", "#5C3E27"});
        items.put("cappuccino.png", new String[]{"Cà phê", "CAPPUCCINO", "Ý", "COFFEE_CUP", "#6F4E37", "#9E7B66"});
        items.put("latte.png", new String[]{"Cà phê", "LATTE", "VANILLA", "COFFEE_CUP", "#8B5A2B", "#D2B48C"});
        items.put("caramel_macchiato.png", new String[]{"Cà phê", "CARAMEL", "MACCHIATO", "COFFEE_GLASS", "#B3541E", "#F39C12"});
        items.put("cf_muoi.png", new String[]{"Cà phê", "CÀ PHÊ", "MUỐI HUẾ", "COFFEE_GLASS", "#4A3525", "#8C6D58"});
        items.put("cf_cot_dua.png", new String[]{"Cà phê", "CÀ PHÊ", "CỐT DỪA", "COFFEE_GLASS", "#5D4037", "#D7CCC8"});
        items.put("cold_brew.png", new String[]{"Cà phê", "COLD BREW", "CAM SẢ", "COFFEE_GLASS", "#3E2723", "#E65100"});
        items.put("mocha.png", new String[]{"Cà phê", "MOCHA", "SOCOLA", "COFFEE_CUP", "#3E2723", "#795548"});

        // 2. Trà & Trà sữa
        items.put("tra_dao.png", new String[]{"Trà trái cây", "TRÀ ĐÀO", "CAM SẢ", "TEA_GLASS", "#E65100", "#FF9800"});
        items.put("tra_vai.png", new String[]{"Trà trái cây", "TRÀ VẢI", "HOA HỒNG", "TEA_GLASS", "#AD1457", "#E91E63"});
        items.put("tra_dau_oi.png", new String[]{"Trà trái cây", "TRÀ DÂU", "ỔI HỒNG", "TEA_GLASS", "#C2185B", "#F06292"});
        items.put("tra_xoai.png", new String[]{"Trà trái cây", "TRÀ XOÀI", "MACCHIATO", "TEA_GLASS", "#F57F17", "#FBC02D"});
        items.put("tra_buoi_hong.png", new String[]{"Trà trái cây", "TRÀ BƯỞI", "MẬT ONG", "TEA_GLASS", "#D81B60", "#FF8A80"});
        items.put("tra_sua_tc.png", new String[]{"Trà sữa", "TRÀ SỮA", "TRÂN CHÂU", "BOBA_CUP", "#6D4C41", "#8D6E63"});
        items.put("tra_sua_matcha.png", new String[]{"Trà sữa", "TRÀ SỮA", "MATCHA ĐỎ", "BOBA_CUP", "#2E7D32", "#66BB6A"});
        items.put("tra_sua_olong.png", new String[]{"Trà sữa", "TRÀ Ô LONG", "NƯỚNG", "BOBA_CUP", "#5D4037", "#A1887F"});
        items.put("hong_tra_cheese.png", new String[]{"Trà kem cheese", "HỒNG TRÀ", "KEM CHEESE", "BOBA_CUP", "#BF360C", "#FFD54F"});
        items.put("tra_sen_vang.png", new String[]{"Trà cao cấp", "TRÀ SEN", "VÀNG LONG NHÃN", "TEA_GLASS", "#F57F17", "#FFEE58"});

        // 3. Đá xay & Sinh tố
        items.put("matcha_ice.png", new String[]{"Đá xay", "MATCHA", "ĐÁ XAY", "ICE_BLENDED", "#1B5E20", "#4CAF50"});
        items.put("choco_ice.png", new String[]{"Đá xay", "SOCOLA", "CHIP ĐÁ XAY", "ICE_BLENDED", "#3E2723", "#5D4037"});
        items.put("cookie_ice.png", new String[]{"Đá xay", "COOKIE KEM", "OREO", "ICE_BLENDED", "#212121", "#757575"});
        items.put("cf_ice.png", new String[]{"Đá xay", "CÀ PHÊ", "CARAMEL XAY", "ICE_BLENDED", "#4E342E", "#FFB74D"});
        items.put("sinh_to_bo.png", new String[]{"Sinh tố", "SINH TỐ BƠ", "CỐT DỪA", "SMOOTHIE", "#33691E", "#689F38"});
        items.put("sinh_to_xoai.png", new String[]{"Sinh tố", "SINH TỐ", "XOÀI CÁT", "SMOOTHIE", "#E65100", "#FFB300"});
        items.put("sinh_to_vietquat.png", new String[]{"Sinh tố", "SINH TỐ", "VIỆT QUẤT", "SMOOTHIE", "#4A148C", "#7B1FA2"});
        items.put("sinh_to_dau.png", new String[]{"Sinh tố", "SINH TỐ", "DÂU TÂY", "SMOOTHIE", "#880E4F", "#C2185B"});

        // 4. Nước ép & Giải khát
        items.put("nuoc_cam.png", new String[]{"Nước ép", "NƯỚC CAM", "TƯƠI", "JUICE_GLASS", "#E65100", "#FF9800"});
        items.put("nuoc_duahau.png", new String[]{"Nước ép", "NƯỚC ÉP", "DƯA HẤU", "JUICE_GLASS", "#B71C1C", "#EF5350"});
        items.put("nuoc_oi_hong.png", new String[]{"Nước ép", "NƯỚC ÉP ỔI", "HỒNG TƯƠI", "JUICE_GLASS", "#C2185B", "#EC407A"});
        items.put("nuoc_tao_carot.png", new String[]{"Nước ép", "NƯỚC ÉP TÁO", "CÀ RỐT", "JUICE_GLASS", "#BF360C", "#FF7043"});
        items.put("chanh_tuyet.png", new String[]{"Giải khát", "CHANH TUYẾT", "BẠC HÀ", "JUICE_GLASS", "#1B5E20", "#81C784"});
        items.put("soda_vietquat.png", new String[]{"Soda Ý", "SODA", "VIỆT QUẤT", "JUICE_GLASS", "#0D47A1", "#29B6F6"});

        // 5. Bánh ngọt & Ăn vặt
        items.put("tiramisu.png", new String[]{"Bánh ngọt", "TIRAMISU", "CACAO Ý", "CAKE", "#3E2723", "#8D6E63"});
        items.put("cheesecake.png", new String[]{"Bánh ngọt", "CHEESECAKE", "BASQUE", "CAKE", "#E65100", "#FFD54F"});
        items.put("mousse_chanhleo.png", new String[]{"Bánh ngọt", "MOUSSE", "CHANH LEO", "CAKE", "#F57F17", "#FFF176"});
        items.put("banh_mi_bo_toi.png", new String[]{"Bánh mặn", "BÁNH MÌ", "BƠ TỎI", "PASTRY", "#D84315", "#FF8A65"});
        items.put("croissant.png", new String[]{"Bánh nướng", "CROISSANT", "BƠ PHÁP", "PASTRY", "#E65100", "#FFB74D"});
        items.put("crepe_saurien.png", new String[]{"Bánh ngọt", "CREPE", "SẦU RIÊNG", "CAKE", "#827717", "#FFF59D"});
        items.put("huong_duong.png", new String[]{"Ăn vặt", "HƯỚNG DƯƠNG", "VỊ DỪA", "SNACK", "#4E342E", "#BDBDBD"});
        items.put("kho_bo.png", new String[]{"Ăn vặt", "KHÔ BÒ", "LÁ CHANH", "SNACK", "#B71C1C", "#FF5722"});

        // 6. Sữa chua
        items.put("sua_chua_traicay.png", new String[]{"Sữa chua", "SỮA CHUA", "TRÁI CÂY", "YOGURT", "#00695C", "#4DB6AC"});
        items.put("sua_chua_duongden.png", new String[]{"Sữa chua", "SỮA CHUA", "ĐƯỜNG ĐEN", "YOGURT", "#3E2723", "#B0BEC5"});
        items.put("sua_chua_lanep.png", new String[]{"Sữa chua", "SỮA CHUA", "LÁ NẾP", "YOGURT", "#2E7D32", "#A5D6A7"});
        items.put("sua_chua_hatdac.png", new String[]{"Sữa chua", "SỮA CHUA", "HẠT ĐÁC", "YOGURT", "#E65100", "#FFE082"});

        // Default item
        items.put("default_drink.png", new String[]{"CoffeLand", "COFFEELAND", "THỰC ĐƠN", "COFFEE_CUP", "#6F4E37", "#B8860B"});

        System.out.println("Generating " + items.size() + " product images...");
        int count = 0;
        for (Map.Entry<String, String[]> entry : items.entrySet()) {
            String filename = entry.getKey();
            String[] meta = entry.getValue();
            BufferedImage img = renderCardImage(meta[0], meta[1], meta[2], meta[3], Color.decode(meta[4]), Color.decode(meta[5]));

            try {
                File target = new File(outDir, filename);
                if (target.exists()) {
                    // Giữ lại ảnh thực tế đã cắt từ menu, không ghi đè
                    continue;
                }
                ImageIO.write(img, "PNG", target);

                // Nếu là default_drink.png, lưu thêm ở root resources/images
                if ("default_drink.png".equals(filename)) {
                    ImageIO.write(img, "PNG", new File(resImagesDir, filename));
                }
                count++;
            } catch (Exception e) {
                System.err.println("Error saving image: " + filename + " - " + e.getMessage());
            }
        }
        System.out.println("Successfully generated " + count + " images in " + outDir.getAbsolutePath());
    }

    public static BufferedImage renderCardImage(String tag, String line1, String line2, String iconType, Color c1, Color c2) {
        int w = 240;
        int h = 180;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();

        // High quality rendering hints
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        // Gradient Background
        GradientPaint gp = new GradientPaint(0, 0, c1, w, h, c2);
        g.setPaint(gp);
        g.fillRect(0, 0, w, h);

        // Subtle background pattern / light circles
        g.setColor(new Color(255, 255, 255, 25));
        g.fillOval(-30, -30, 130, 130);
        g.fillOval(w - 70, h - 70, 120, 120);
        g.fillOval(w / 2 - 20, h / 2 - 20, 90, 90);

        // Draw Icon Illustration in Center
        drawIcon(g, iconType, w / 2, 70);

        // Bottom banner for text
        int bannerH = 58;
        g.setColor(new Color(0, 0, 0, 130));
        g.fillRect(0, h - bannerH, w, bannerH);
        g.setColor(new Color(255, 255, 255, 40));
        g.drawLine(0, h - bannerH, w, h - bannerH);

        // Top tag badge
        g.setColor(new Color(255, 255, 255, 220));
        g.fillRoundRect(10, 10, 85, 20, 10, 10);
        g.setColor(new Color(40, 40, 40));
        g.setFont(new Font("Segoe UI", Font.BOLD, 10));
        g.drawString(tag.toUpperCase(), 16, 24);

        // Text titles
        g.setColor(Color.WHITE);
        g.setFont(new Font("Segoe UI", Font.BOLD, 14));
        FontMetrics fm1 = g.getFontMetrics();
        int strW1 = fm1.stringWidth(line1);
        g.drawString(line1, (w - strW1) / 2, h - bannerH + 20);

        g.setColor(new Color(255, 215, 0)); // Vàng Gold
        g.setFont(new Font("Segoe UI", Font.BOLD, 13));
        FontMetrics fm2 = g.getFontMetrics();
        int strW2 = fm2.stringWidth(line2);
        g.drawString(line2, (w - strW2) / 2, h - bannerH + 40);

        g.dispose();
        return img;
    }

    private static void drawIcon(Graphics2D g, String type, int cx, int cy) {
        g.setColor(new Color(255, 255, 255, 230));

        switch (type) {
            case "COFFEE_CUP":
                // Cup
                g.fillRoundRect(cx - 24, cy - 14, 42, 34, 10, 10);
                // Handle
                g.setStroke(new BasicStroke(4f));
                g.drawArc(cx + 12, cy - 8, 18, 22, -90, 180);
                // Saucer
                g.fillRoundRect(cx - 30, cy + 18, 54, 7, 5, 5);
                // Steam
                g.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(cx - 10, cy - 24, cx - 14, cy - 32);
                g.drawLine(cx + 2, cy - 24, cx, cy - 34);
                break;

            case "COFFEE_GLASS":
            case "TEA_GLASS":
            case "JUICE_GLASS":
                // Tall glass
                int[] xPoints = {cx - 18, cx + 18, cx + 13, cx - 13};
                int[] yPoints = {cy - 28, cy - 28, cy + 24, cy + 24};
                g.fillPolygon(xPoints, yPoints, 4);
                // Ice / beverage line
                g.setColor(new Color(255, 255, 255, 120));
                g.fillRect(cx - 14, cy - 16, 28, 6);
                // Straw
                g.setColor(new Color(255, 255, 255, 240));
                g.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(cx + 4, cy + 15, cx + 18, cy - 38);
                break;

            case "BOBA_CUP":
                // Boba cup
                int[] bx = {cx - 20, cx + 20, cx + 15, cx - 15};
                int[] by = {cy - 26, cy - 26, cy + 22, cy + 22};
                g.fillPolygon(bx, by, 4);
                // Lid
                g.fillRoundRect(cx - 23, cy - 30, 46, 8, 4, 4);
                // Straw
                g.setStroke(new BasicStroke(4f));
                g.drawLine(cx, cy + 15, cx + 8, cy - 38);
                // Pearls (boba)
                g.setColor(new Color(40, 40, 40, 200));
                g.fillOval(cx - 10, cy + 10, 7, 7);
                g.fillOval(cx, cy + 12, 7, 7);
                g.fillOval(cx + 6, cy + 8, 7, 7);
                g.fillOval(cx - 6, cy + 4, 6, 6);
                break;

            case "ICE_BLENDED":
            case "SMOOTHIE":
                // Dome cup
                int[] sx = {cx - 18, cx + 18, cx + 13, cx - 13};
                int[] sy = {cy - 12, cy - 12, cy + 24, cy + 24};
                g.fillPolygon(sx, sy, 4);
                // Whipped cream dome
                g.fillArc(cx - 20, cy - 34, 40, 32, 0, 180);
                // Cherry / topping
                g.setColor(new Color(255, 60, 60));
                g.fillOval(cx - 5, cy - 38, 10, 10);
                break;

            case "CAKE":
                // Cake slice
                int[] cxp = {cx - 24, cx + 24, cx + 14, cx - 24};
                int[] cyp = {cy + 18, cy + 18, cy - 12, cy + 4};
                g.fillPolygon(cxp, cyp, 4);
                // Frosting top
                g.setColor(new Color(255, 255, 255, 200));
                g.setStroke(new BasicStroke(3f));
                g.drawLine(cx - 24, cy + 4, cx + 14, cy - 12);
                break;

            case "PASTRY":
            case "SNACK":
                // Croissant / snack shape
                g.fillRoundRect(cx - 26, cy - 10, 52, 24, 16, 16);
                g.setColor(new Color(255, 255, 255, 150));
                g.fillOval(cx - 18, cy - 16, 36, 18);
                break;

            case "YOGURT":
            default:
                // Yogurt bowl
                g.fillArc(cx - 24, cy - 18, 48, 40, 180, 180);
                g.fillRect(cx - 24, cy - 18, 48, 8);
                // Spoon
                g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(cx + 8, cy - 12, cx + 24, cy - 30);
                break;
        }
    }
}

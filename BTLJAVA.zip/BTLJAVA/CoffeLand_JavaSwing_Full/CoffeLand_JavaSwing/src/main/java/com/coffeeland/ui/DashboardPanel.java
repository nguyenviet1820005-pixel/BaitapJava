package com.coffeeland.ui;

import com.coffeeland.dao.StatsDAO;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * Màn hình Tổng quan hoạt động kinh doanh (Dashboard) tích hợp Biểu đồ Doanh thu 7 ngày và Biểu đồ Donut tỷ trọng danh mục.
 */
public class DashboardPanel extends JPanel {

    private final StatsDAO statsDAO = new StatsDAO();

    private final JLabel lblRevenueToday = new JLabel("0 ₫");
    private final JLabel lblRevenueMonth = new JLabel("0 ₫");
    private final JLabel lblOrdersToday = new JLabel("0");
    private final JLabel lblProducts = new JLabel("0");
    private final JLabel lblLowStock = new JLabel("0");

    private final RevenueChartPanel revenueChart = new RevenueChartPanel();
    private final CategoryRevenueChartPanel categoryChart = new CategoryRevenueChartPanel();

    private final DefaultTableModel topProductsModel = new DefaultTableModel(
            new String[]{"TOP", "Mã", "Tên món", "Danh mục", "Đã bán", "Doanh thu"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable topProductsTable = new JTable(topProductsModel);

    public DashboardPanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        refresh();
    }

    private void initUI() {
        // 1. Thanh tiêu đề và nút làm mới
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JLabel lblTitle = new JLabel("TỔNG QUAN HOẠT ĐỘNG KINH DOANH");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);

        JButton btnRefresh = UIUtils.createPrimaryButton("Làm mới số liệu");
        btnRefresh.addActionListener(e -> refresh());

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(btnRefresh, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // 2. Nội dung cuộn chính
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);

        // Lưới 5 thẻ KPI đầu trang
        JPanel cardsGrid = new JPanel(new GridLayout(1, 5, 12, 12));
        cardsGrid.setOpaque(false);
        cardsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));

        cardsGrid.add(UIUtils.createKpiCard("Doanh thu hôm nay", lblRevenueToday, "Doanh thu trong ngày", UIUtils.SUCCESS_COLOR, "VNĐ"));
        cardsGrid.add(UIUtils.createKpiCard("Doanh thu tháng này", lblRevenueMonth, "Tổng thu tháng hiện tại", UIUtils.INFO_COLOR, "THÁNG"));
        cardsGrid.add(UIUtils.createKpiCard("Đơn hôm nay", lblOrdersToday, "Số hóa đơn hoàn thành", UIUtils.WARNING_COLOR, "ĐƠN"));
        cardsGrid.add(UIUtils.createKpiCard("Sản phẩm kinh doanh", lblProducts, "Món đang mở bán", UIUtils.PRIMARY_COLOR, "MÓN"));
        cardsGrid.add(UIUtils.createKpiCard("Cảnh báo tồn kho", lblLowStock, "Tồn kho ≤ 10 sản phẩm", UIUtils.DANGER_COLOR, "!"));

        contentPanel.add(cardsGrid);
        contentPanel.add(Box.createVerticalStrut(14));

        // Lưới 2 biểu đồ: Cột 7 ngày + Donut tỷ trọng danh mục
        JPanel chartsGrid = new JPanel(new GridLayout(1, 2, 14, 0));
        chartsGrid.setOpaque(false);
        chartsGrid.setPreferredSize(new Dimension(0, 260));
        chartsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));

        JPanel chartCard1 = UIUtils.createCardPanel("DOANH THU 7 NGÀY GẦN NHẤT");
        chartCard1.add(revenueChart, BorderLayout.CENTER);
        chartsGrid.add(chartCard1);

        JPanel chartCard2 = UIUtils.createCardPanel("TỶ TRỌNG DOANH THU THEO DANH MỤC");
        chartCard2.add(categoryChart, BorderLayout.CENTER);
        chartsGrid.add(chartCard2);

        contentPanel.add(chartsGrid);
        contentPanel.add(Box.createVerticalStrut(14));

        // Bảng Top 5 món bán chạy nhất
        JPanel topTableCard = UIUtils.createCardPanel("TOP 5 SẢN PHẨM BÁN CHẠY NHẤT");
        UIUtils.styleTable(topProductsTable);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        topProductsTable.getColumnModel().getColumn(0).setPreferredWidth(55);
        topProductsTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        topProductsTable.getColumnModel().getColumn(1).setPreferredWidth(75);
        topProductsTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        topProductsTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        topProductsTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        topProductsTable.getColumnModel().getColumn(4).setPreferredWidth(85);
        topProductsTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        topProductsTable.getColumnModel().getColumn(5).setPreferredWidth(110);
        topProductsTable.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);

        JScrollPane scrollTable = new JScrollPane(topProductsTable);
        scrollTable.setPreferredSize(new Dimension(0, 170));
        topTableCard.add(scrollTable, BorderLayout.CENTER);

        contentPanel.add(topTableCard);

        JScrollPane mainScroll = new JScrollPane(contentPanel);
        mainScroll.setBorder(null);
        mainScroll.setOpaque(false);
        mainScroll.getViewport().setOpaque(false);
        mainScroll.getVerticalScrollBar().setUnitIncrement(16);

        add(mainScroll, BorderLayout.CENTER);
    }

    /**
     * Làm mới toàn bộ số liệu thống kê trên Dashboard.
     */
    public void refresh() {
        try {
            // Lấy dữ liệu KPI
            Map<String, Number> stats = statsDAO.getDashboard();
            lblProducts.setText(String.valueOf(stats.getOrDefault("products", 0)));
            lblLowStock.setText(String.valueOf(stats.getOrDefault("lowStock", 0)));
            lblOrdersToday.setText(String.valueOf(stats.getOrDefault("ordersToday", 0)));
            lblRevenueToday.setText(UIUtils.money(stats.getOrDefault("revenueToday", 0).doubleValue()));
            lblRevenueMonth.setText(UIUtils.money(stats.getOrDefault("revenueMonth", 0).doubleValue()));

            // Cập nhật biểu đồ doanh thu 7 ngày
            List<Object[]> chartData = statsDAO.getRevenueLast7Days();
            revenueChart.setData(chartData);

            // Cập nhật biểu đồ Donut theo danh mục
            List<Object[]> categoryData = statsDAO.getRevenueByCategory();
            categoryChart.setData(categoryData);

            // Lấy Top 5 sản phẩm bán chạy
            topProductsModel.setRowCount(0);
            List<Object[]> topList = statsDAO.getTopSellingProducts(5);
            int rank = 1;
            String[] medals = {"🥇", "🥈", "🥉", "4️⃣", "5️⃣"};
            for (Object[] row : topList) {
                String rankStr = (rank <= 5) ? medals[rank - 1] : ("#" + rank);
                topProductsModel.addRow(new Object[]{
                        rankStr,
                        row[0],
                        row[1],
                        row[2],
                        row[3] + " ly",
                        UIUtils.money((Double) row[4])
                });
                rank++;
            }
        } catch (Exception e) {
            lblProducts.setText("-");
            lblLowStock.setText("-");
            lblOrdersToday.setText("-");
            lblRevenueToday.setText("-");
            lblRevenueMonth.setText("-");
        }
    }
}

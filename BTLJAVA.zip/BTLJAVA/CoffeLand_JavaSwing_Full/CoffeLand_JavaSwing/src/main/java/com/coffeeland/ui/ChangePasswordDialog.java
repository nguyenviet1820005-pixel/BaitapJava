package com.coffeeland.ui;

import com.coffeeland.dao.UserDAO;
import com.coffeeland.model.User;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Hộp thoại cho phép người dùng đổi mật khẩu tài khoản.
 */
public class ChangePasswordDialog extends JDialog {

    private final User user;
    private final UserDAO userDAO = new UserDAO();

    private final JPasswordField txtOldPass = new JPasswordField(20);
    private final JPasswordField txtNewPass = new JPasswordField(20);
    private final JPasswordField txtConfirmPass = new JPasswordField(20);

    public ChangePasswordDialog(Frame parent, User user) {
        super(parent, "Đổi mật khẩu - " + user.getUsername(), true);
        this.user = user;

        setSize(420, 320);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel();
        root.setBackground(UIUtils.BG_MAIN);
        root.setBorder(new EmptyBorder(20, 24, 20, 24));
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("ĐỔI MẬT KHẨU TÀI KHOẢN");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(UIUtils.PRIMARY_COLOR);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel userLabel = new JLabel("Tài khoản: " + user.getUsername());
        userLabel.setFont(UIUtils.FONT_BODY_BOLD);
        userLabel.setForeground(UIUtils.TEXT_MUTED);
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        root.add(title);
        root.add(Box.createVerticalStrut(4));
        root.add(userLabel);
        root.add(Box.createVerticalStrut(18));

        root.add(UIUtils.formRow("Mật khẩu cũ:", txtOldPass));
        root.add(Box.createVerticalStrut(10));
        root.add(UIUtils.formRow("Mật khẩu mới:", txtNewPass));
        root.add(Box.createVerticalStrut(10));
        root.add(UIUtils.formRow("Xác nhận lại:", txtConfirmPass));
        root.add(Box.createVerticalStrut(20));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        btnPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Cập nhật mật khẩu");
        JButton btnCancel = UIUtils.createSecondaryButton("Hủy bỏ");

        btnSave.addActionListener(e -> handleChangePassword());
        btnCancel.addActionListener(e -> dispose());

        btnPanel.add(btnSave);
        btnPanel.add(btnCancel);

        root.add(btnPanel);
        add(root, BorderLayout.CENTER);
    }

    private void handleChangePassword() {
        String oldPass = new String(txtOldPass.getPassword()).trim();
        String newPass = new String(txtNewPass.getPassword()).trim();
        String confirmPass = new String(txtConfirmPass.getPassword()).trim();

        if (oldPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
            UIUtils.warning(this, "Vui lòng điền đầy đủ các thông tin mật khẩu.");
            return;
        }

        if (newPass.length() < 4) {
            UIUtils.warning(this, "Mật khẩu mới phải có ít nhất 4 ký tự.");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            UIUtils.warning(this, "Mật khẩu mới và mật khẩu xác nhận không trùng khớp.");
            return;
        }

        try {
            boolean success = userDAO.changePassword(user.getId(), oldPass, newPass);
            if (success) {
                UIUtils.info(this, "Đổi mật khẩu thành công! Hãy ghi nhớ mật khẩu mới của bạn.");
                dispose();
            } else {
                UIUtils.warning(this, "Mật khẩu cũ không chính xác. Vui lòng thử lại.");
                txtOldPass.requestFocus();
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }
}

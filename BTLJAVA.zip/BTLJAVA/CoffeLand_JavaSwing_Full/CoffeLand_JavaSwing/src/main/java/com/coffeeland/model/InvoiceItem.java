package com.coffeeland.model;

/**
 * Model đại diện cho chi tiết một món hàng trong hóa đơn.
 */
public class InvoiceItem {
    private int id;
    private int invoiceId;
    private int productId;
    private String productCode;
    private String productName;
    private String unit;
    private int quantity;
    private double unitPrice;
    private double lineTotal;
    private String note = "";

    public InvoiceItem() {
    }

    public InvoiceItem(int id, int invoiceId, int productId, String productCode, String productName, String unit, int quantity, double unitPrice, double lineTotal) {
        this(id, invoiceId, productId, productCode, productName, unit, quantity, unitPrice, lineTotal, "");
    }

    public InvoiceItem(int id, int invoiceId, int productId, String productCode, String productName, String unit, int quantity, double unitPrice, double lineTotal, String note) {
        this.id = id;
        this.invoiceId = invoiceId;
        this.productId = productId;
        this.productCode = productCode;
        this.productName = productName;
        this.unit = unit;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.lineTotal = lineTotal;
        this.note = (note != null) ? note.trim() : "";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getLineTotal() {
        return lineTotal;
    }

    public void setLineTotal(double lineTotal) {
        this.lineTotal = lineTotal;
    }

    public String getNote() {
        return note != null ? note : "";
    }

    public void setNote(String note) {
        this.note = (note != null) ? note.trim() : "";
    }
}

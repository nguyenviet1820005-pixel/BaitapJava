package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Nhân viên (Employees).
 */
public class EmployeeDAO {

    private Employee mapResultSet(ResultSet rs) throws SQLException {
        Employee e = new Employee();
        e.setId(rs.getInt("id"));
        e.setCode(rs.getString("code"));
        e.setFullName(rs.getString("full_name"));
        e.setPhone(rs.getString("phone"));
        e.setEmail(rs.getString("email"));
        e.setPosition(rs.getString("position"));
        e.setActive(rs.getBoolean("active"));
        
        // Lấy username liên kết nếu có (trong câu query JOIN)
        try {
            e.setUsername(rs.getString("username"));
        } catch (SQLException ignored) {
            // Đề phòng trường hợp query không join bảng users
        }
        return e;
    }

    /**
     * Lấy danh sách nhân viên theo từ khóa tìm kiếm.
     */
    public List<Employee> findAll(String keyword) throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT e.*, u.username FROM employees e " +
                     "LEFT JOIN users u ON e.id = u.employee_id " +
                     "WHERE e.code LIKE ? OR e.full_name LIKE ? OR e.phone LIKE ? " +
                     "ORDER BY e.id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String k = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            ps.setString(1, k);
            ps.setString(2, k);
            ps.setString(3, k);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    /**
     * Lấy tất cả nhân viên.
     */
    public List<Employee> findAll() throws SQLException {
        return findAll("");
    }

    /**
     * Kiểm tra mã nhân viên đã tồn tại hay chưa.
     */
    public boolean isCodeExists(String code, int excludeId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM employees WHERE code = ? AND id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code.trim());
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Thêm mới nhân viên.
     */
    public void insert(Employee e) throws SQLException {
        String sql = "INSERT INTO employees(code, full_name, phone, email, position, active) VALUES(?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, e.getCode().trim().toUpperCase());
            ps.setString(2, e.getFullName().trim());
            ps.setString(3, e.getPhone() != null ? e.getPhone().trim() : "");
            ps.setString(4, e.getEmail() != null ? e.getEmail().trim() : "");
            ps.setString(5, e.getPosition() != null ? e.getPosition().trim() : "Nhân viên");
            ps.setBoolean(6, e.isActive());
            ps.executeUpdate();
        }
    }

    /**
     * Cập nhật thông tin nhân viên.
     */
    public void update(Employee e) throws SQLException {
        String sql = "UPDATE employees SET code = ?, full_name = ?, phone = ?, email = ?, position = ?, active = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, e.getCode().trim().toUpperCase());
            ps.setString(2, e.getFullName().trim());
            ps.setString(3, e.getPhone() != null ? e.getPhone().trim() : "");
            ps.setString(4, e.getEmail() != null ? e.getEmail().trim() : "");
            ps.setString(5, e.getPosition() != null ? e.getPosition().trim() : "Nhân viên");
            ps.setBoolean(6, e.isActive());
            ps.setInt(7, e.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Xóa nhân viên theo ID.
     */
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

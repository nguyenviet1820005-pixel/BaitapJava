package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.User;
import com.coffeeland.util.PasswordUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Tài khoản người dùng (Users).
 */
public class UserDAO {

    /**
     * Xác thực đăng nhập người dùng.
     * @param username Tên đăng nhập
     * @param password Mật khẩu gốc
     * @return Đối tượng User nếu đăng nhập đúng, hoặc null nếu sai
     */
    public User login(String username, String password) throws SQLException {
        String sql = "SELECT u.id, u.username, u.role, u.employee_id, u.active, e.full_name " +
                     "FROM users u " +
                     "LEFT JOIN employees e ON u.employee_id = e.id " +
                     "WHERE u.username = ? AND u.password_hash = ? AND u.active = 1";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username.trim());
            ps.setString(2, PasswordUtils.sha256(password));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setRole(rs.getString("role"));
                    int empId = rs.getInt("employee_id");
                    user.setEmployeeId(rs.wasNull() ? null : empId);
                    user.setEmployeeName(rs.getString("full_name"));
                    user.setActive(rs.getBoolean("active"));
                    return user;
                }
            }
        }
        return null;
    }

    /**
     * Đổi mật khẩu cho người dùng.
     * @param userId ID người dùng
     * @param oldPassword Mật khẩu cũ
     * @param newPassword Mật khẩu mới
     * @return true nếu đổi thành công, false nếu sai mật khẩu cũ
     */
    public boolean changePassword(int userId, String oldPassword, String newPassword) throws SQLException {
        String checkSql = "SELECT id FROM users WHERE id = ? AND password_hash = ?";
        String updateSql = "UPDATE users SET password_hash = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setInt(1, userId);
                checkPs.setString(2, PasswordUtils.sha256(oldPassword));
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (!rs.next()) {
                        return false; // Mật khẩu cũ không chính xác
                    }
                }
            }

            try (PreparedStatement updatePs = conn.prepareStatement(updateSql)) {
                updatePs.setString(1, PasswordUtils.sha256(newPassword));
                updatePs.setInt(2, userId);
                return updatePs.executeUpdate() > 0;
            }
        }
    }

    /**
     * Lấy danh sách tất cả tài khoản người dùng trong hệ thống (dành cho Admin).
     */
    public List<User> findAll() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT u.id, u.username, u.role, u.employee_id, u.active, e.full_name " +
                     "FROM users u " +
                     "LEFT JOIN employees e ON u.employee_id = e.id " +
                     "ORDER BY u.id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setRole(rs.getString("role"));
                int empId = rs.getInt("employee_id");
                user.setEmployeeId(rs.wasNull() ? null : empId);
                user.setEmployeeName(rs.getString("full_name"));
                user.setActive(rs.getBoolean("active"));
                list.add(user);
            }
        }
        return list;
    }
}

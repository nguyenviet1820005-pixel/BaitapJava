package com.coffeeland.ui;

import com.coffeeland.model.CartItem;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Hộp thoại tùy chọn pha chế hiện đại (Chip/Pill Buttons phong cách POS chuyên nghiệp).
 * Tối ưu hiển thị không bị lỗi font biểu tượng và bố cục chuẩn chỉ cho thu ngân.
 */
public class ItemNoteDialog extends JDialog {

    private final ButtonGroup sugarGroup = new ButtonGroup();
    private final ButtonGroup iceGroup = new ButtonGroup();

    private final List<ChipToggleButton> sugarChips = new ArrayList<>();
    private final List<ChipToggleButton> iceChips = new ArrayList<>();

    private final ChipToggleButton chkSeparateIce = new ChipToggleButton("Để đá riêng", false);
    private final ChipToggleButton chkTakeAway = new ChipToggleButton("Mang về", false);
    private final ChipToggleButton chkLessMilk = new ChipToggleButton("Ít sữa", false);
    private final ChipToggleButton chkMoreMilk = new ChipToggleButton("Nhiều sữa", false);
    private final ChipToggleButton chkStrongCoffee = new ChipToggleButton("Đậm vị cà phê", false);

    private final JTextField txtCustomNote = new JTextField();
    private final JLabel lblPreview = new JLabel("Món tiêu chuẩn (Pha theo công thức chuẩn)");

    private boolean confirmed = false;
    private String resultNote = "";

    public ItemNoteDialog(Window owner, CartItem cartItem) {
        super(owner, "Tùy chọn pha chế - " + (cartItem != null && cartItem.getProduct() != null ? cartItem.getProduct().getName() : "Món"), ModalityType.APPLICATION_MODAL);
        initUI(cartItem);
    }

    private void initUI(CartItem cartItem) {
        setSize(600, 680);
        setLocationRelativeTo(getOwner());
        setResizable(false);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UIUtils.BG_MAIN);

        // 1. Header Banner
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(36, 18, 8)); // Espresso Dark
        headerPanel.setBorder(new EmptyBorder(16, 22, 16, 22));

        String prodName = (cartItem != null && cartItem.getProduct() != null) ? cartItem.getProduct().getName() : "Món đồ uống";
        String prodPrice = (cartItem != null && cartItem.getProduct() != null) ? UIUtils.money(cartItem.getProduct().getPrice()) : "";

        JLabel lblTitle = new JLabel(prodName.toUpperCase());
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblTitle.setForeground(new Color(255, 235, 215));

        JLabel lblSubtitle = new JLabel("Đơn giá: " + prodPrice + "  •  Tùy chỉnh công thức pha chế theo yêu cầu của khách");
        lblSubtitle.setFont(UIUtils.FONT_SMALL);
        lblSubtitle.setForeground(new Color(200, 180, 160));

        headerPanel.add(lblTitle, BorderLayout.NORTH);
        headerPanel.add(Box.createVerticalStrut(4), BorderLayout.CENTER);
        headerPanel.add(lblSubtitle, BorderLayout.SOUTH);
        add(headerPanel, BorderLayout.NORTH);

        // 2. Body Panel (Scrollable content)
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        contentPanel.setBorder(new EmptyBorder(14, 20, 14, 20));

        // 2.1. Nhóm Đường
        JPanel sugarSection = createSectionCard("MỨC ĐƯỜNG (ĐỘ NGỌT)");
        JPanel sugarChipsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        sugarChipsPanel.setOpaque(false);
        addChipToGroup(sugarChipsPanel, sugarGroup, sugarChips, "Chuẩn (100%)", true);
        addChipToGroup(sugarChipsPanel, sugarGroup, sugarChips, "70% đường", false);
        addChipToGroup(sugarChipsPanel, sugarGroup, sugarChips, "Ít đường (50%)", false);
        addChipToGroup(sugarChipsPanel, sugarGroup, sugarChips, "30% đường", false);
        addChipToGroup(sugarChipsPanel, sugarGroup, sugarChips, "Không đường (0%)", false);
        sugarSection.add(sugarChipsPanel, BorderLayout.CENTER);
        contentPanel.add(sugarSection);
        contentPanel.add(Box.createVerticalStrut(12));

        // 2.2. Nhóm Đá
        JPanel iceSection = createSectionCard("MỨC ĐÁ (LƯỢNG ĐÁ / NHIỆT ĐỘ)");
        JPanel iceChipsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        iceChipsPanel.setOpaque(false);
        addChipToGroup(iceChipsPanel, iceGroup, iceChips, "Chuẩn (100%)", true);
        addChipToGroup(iceChipsPanel, iceGroup, iceChips, "70% đá", false);
        addChipToGroup(iceChipsPanel, iceGroup, iceChips, "Ít đá (50%)", false);
        addChipToGroup(iceChipsPanel, iceGroup, iceChips, "Không đá", false);
        addChipToGroup(iceChipsPanel, iceGroup, iceChips, "Uống nóng", false);
        iceSection.add(iceChipsPanel, BorderLayout.CENTER);
        contentPanel.add(iceSection);
        contentPanel.add(Box.createVerticalStrut(12));

        // 2.3. Yêu cầu thêm (Chọn nhanh)
        JPanel extraSection = createSectionCard("YÊU CẦU THÊM (CHỌN NHANH)");
        JPanel extraChipsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        extraChipsPanel.setOpaque(false);

        chkSeparateIce.addActionListener(e -> updatePreview());
        chkTakeAway.addActionListener(e -> updatePreview());
        chkLessMilk.addActionListener(e -> updatePreview());
        chkMoreMilk.addActionListener(e -> updatePreview());
        chkStrongCoffee.addActionListener(e -> updatePreview());

        extraChipsPanel.add(chkSeparateIce);
        extraChipsPanel.add(chkTakeAway);
        extraChipsPanel.add(chkLessMilk);
        extraChipsPanel.add(chkMoreMilk);
        extraChipsPanel.add(chkStrongCoffee);
        extraSection.add(extraChipsPanel, BorderLayout.CENTER);
        contentPanel.add(extraSection);
        contentPanel.add(Box.createVerticalStrut(12));

        // 2.4. Ghi chú tự do
        JPanel noteSection = createSectionCard("GHI CHÚ RIÊNG CHO BARISTA");
        txtCustomNote.setFont(UIUtils.FONT_BODY);
        txtCustomNote.setPreferredSize(new Dimension(0, 36));
        txtCustomNote.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(4, 12, 4, 12)
        ));
        txtCustomNote.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updatePreview(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updatePreview(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updatePreview(); }
        });
        noteSection.add(txtCustomNote, BorderLayout.CENTER);
        contentPanel.add(noteSection);
        contentPanel.add(Box.createVerticalStrut(12));

        // 2.5. Xem trước ghi chú trên Bill
        JPanel previewSection = createSectionCard("XEM TRƯỚC GHI CHÚ TRÊN PHIẾU PHA CHẾ");
        previewSection.setBackground(new Color(255, 252, 245));
        lblPreview.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblPreview.setForeground(new Color(140, 70, 20));
        lblPreview.setBorder(new EmptyBorder(4, 8, 4, 8));
        previewSection.add(lblPreview, BorderLayout.CENTER);
        contentPanel.add(previewSection);

        add(contentPanel, BorderLayout.CENTER);

        // 3. Footer Actions Panel
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 14));
        footerPanel.setBackground(Color.WHITE);
        footerPanel.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1),
                new EmptyBorder(4, 16, 4, 16)
        ));

        JButton btnClear = UIUtils.createSecondaryButton("Đặt lại mặc định");
        JButton btnCancel = UIUtils.createSecondaryButton("Hủy bỏ");
        JButton btnSave = UIUtils.createPrimaryButton("Lưu tùy chọn");

        btnClear.addActionListener(e -> resetDefaults());
        btnCancel.addActionListener(e -> {
            confirmed = false;
            dispose();
        });
        btnSave.addActionListener(e -> {
            confirmed = true;
            resultNote = compileNoteString();
            dispose();
        });

        footerPanel.add(btnClear);
        footerPanel.add(btnCancel);
        footerPanel.add(btnSave);
        add(footerPanel, BorderLayout.SOUTH);

        // Đọc ghi chú cũ nếu món đã có sẵn ghi chú
        if (cartItem != null && cartItem.getNote() != null && !cartItem.getNote().isEmpty()) {
            parseExistingNote(cartItem.getNote());
        }

        updatePreview();
    }

    private JPanel createSectionCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
                new LineBorder(new Color(225, 218, 208), 1, true),
                new EmptyBorder(10, 14, 10, 14)
        ));

        // Section Title Header
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        titlePanel.setOpaque(false);

        // Indicator bar
        JPanel indicator = new JPanel();
        indicator.setBackground(UIUtils.ACCENT_COLOR);
        indicator.setPreferredSize(new Dimension(4, 15));
        titlePanel.add(indicator);

        JLabel lblHeader = new JLabel(title);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblHeader.setForeground(new Color(80, 50, 25));
        titlePanel.add(lblHeader);

        card.add(titlePanel, BorderLayout.NORTH);
        return card;
    }

    private void addChipToGroup(JPanel container, ButtonGroup group, List<ChipToggleButton> list, String text, boolean selected) {
        ChipToggleButton chip = new ChipToggleButton(text, true);
        chip.setSelected(selected);
        chip.addActionListener(e -> updatePreview());
        group.add(chip);
        list.add(chip);
        container.add(chip);
    }

    private String getSelectedChipText(ButtonGroup group) {
        for (Enumeration<AbstractButton> buttons = group.getElements(); buttons.hasMoreElements(); ) {
            AbstractButton b = buttons.nextElement();
            if (b.isSelected()) {
                return b.getText();
            }
        }
        return "";
    }

    private void selectChipByKeyword(List<ChipToggleButton> chips, String keyword) {
        for (ChipToggleButton chip : chips) {
            if (chip.getText().toLowerCase().contains(keyword.toLowerCase())) {
                chip.setSelected(true);
                return;
            }
        }
    }

    private void parseExistingNote(String oldNote) {
        String lower = oldNote.toLowerCase();

        // Đường
        if (lower.contains("không đường") || lower.contains("0%")) {
            selectChipByKeyword(sugarChips, "không đường");
        } else if (lower.contains("ít đường") || lower.contains("50%")) {
            selectChipByKeyword(sugarChips, "ít đường");
        } else if (lower.contains("70%")) {
            selectChipByKeyword(sugarChips, "70%");
        } else if (lower.contains("30%")) {
            selectChipByKeyword(sugarChips, "30%");
        }

        // Đá
        if (lower.contains("nóng")) {
            selectChipByKeyword(iceChips, "uống nóng");
        } else if (lower.contains("không đá")) {
            selectChipByKeyword(iceChips, "không đá");
        } else if (lower.contains("ít đá")) {
            selectChipByKeyword(iceChips, "ít đá");
        } else if (lower.contains("70%")) {
            selectChipByKeyword(iceChips, "70%");
        }

        if (lower.contains("đá riêng")) chkSeparateIce.setSelected(true);
        if (lower.contains("mang về")) chkTakeAway.setSelected(true);
        if (lower.contains("ít sữa")) chkLessMilk.setSelected(true);
        if (lower.contains("nhiều sữa")) chkMoreMilk.setSelected(true);
        if (lower.contains("đậm")) chkStrongCoffee.setSelected(true);

        txtCustomNote.setText(oldNote);
    }

    private String compileNoteString() {
        List<String> parts = new ArrayList<>();

        // Đường
        String sugar = getSelectedChipText(sugarGroup);
        if (!sugar.isEmpty() && !sugar.startsWith("Chuẩn")) {
            if (sugar.contains("Ít đường")) {
                parts.add("Ít đường (50%)");
            } else if (sugar.contains("Không đường")) {
                parts.add("Không đường");
            } else {
                parts.add(sugar);
            }
        }

        // Đá
        String ice = getSelectedChipText(iceGroup);
        if (!ice.isEmpty() && !ice.startsWith("Chuẩn")) {
            if (ice.contains("Ít đá")) {
                parts.add("Ít đá (50%)");
            } else if (ice.contains("Không đá")) {
                parts.add("Không đá");
            } else if (ice.contains("Uống nóng")) {
                parts.add("Uống nóng");
            } else {
                parts.add(ice);
            }
        }

        // Yêu cầu thêm
        if (chkSeparateIce.isSelected()) parts.add("Để đá riêng");
        if (chkTakeAway.isSelected()) parts.add("Mang về");
        if (chkLessMilk.isSelected()) parts.add("Ít sữa");
        if (chkMoreMilk.isSelected()) parts.add("Nhiều sữa");
        if (chkStrongCoffee.isSelected()) parts.add("Đậm vị cà phê");

        // Ghi chú tự do
        String custom = txtCustomNote.getText().trim();
        if (!custom.isEmpty()) {
            boolean dup = false;
            for (String p : parts) {
                if (custom.equalsIgnoreCase(p)) {
                    dup = true;
                    break;
                }
            }
            if (!dup) {
                parts.add(custom);
            }
        }

        return String.join(", ", parts);
    }

    private void updatePreview() {
        String note = compileNoteString();
        if (note.isEmpty()) {
            lblPreview.setText("Món tiêu chuẩn (Pha theo công thức chuẩn)");
            lblPreview.setForeground(UIUtils.TEXT_MUTED);
        } else {
            lblPreview.setText("» " + note);
            lblPreview.setForeground(new Color(150, 50, 10));
        }
    }

    private void resetDefaults() {
        selectChipByKeyword(sugarChips, "chuẩn");
        selectChipByKeyword(iceChips, "chuẩn");
        chkSeparateIce.setSelected(false);
        chkTakeAway.setSelected(false);
        chkLessMilk.setSelected(false);
        chkMoreMilk.setSelected(false);
        chkStrongCoffee.setSelected(false);
        txtCustomNote.setText("");
        updatePreview();
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public String getResultNote() {
        return resultNote;
    }

    /**
     * Nút bấm dạng Tag / Pill Chip hiện đại, hỗ trợ trạng thái Active nổi bật.
     */
    private static class ChipToggleButton extends JToggleButton {
        private boolean isHover = false;

        public ChipToggleButton(String text, boolean singleGroup) {
            super(text);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFont(new Font("Segoe UI", Font.PLAIN, 13));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHover = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();
            boolean sel = isSelected();

            // Background
            if (sel) {
                // Nâu caramel đậm nổi bật
                g2.setColor(new Color(130, 65, 20));
            } else if (isHover) {
                g2.setColor(new Color(245, 238, 228));
            } else {
                g2.setColor(new Color(252, 250, 248));
            }
            g2.fillRoundRect(1, 1, w - 2, h - 2, 8, 8);

            // Border
            if (sel) {
                g2.setColor(new Color(90, 40, 10));
                g2.setStroke(new BasicStroke(1.5f));
            } else {
                g2.setColor(isHover ? new Color(180, 150, 120) : new Color(215, 205, 195));
                g2.setStroke(new BasicStroke(1.0f));
            }
            g2.drawRoundRect(1, 1, w - 3, h - 3, 8, 8);

            // Text
            String display = getText();
            if (sel) {
                display = "✓ " + display;
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            } else {
                g2.setColor(new Color(50, 30, 15));
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            }

            FontMetrics fm = g2.getFontMetrics();
            int strW = fm.stringWidth(display);
            int strH = fm.getAscent();
            int x = (w - strW) / 2;
            int y = (h + strH) / 2 - 2;
            g2.drawString(display, x, y);

            g2.dispose();
        }

        @Override
        public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(new Font("Segoe UI", Font.BOLD, 12));
            int textW = fm.stringWidth("✓ " + getText());
            return new Dimension(textW + 24, 34);
        }
    }
}

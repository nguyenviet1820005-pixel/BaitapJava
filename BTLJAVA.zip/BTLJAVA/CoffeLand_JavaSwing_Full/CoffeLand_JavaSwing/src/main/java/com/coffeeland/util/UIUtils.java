package com.coffeeland.util;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tiện ích định dạng giao diện, màu sắc, font chữ và các thành phần UI cho hệ thống CoffeLand.
 */
public final class UIUtils {

    // === HỆ THỐNG MÀU SẮC CHỦ ĐỀ CÀ PHÊ (COFFEE BRANDING) ===
    public static final Color PRIMARY_COLOR = new Color(55, 30, 12);       // Nâu cà phê đậm sâu, rõ nét (#371E0C)
    public static final Color PRIMARY_HOVER = new Color(36, 18, 5);        // Nâu đậm khi hover (#241205)
    public static final Color PRIMARY_LIGHT = new Color(255, 244, 232);    // Màu kem cà phê sữa sáng (#FFF4E8)
    public static final Color ACCENT_COLOR = new Color(200, 130, 60);      // Vàng caramel đậm (#C8823C)
    // Nút đăng nhập: Cam đỏ nổi bật nhất - dễ nhìn, độ tương phản cao
    public static final Color LOGIN_BTN_COLOR  = new Color(186, 32, 8);    // Cam đỏ đậm rực (#BA2008)
    public static final Color LOGIN_BTN_HOVER  = new Color(145, 18, 4);    // Cam đỏ đậm khi hover (#911204)
    public static final Color BG_MAIN = new Color(245, 242, 238);          // Nền kem ấm áp (#F5F2EE)
    public static final Color CARD_BG = Color.WHITE;                       // Nền thẻ trắng (#FFFFFF)
    public static final Color TEXT_DARK = new Color(20, 20, 20);           // Chữ đen tuyền (#141414)
    public static final Color TEXT_MUTED = new Color(90, 90, 100);         // Chữ xám đậm hơn (#5A5A64)
    public static final Color BORDER_COLOR = new Color(200, 190, 178);     // Viền nâu kem (#C8BEB2)

    // Màu trạng thái
    public static final Color SUCCESS_COLOR = new Color(24, 120, 40);      // Xanh lá thành công đậm (#187828)
    public static final Color SUCCESS_LIGHT = new Color(220, 245, 225);
    public static final Color DANGER_COLOR = new Color(185, 25, 25);       // Đỏ cảnh báo đậm (#B91919)
    public static final Color DANGER_LIGHT = new Color(255, 228, 228);
    public static final Color WARNING_COLOR = new Color(210, 90, 0);       // Cam cảnh báo đậm (#D25A00)
    public static final Color WARNING_LIGHT = new Color(255, 238, 210);
    public static final Color INFO_COLOR = new Color(0, 110, 190);         // Xanh dương thông tin đậm (#006EBE)
    public static final Color INFO_LIGHT = new Color(215, 238, 255);

    // Sidebar Theme (Espresso Dark & Luxury Coffee Vibe)
    public static final Color SIDEBAR_BG = new Color(30, 16, 8);           // Nâu Espresso cực đậm (#1E1008)
    public static final Color SIDEBAR_HOVER_BG = new Color(55, 30, 14);    // Hover mờ (#371E0E)
    public static final Color SIDEBAR_ACTIVE_BG = new Color(200, 130, 60);  // Nền kích hoạt Caramel (#C8823C)
    public static final Color SIDEBAR_TEXT_MUTED = new Color(180, 160, 145);
    public static final Color SIDEBAR_CARD_BG = new Color(44, 25, 12);     // Thẻ nền trong sidebar

    // Font chữ đồng bộ
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 15);
    public static final Font FONT_BODY = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BODY_BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 12);

    private static final DecimalFormat MONEY_FORMAT;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    private static final SimpleDateFormat SHORT_DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    static {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("vi", "VN"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        MONEY_FORMAT = new DecimalFormat("#,##0 ₫", symbols);
    }

    private UIUtils() {
    }

    /**
     * Định dạng số tiền sang định dạng tiền Việt Nam (Ví dụ: 35.000 ₫).
     */
    public static String money(double value) {
        return MONEY_FORMAT.format(value);
    }

    /**
     * Định dạng ngày giờ đầy đủ (Ví dụ: 20/08/2026 14:30).
     */
    public static String formatDateTime(Date date) {
        if (date == null) return "-";
        return DATE_FORMAT.format(date);
    }

    /**
     * Định dạng ngày ngắn (Ví dụ: 20/08/2026).
     */
    public static String formatDate(Date date) {
        if (date == null) return "-";
        return SHORT_DATE_FORMAT.format(date);
    }

    /**
     * Tùy biến bảng JTable với giao diện hiện đại: Chiều cao hàng thoáng đãng,
     * header màu thương hiệu, màu dòng xen kẽ (Zebra), hiệu ứng chọn đẹp mắt.
     */
    public static void styleTable(JTable table) {
        table.setRowHeight(32);
        table.setFont(FONT_BODY);
        table.setFillsViewportHeight(true);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setGridColor(BORDER_COLOR);
        table.setSelectionBackground(new Color(230, 218, 206));
        table.setSelectionForeground(TEXT_DARK);

        // Tùy biến Header
        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 38));
        header.setFont(FONT_BODY_BOLD);
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);

        // Renderer cho Header
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSelected, boolean hasFocus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, isSelected, hasFocus, row, col);
                l.setBackground(PRIMARY_COLOR);
                l.setForeground(Color.WHITE);
                l.setFont(FONT_BODY_BOLD);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                l.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                return l;
            }
        };
        header.setDefaultRenderer(headerRenderer);

        // Renderer cho các dòng dữ liệu xen kẽ màu (Zebra)
        DefaultTableCellRenderer zebraRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSelected, boolean hasFocus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, isSelected, hasFocus, row, col);
                l.setFont(FONT_BODY);
                l.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));

                if (!isSelected) {
                    if (row % 2 == 0) {
                        l.setBackground(Color.WHITE);
                    } else {
                        l.setBackground(new Color(250, 248, 245));
                    }
                    l.setForeground(TEXT_DARK);
                }
                return l;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(zebraRenderer);
        }
    }

    /**
     * Tạo một dòng Form chuẩn gồm Label bên trái và Component bên phải.
     */
    public static JPanel formRow(String labelText, JComponent component) {
        JPanel p = new JPanel(new BorderLayout(10, 4));
        p.setOpaque(false);
        JLabel l = new JLabel(labelText);
        l.setFont(FONT_BODY_BOLD);
        l.setForeground(TEXT_DARK);
        l.setPreferredSize(new Dimension(110, 32));
        p.add(l, BorderLayout.WEST);

        if (component instanceof JTextField || component instanceof JComboBox || component instanceof JSpinner) {
            component.setFont(FONT_BODY);
            component.setPreferredSize(new Dimension(component.getPreferredSize().width, 32));
        }
        p.add(component, BorderLayout.CENTER);
        return p;
    }

    /**
     * Tạo nút bấm có màu chủ đạo với hiệu ứng hover mượt mà.
     */
    public static JButton createPrimaryButton(String text) {
        return createCustomButton(text, PRIMARY_COLOR, PRIMARY_HOVER, Color.WHITE);
    }

    /**
     * Tạo nút Đăng nhập đặc biệt nổi bật nhất (Cam đỏ rực, chữ trắng đậm).
     */
    public static JButton createLoginButton(String text) {
        return createBaseCustomButton(
            text, 
            LOGIN_BTN_COLOR, 
            LOGIN_BTN_HOVER, 
            Color.WHITE, 
            8, 
            2, 
            new Color(130, 15, 2), 
            new Font("Segoe UI", Font.BOLD, 15), 
            9, 
            24
        );
    }

    /**
     * Tạo nút bấm hành động thành công (Xanh lá).
     */
    public static JButton createSuccessButton(String text) {
        return createCustomButton(text, SUCCESS_COLOR, new Color(36, 100, 40), Color.WHITE);
    }

    /**
     * Tạo nút bấm cảnh báo/xóa (Đỏ).
     */
    public static JButton createDangerButton(String text) {
        return createCustomButton(text, DANGER_COLOR, new Color(160, 30, 30), Color.WHITE);
    }

    /**
     * Tạo nút bấm phụ (Xám/Trắng).
     */
    public static JButton createSecondaryButton(String text) {
        return createBaseCustomButton(
            text, 
            new Color(240, 240, 240), 
            new Color(225, 225, 225), 
            TEXT_DARK, 
            4, 
            1, 
            BORDER_COLOR, 
            FONT_BODY_BOLD, 
            6, 
            14
        );
    }

    /**
     * Helper tạo nút bấm tùy chỉnh màu nền và hover.
     */
    public static JButton createCustomButton(String text, Color bg, Color hoverBg, Color fg) {
        return createBaseCustomButton(
            text, 
            bg, 
            hoverBg, 
            fg, 
            6, 
            1, 
            bg.darker(), 
            FONT_BODY_BOLD, 
            7, 
            16
        );
    }

    /**
     * Phương thức nền vẽ nút bấm tùy chỉnh tương thích hoàn toàn với FlatLaf
     * và tự động vẽ lại nền thủ công khi chạy trên Look & Feel hệ thống truyền thống (tránh lỗi nút trắng chữ trắng).
     */
    private static JButton createBaseCustomButton(
            String text, Color bg, Color hoverBg, Color fg, 
            int arc, int borderWidth, Color borderColor, Font font, 
            int paddingY, int paddingX) {
            
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                // Nếu FlatLaf đang hoạt động, để FlatLaf tự xử lý theo Client Property
                if (UIManager.getLookAndFeel().getClass().getName().contains("flatlaf")) {
                    super.paintComponent(g);
                    return;
                }
                
                // Vẽ nền và viền thủ công cho Look and Feel truyền thống (như Windows L&F)
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // 1. Vẽ nền nút theo trạng thái bấm/di chuột
                if (!isEnabled()) {
                    g2.setColor(new Color(204, 204, 204));
                } else if (getModel().isPressed()) {
                    g2.setColor(hoverBg.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(hoverBg);
                } else {
                    g2.setColor(bg);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
                
                // 2. Vẽ viền nút
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(borderWidth));
                g2.drawRoundRect(borderWidth / 2, borderWidth / 2, getWidth() - borderWidth, getHeight() - borderWidth, arc, arc);
                
                g2.dispose();
                
                // 3. Gọi mặc định để vẽ chữ (Foreground) và Icon lên trên nền đã tự vẽ
                super.paintComponent(g);
            }
        };
        
        // Vô hiệu hóa chế độ vẽ nền và viền mặc định của Windows L&F để tránh bị đè đè trắng
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        
        btn.setFont(font);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Cấu hình FlatLaf qua Client Property
        String style = String.format(
            "background: %s; hoverBackground: %s; pressedBackground: %s; foreground: %s; arc: %d; borderColors: %s; borderWidth: %d; margins: [%d,%d,%d,%d];",
            toHtmlColor(bg),
            toHtmlColor(hoverBg),
            toHtmlColor(hoverBg.darker()),
            toHtmlColor(fg),
            arc,
            toHtmlColor(borderColor),
            borderWidth,
            paddingY, paddingX, paddingY, paddingX
        );
        btn.putClientProperty("FlatLaf.style", style);
        
        // Kích hoạt repaint khi di chuột (cho L&F truyền thống nhận diện thay đổi rollover/pressed)
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.repaint();
            }
        });
        
        return btn;
    }

    /**
     * Tạo thẻ KPI thống kê trực quan cho Dashboard.
     */
    public static JPanel createKpiCard(String title, JLabel valueLabel, String subtitle, Color accentColor, String iconSymbol) {
        JPanel outer = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Shadow
                g2.setColor(new Color(0, 0, 0, 18));
                g2.fillRoundRect(3, 4, getWidth() - 3, getHeight() - 3, 14, 14);
                // Card background
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 14, 14);
                // Left accent bar
                g2.setColor(accentColor);
                g2.fillRoundRect(0, 0, 5, getHeight() - 3, 6, 6);
                g2.dispose();
            }
        };
        outer.setOpaque(false);
        outer.setBorder(new EmptyBorder(14, 18, 14, 14));

        JPanel card = new JPanel(new BorderLayout(12, 6));
        card.setOpaque(false);

        // Header thẻ gồm tiêu đề và icon ký hiệu
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(FONT_SMALL);
        lblTitle.setForeground(TEXT_MUTED);

        JLabel lblIcon = new JLabel(iconSymbol, SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.BOLD, 22));
        lblIcon.setForeground(accentColor);
        lblIcon.setPreferredSize(new Dimension(34, 34));

        top.add(lblTitle, BorderLayout.WEST);
        top.add(lblIcon, BorderLayout.EAST);

        // Giá trị số lớn
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLabel.setForeground(accentColor);

        // Chú thích chân thẻ
        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(FONT_SMALL);
        lblSub.setForeground(TEXT_MUTED);

        card.add(top, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(lblSub, BorderLayout.SOUTH);

        outer.add(card, BorderLayout.CENTER);
        return outer;
    }

    /**
     * Tạo panel chứa form hoặc bảng có viền thẻ Card đẹp mắt.
     */
    public static JPanel createCardPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(CARD_BG);
        panel.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(16, 16, 16, 16)
        ));

        if (title != null && !title.isBlank()) {
            JLabel lblTitle = new JLabel(title);
            lblTitle.setFont(FONT_HEADER);
            lblTitle.setForeground(PRIMARY_COLOR);
            lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
            panel.add(lblTitle, BorderLayout.NORTH);
        }
        return panel;
    }

    /**
     * Hiển thị thông báo thông tin thành công.
     */
    public static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Hiển thị thông báo cảnh báo.
     */
    public static void warning(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Cảnh báo", JOptionPane.WARNING_MESSAGE);
    }

    /**
     * Hiển thị thông báo lỗi chi tiết.
     */
    public static void error(Component parent, Exception e) {
        String msg = (e.getMessage() != null && !e.getMessage().isBlank()) ? e.getMessage() : "Đã có lỗi xảy ra.";
        JOptionPane.showMessageDialog(parent, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Hộp thoại xác nhận thao tác.
     */
    public static boolean confirm(Component parent, String message, String title) {
        int res = JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return res == JOptionPane.YES_OPTION;
    }

    /**
     * Tạo nhãn huy hiệu Badge bo tròn với màu sắc nổi bật.
     */
    public static JLabel createBadge(String text, Color bg, Color fg) {
        JLabel badge = new JLabel(text, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setOpaque(false);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setForeground(fg);
        badge.setBorder(new EmptyBorder(3, 8, 3, 8));
        return badge;
    }

    /**
     * Tạo nút danh mục kiểu Pill Button (viên thuốc bo tròn) cho màn hình POS.
     */
    public static JButton createPillButton(String text, boolean isSelected) {
        Color bg = isSelected ? ACCENT_COLOR : CARD_BG;
        Color hoverBg = isSelected ? ACCENT_COLOR.darker() : PRIMARY_LIGHT;
        Color fg = isSelected ? Color.WHITE : TEXT_DARK;
        Color border = isSelected ? ACCENT_COLOR : BORDER_COLOR;

        JButton btn = createBaseCustomButton(
                text,
                bg,
                hoverBg,
                fg,
                20,
                1,
                border,
                FONT_BODY_BOLD,
                6,
                14
        );
        return btn;
    }

    /**
     * Tạo nút điều hướng thanh Sidebar phong cách sang trọng.
     */
    public static JButton createSidebarNavButton(String text, String icon, boolean isActive) {
        Color fg = new Color(220, 205, 190);
        String fullText = (icon != null && !icon.isBlank()) ? (icon + "  " + text) : text;

        JButton btn = new JButton(fullText) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                boolean active = Boolean.TRUE.equals(getClientProperty("active"));
                if (active) {
                    g2.setColor(SIDEBAR_ACTIVE_BG);
                    g2.fillRoundRect(6, 2, getWidth() - 12, getHeight() - 4, 10, 10);
                } else if (getModel().isRollover()) {
                    g2.setColor(SIDEBAR_HOVER_BG);
                    g2.fillRoundRect(6, 2, getWidth() - 12, getHeight() - 4, 10, 10);
                }

                g2.dispose();
                super.paintComponent(g);
            }
        };

        btn.putClientProperty("active", isActive);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", isActive ? Font.BOLD : Font.PLAIN, 14));
        btn.setForeground(isActive ? Color.WHITE : fg);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(10, 20, 10, 16));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(260, 42));
        btn.setPreferredSize(new Dimension(225, 42));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.repaint();
            }
        });

        return btn;
    }

    /**
     * Bộ đệm hình ảnh sản phẩm (Image Cache)
     */
     private static final Map<String, ImageIcon> IMAGE_CACHE = new ConcurrentHashMap<>();

    /**
     * Tải và co dãn hình ảnh sản phẩm theo kích thước width x height với góc bo tròn mượt mà.
     * Tự động tìm kiếm trong:
     * 1. Classpath: images/products/[imageName]
     * 2. Classpath: images/[imageName]
     * 3. File hệ thống (Đường dẫn tuyệt đối hoặc tương đối)
     * 4. Fallback tự động vẽ ảnh dự phòng gradient đẹp mắt.
     */
    public static ImageIcon loadProductImage(String imageName, int width, int height) {
        String safeName = (imageName != null && !imageName.trim().isEmpty()) ? imageName.trim() : "default_drink.png";
        String cacheKey = safeName + "@" + width + "x" + height;
        if (IMAGE_CACHE.containsKey(cacheKey)) {
            return IMAGE_CACHE.get(cacheKey);
        }

        BufferedImage loaded = null;

        // 1. Thử tải từ resources/images/products/
        try {
            URL url = UIUtils.class.getClassLoader().getResource("images/products/" + safeName);
            if (url != null) {
                loaded = ImageIO.read(url);
            }
        } catch (Exception ignored) {}

        // 2. Thử tải từ resources/images/
        if (loaded == null) {
            try {
                URL url = UIUtils.class.getClassLoader().getResource("images/" + safeName);
                if (url != null) {
                    loaded = ImageIO.read(url);
                }
            } catch (Exception ignored) {}
        }

        // 3. Thử tải từ đường dẫn File hệ thống
        if (loaded == null) {
            try {
                File f = new File(safeName);
                if (f.exists() && f.isFile()) {
                    loaded = ImageIO.read(f);
                }
            } catch (Exception ignored) {}
        }

        // 4. Fallback mặc định
        if (loaded == null) {
            try {
                URL url = UIUtils.class.getClassLoader().getResource("images/products/default_drink.png");
                if (url != null) {
                    loaded = ImageIO.read(url);
                }
            } catch (Exception ignored) {}
        }

        // 5. Nếu vẫn chưa có thì vẽ fallback gradient trực tiếp
        if (loaded == null) {
            loaded = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = loaded.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, PRIMARY_COLOR, width, height, ACCENT_COLOR));
            g2.fillRoundRect(0, 0, width, height, 12, 12);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2.drawString("CoffeLand", width / 2 - 28, height / 2 + 4);
            g2.dispose();
        }

        // Co dãn hình ảnh mượt mà với góc bo tròn
        BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = output.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        // Bo tròn góc ảnh
        g2.setClip(new RoundRectangle2D.Float(0, 0, width, height, 10, 10));
        g2.drawImage(loaded, 0, 0, width, height, null);
        g2.dispose();

        ImageIcon icon = new ImageIcon(output);
        IMAGE_CACHE.put(cacheKey, icon);
        return icon;
    }

    /**
     * Chuyển đổi mã màu Color sang định dạng chuỗi Hex dùng cho phong cách FlatLaf.
     */
    private static String toHtmlColor(Color color) {
        if (color == null) return "#FFFFFF";
        return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }
}


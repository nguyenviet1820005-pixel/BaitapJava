package com.coffeeland;

import com.coffeeland.ui.LoginFrame;
import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Method;

/**
 * Điểm khởi chạy chính (Main Entry Point) của ứng dụng quản lý CoffeLand.
 */
public class App {

    public static void main(String[] args) {
        // Chạy giao diện trên Event Dispatch Thread (EDT) của Swing
        SwingUtilities.invokeLater(() -> {
            initLookAndFeel();
            new LoginFrame().setVisible(true);
        });
    }

    /**
     * Khởi tạo giao diện hiện đại: Ưu tiên FlatLaf nếu có thư viện,
     * hoặc tự động fallback về System Look and Feel mượt mà.
     */
    private static void initLookAndFeel() {
        boolean flatlafLoaded = false;
        try {
            // Thử nạp FlatLightLaf bằng reflection để an toàn ngay cả khi chưa build Maven
            Class<?> flatLightLafClass = Class.forName("com.formdev.flatlaf.FlatLightLaf");
            Method setupMethod = flatLightLafClass.getMethod("setup");
            setupMethod.invoke(null);
            flatlafLoaded = true;
        } catch (Throwable ignored) {
            // FlatLaf không khả dụng, sử dụng System Look and Feel
        }

        if (!flatlafLoaded) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
        }

        // Cấu hình font chữ hệ thống đồng bộ rõ nét
        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 13);
        UIManager.put("Button.font", defaultFont);
        UIManager.put("Label.font", defaultFont);
        UIManager.put("TextField.font", defaultFont);
        UIManager.put("PasswordField.font", defaultFont);
        UIManager.put("ComboBox.font", defaultFont);
        UIManager.put("Table.font", defaultFont);
        UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 13));
        UIManager.put("TabbedPane.font", new Font("Segoe UI", Font.BOLD, 13));
    }
}

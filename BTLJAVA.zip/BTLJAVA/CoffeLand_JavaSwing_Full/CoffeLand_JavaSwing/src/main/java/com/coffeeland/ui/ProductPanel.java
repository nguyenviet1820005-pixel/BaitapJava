package com.coffeeland.ui;

import com.coffeeland.dao.CategoryDAO;
import com.coffeeland.dao.ProductDAO;
import com.coffeeland.model.Category;
import com.coffeeland.model.Product;
import com.coffeeland.util.ExcelExporter;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Màn hình Quản lý Sản phẩm / Menu Đồ uống & Xuất Excel (Products).
 */
public class ProductPanel extends JPanel {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private List<Product> cachedProductList = new ArrayList<>();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Mã món", "Tên sản phẩm / Đồ uống", "Danh mục", "ĐVT", "Giá bán", "Tồn kho", "Trạng thái"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    // Bộ lọc tìm kiếm
    private final JTextField txtSearch = new JTextField();
    private final JComboBox<CategoryWrapper> cboCategoryFilter = new JComboBox<>();

    // Form nhập liệu
    private final JTextField txtCode = new JTextField();
    private final JTextField txtName = new JTextField();
    private final JComboBox<Category> cboCategory = new JComboBox<>();
    private final JComboBox<String> cboUnit = new JComboBox<>(new String[]{"Ly", "Phần", "Chai", "Lon", "Gói"});
    private final JTextField txtPrice = new JTextField();
    private final JTextField txtStock = new JTextField("0");
    private final JTextField txtImage = new JTextField("default_drink.png");
    private final JLabel lblImagePreview = new JLabel();
    private final JCheckBox chkActive = new JCheckBox("Đang mở bán", true);
    private int selectedProductId = 0;

    public ProductPanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadCategories();
        loadProducts();
    }

    private void initUI() {
        // 1. Tiêu đề và Bộ lọc tìm kiếm
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("QUẢN LÝ SẢN PHẨM & MENU ĐỒ UỐNG");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        topPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel filterBar = new JPanel(new BorderLayout(10, 0));
        filterBar.setOpaque(false);

        JPanel searchInputs = new JPanel(new GridLayout(1, 2, 10, 0));
        searchInputs.setOpaque(false);

        JPanel p1 = new JPanel(new BorderLayout(6, 0));
        p1.setOpaque(false);
        p1.add(new JLabel("Từ khóa:"), BorderLayout.WEST);
        txtSearch.putClientProperty("JTextField.placeholderText", "Tìm theo mã hoặc tên món...");
        p1.add(txtSearch, BorderLayout.CENTER);

        JPanel p2 = new JPanel(new BorderLayout(6, 0));
        p2.setOpaque(false);
        p2.add(new JLabel("Danh mục:"), BorderLayout.WEST);
        p2.add(cboCategoryFilter, BorderLayout.CENTER);

        searchInputs.add(p1);
        searchInputs.add(p2);
        filterBar.add(searchInputs, BorderLayout.CENTER);

        JPanel filterButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        filterButtons.setOpaque(false);
        JButton btnSearch = UIUtils.createPrimaryButton("Tìm kiếm");
        JButton btnReload = UIUtils.createSecondaryButton("Tải lại");
        JButton btnExportExcel = UIUtils.createSuccessButton("Xuất Excel");

        btnExportExcel.addActionListener(e -> ExcelExporter.exportTableToExcel(this, table, "Menu_Thuc_Don_CoffeLand"));

        filterButtons.add(btnSearch);
        filterButtons.add(btnReload);
        filterButtons.add(btnExportExcel);
        filterBar.add(filterButtons, BorderLayout.EAST);

        topPanel.add(filterBar, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        btnSearch.addActionListener(e -> loadProducts());
        txtSearch.addActionListener(e -> loadProducts());
        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { loadProducts(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { loadProducts(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { loadProducts(); }
        });
        cboCategoryFilter.addActionListener(e -> loadProducts());
        btnReload.addActionListener(e -> {
            txtSearch.setText("");
            cboCategoryFilter.setSelectedIndex(0);
            loadProducts();
        });

        // 2. Bảng dữ liệu sản phẩm
        JPanel centerCard = UIUtils.createCardPanel("DANH SÁCH SẢN PHẨM");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(45);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(1).setPreferredWidth(75);
        table.getColumnModel().getColumn(1).setCellRenderer(center);
        table.getColumnModel().getColumn(4).setPreferredWidth(55);
        table.getColumnModel().getColumn(4).setCellRenderer(center);

        // Renderer cảnh báo tồn kho sắp hết
        DefaultTableCellRenderer stockRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSelected, boolean hasFocus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, isSelected, hasFocus, row, col);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                String val = (v != null) ? v.toString() : "";
                if (!isSelected) {
                    if (val.contains("Hết")) {
                        l.setForeground(UIUtils.DANGER_COLOR);
                        l.setFont(UIUtils.FONT_BODY_BOLD);
                    } else if (val.contains("Sắp hết")) {
                        l.setForeground(UIUtils.WARNING_COLOR);
                        l.setFont(UIUtils.FONT_BODY_BOLD);
                    } else {
                        l.setForeground(UIUtils.SUCCESS_COLOR);
                        l.setFont(UIUtils.FONT_BODY);
                    }
                }
                return l;
            }
        };
        table.getColumnModel().getColumn(6).setPreferredWidth(105);
        table.getColumnModel().getColumn(6).setCellRenderer(stockRenderer);

        // Renderer trạng thái mở bán
        DefaultTableCellRenderer statusRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSelected, boolean hasFocus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, isSelected, hasFocus, row, col);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                String val = (v != null) ? v.toString() : "";
                if (!isSelected) {
                    if (val.contains("Đang bán")) {
                        l.setForeground(UIUtils.SUCCESS_COLOR);
                        l.setFont(UIUtils.FONT_BODY_BOLD);
                    } else {
                        l.setForeground(UIUtils.TEXT_MUTED);
                        l.setFont(UIUtils.FONT_BODY);
                    }
                }
                return l;
            }
        };
        table.getColumnModel().getColumn(7).setPreferredWidth(110);
        table.getColumnModel().getColumn(7).setCellRenderer(statusRenderer);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(5).setPreferredWidth(95);
        table.getColumnModel().getColumn(5).setCellRenderer(right);

        table.getSelectionModel().addListSelectionListener(e -> handleSelectRow());
        centerCard.add(new JScrollPane(table), BorderLayout.CENTER);
        add(centerCard, BorderLayout.CENTER);

        // 3. Form thông tin sản phẩm bên phải
        JPanel rightCard = UIUtils.createCardPanel("THÔNG TIN SẢN PHẨM");
        rightCard.setPreferredSize(new Dimension(380, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        // Khung xem trước ảnh món
        lblImagePreview.setPreferredSize(new Dimension(150, 95));
        lblImagePreview.setMaximumSize(new Dimension(150, 95));
        lblImagePreview.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblImagePreview.setHorizontalAlignment(SwingConstants.CENTER);
        lblImagePreview.setBorder(BorderFactory.createLineBorder(UIUtils.BORDER_COLOR, 1, true));
        updateImagePreview("default_drink.png");

        JPanel previewContainer = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        previewContainer.setOpaque(false);
        previewContainer.add(lblImagePreview);
        formBody.add(previewContainer);
        formBody.add(Box.createVerticalStrut(8));

        // Chọn file ảnh
        JPanel imgRow = new JPanel(new BorderLayout(6, 0));
        imgRow.setOpaque(false);
        imgRow.add(txtImage, BorderLayout.CENTER);
        JButton btnBrowseImg = UIUtils.createSecondaryButton("📁 Chọn...");
        btnBrowseImg.addActionListener(e -> handleBrowseImage());
        imgRow.add(btnBrowseImg, BorderLayout.EAST);
        txtImage.addActionListener(e -> updateImagePreview(txtImage.getText()));

        formBody.add(UIUtils.formRow("Hình ảnh:", imgRow));
        formBody.add(Box.createVerticalStrut(6));

        formBody.add(UIUtils.formRow("Mã món *:", txtCode));
        formBody.add(Box.createVerticalStrut(6));
        formBody.add(UIUtils.formRow("Tên món *:", txtName));
        formBody.add(Box.createVerticalStrut(6));
        formBody.add(UIUtils.formRow("Danh mục *:", cboCategory));
        formBody.add(Box.createVerticalStrut(6));
        formBody.add(UIUtils.formRow("Đơn vị tính:", cboUnit));
        formBody.add(Box.createVerticalStrut(6));
        formBody.add(UIUtils.formRow("Giá bán (VNĐ) *:", txtPrice));
        formBody.add(Box.createVerticalStrut(6));
        formBody.add(UIUtils.formRow("Tồn kho:", txtStock));
        formBody.add(Box.createVerticalStrut(6));

        chkActive.setOpaque(false);
        chkActive.setFont(UIUtils.FONT_BODY_BOLD);
        chkActive.setForeground(UIUtils.PRIMARY_COLOR);
        formBody.add(chkActive);
        formBody.add(Box.createVerticalStrut(14));

        // Nút thao tác
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 8, 8));
        buttonPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Lưu");
        JButton btnClear = UIUtils.createSecondaryButton("+ Mới");
        JButton btnDelete = UIUtils.createDangerButton("Xóa");

        btnSave.addActionListener(e -> handleSave());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> handleDelete());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnDelete);

        formBody.add(buttonPanel);
        rightCard.add(formBody, BorderLayout.CENTER);
        add(rightCard, BorderLayout.EAST);
    }

    private void updateImagePreview(String imgName) {
        ImageIcon icon = UIUtils.loadProductImage(imgName, 150, 95);
        lblImagePreview.setIcon(icon);
    }

    private void handleBrowseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Chọn hình ảnh sản phẩm (PNG, JPG)");
        chooser.setFileFilter(new FileNameExtensionFilter("Hình ảnh (*.png, *.jpg, *.jpeg)", "png", "jpg", "jpeg"));
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            txtImage.setText(selectedFile.getAbsolutePath());
            updateImagePreview(selectedFile.getAbsolutePath());
        }
    }

    private void loadCategories() {
        try {
            cboCategory.removeAllItems();
            cboCategoryFilter.removeAllItems();

            cboCategoryFilter.addItem(new CategoryWrapper(0, "-- Tất cả danh mục --"));

            List<Category> list = categoryDAO.findAll();
            for (Category c : list) {
                cboCategory.addItem(c);
                cboCategoryFilter.addItem(new CategoryWrapper(c.getId(), c.getName()));
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void loadProducts() {
        try {
            tableModel.setRowCount(0);
            String keyword = txtSearch.getText().trim();
            CategoryWrapper selectedCat = (CategoryWrapper) cboCategoryFilter.getSelectedItem();
            Integer catId = (selectedCat != null && selectedCat.id > 0) ? selectedCat.id : null;

            cachedProductList = productDAO.findAll(keyword, catId);
            for (Product p : cachedProductList) {
                tableModel.addRow(new Object[]{
                        p.getId(),
                        p.getCode(),
                        p.getName(),
                        p.getCategoryName(),
                        p.getUnit(),
                        UIUtils.money(p.getPrice()),
                        p.getStock() == 0 ? "Hết hàng" : (p.getStock() <= 10 ? "Sắp hết (" + p.getStock() + ")" : "Còn (" + p.getStock() + ")"),
                        p.isActive() ? "Đang bán" : "Ngừng bán"
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleSelectRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        selectedProductId = (int) tableModel.getValueAt(row, 0);
        txtCode.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        txtName.setText(String.valueOf(tableModel.getValueAt(row, 2)));

        // Tìm Product trong cache để lấy tên file ảnh chính xác
        String imgPath = "default_drink.png";
        for (Product p : cachedProductList) {
            if (p.getId() == selectedProductId) {
                imgPath = p.getImageOrDefault();
                break;
            }
        }
        txtImage.setText(imgPath);
        updateImagePreview(imgPath);

        String catName = String.valueOf(tableModel.getValueAt(row, 3));
        for (int i = 0; i < cboCategory.getItemCount(); i++) {
            if (cboCategory.getItemAt(i).getName().equalsIgnoreCase(catName)) {
                cboCategory.setSelectedIndex(i);
                break;
            }
        }

        String unit = String.valueOf(tableModel.getValueAt(row, 4));
        cboUnit.setSelectedItem(unit);

        String priceStr = String.valueOf(tableModel.getValueAt(row, 5)).replaceAll("[^0-9]", "");
        txtPrice.setText(priceStr);

        String stockStr = String.valueOf(tableModel.getValueAt(row, 6));
        if (stockStr.contains("Hết hàng")) {
            txtStock.setText("0");
        } else if (stockStr.contains("(")) {
            int start = stockStr.indexOf('(');
            int end = stockStr.indexOf(')');
            if (start != -1 && end != -1) {
                txtStock.setText(stockStr.substring(start + 1, end).trim());
            } else {
                txtStock.setText("0");
            }
        } else {
            txtStock.setText(stockStr);
        }

        String activeStr = String.valueOf(tableModel.getValueAt(row, 7));
        chkActive.setSelected(activeStr.contains("Đang bán"));
    }

    private void handleSave() {
        String code = txtCode.getText().trim();
        String name = txtName.getText().trim();
        Category cat = (Category) cboCategory.getSelectedItem();
        String unit = String.valueOf(cboUnit.getSelectedItem());
        String priceText = txtPrice.getText().trim();
        String stockText = txtStock.getText().trim();
        String image = txtImage.getText().trim();
        boolean active = chkActive.isSelected();

        if (code.isEmpty() || name.isEmpty() || cat == null) {
            UIUtils.warning(this, "Vui lòng nhập đầy đủ Mã món, Tên món và chọn Danh mục.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText.replaceAll("[^0-9.]", ""));
            if (price < 0) throw new NumberFormatException();
        } catch (Exception e) {
            UIUtils.warning(this, "Giá bán không hợp lệ (phải là số ≥ 0).");
            txtPrice.requestFocus();
            return;
        }

        int stock;
        try {
            stock = Integer.parseInt(stockText.trim());
            if (stock < 0) throw new NumberFormatException();
        } catch (Exception e) {
            UIUtils.warning(this, "Tồn kho không hợp lệ (phải là số nguyên ≥ 0).");
            txtStock.requestFocus();
            return;
        }

        try {
            if (productDAO.isCodeExists(code, selectedProductId)) {
                UIUtils.warning(this, "Mã món '" + code + "' đã tồn tại trong hệ thống.");
                txtCode.requestFocus();
                return;
            }

            Product p = new Product();
            p.setId(selectedProductId);
            p.setCode(code);
            p.setName(name);
            p.setCategoryId(cat.getId());
            p.setUnit(unit);
            p.setPrice(price);
            p.setStock(stock);
            p.setActive(active);
            p.setImage(image);

            if (selectedProductId == 0) {
                productDAO.insert(p);
                UIUtils.info(this, "Thêm món mới vào menu thành công!");
            } else {
                productDAO.update(p);
                UIUtils.info(this, "Cập nhật thông tin món thành công!");
            }

            clearForm();
            loadProducts();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleDelete() {
        if (selectedProductId == 0) {
            UIUtils.warning(this, "Vui lòng chọn sản phẩm cần xóa từ bảng.");
            return;
        }

        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn xóa sản phẩm này?", "Xác nhận xóa")) {
            try {
                productDAO.delete(selectedProductId);
                UIUtils.info(this, "Xóa sản phẩm thành công!");
                clearForm();
                loadProducts();
            } catch (Exception e) {
                UIUtils.error(this, new Exception("Không thể xóa sản phẩm đã có lịch sử bán hàng/nhập kho. Bạn có thể bỏ chọn 'Đang mở bán' để ẩn món khỏi menu."));
            }
        }
    }

    private void clearForm() {
        selectedProductId = 0;
        txtCode.setText("");
        txtName.setText("");
        txtPrice.setText("");
        txtStock.setText("0");
        txtImage.setText("default_drink.png");
        updateImagePreview("default_drink.png");
        cboUnit.setSelectedIndex(0);
        chkActive.setSelected(true);
        table.clearSelection();
        txtCode.requestFocus();
    }

    private static class CategoryWrapper {
        final int id;
        final String name;

        CategoryWrapper(int id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}

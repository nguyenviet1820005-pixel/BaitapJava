package com.coffeeland.ui;

import com.coffeeland.dao.CustomerDAO;
import com.coffeeland.model.Customer;
import com.coffeeland.util.ExcelExporter;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Màn hình Quản lý Khách hàng & Điểm tích lũy & Xuất Excel (Customers).
 */
public class CustomerPanel extends JPanel {

    private final CustomerDAO customerDAO = new CustomerDAO();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Mã KH", "Họ và tên", "Số điện thoại", "Địa chỉ", "Điểm tích lũy", "Hạng thành viên"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    private final JTextField txtSearch = new JTextField();
    private final JTextField txtCode = new JTextField();
    private final JTextField txtFullName = new JTextField();
    private final JTextField txtPhone = new JTextField();
    private final JTextField txtAddress = new JTextField();
    private final JTextField txtPoints = new JTextField("0");
    private int selectedCustomerId = 0;

    public CustomerPanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadCustomers();
    }

    private void initUI() {
        // 1. Tiêu đề và Thanh tìm kiếm
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("QUAN LY KHACH HANG & TICH DIEM");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        topPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new BorderLayout(8, 0));
        searchBar.setOpaque(false);
        searchBar.add(new JLabel("Tìm kiếm (Mã / Tên / SĐT):"), BorderLayout.WEST);
        searchBar.add(txtSearch, BorderLayout.CENTER);

        JPanel searchButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        searchButtons.setOpaque(false);
        JButton btnSearch = UIUtils.createPrimaryButton("Tìm");
        JButton btnReload = UIUtils.createSecondaryButton("Tải lại");
        JButton btnExportExcel = UIUtils.createSuccessButton("Xuất Excel");

        btnExportExcel.addActionListener(e -> ExcelExporter.exportTableToExcel(this, table, "Danh_sach_khach_hang_CoffeLand"));

        searchButtons.add(btnSearch);
        searchButtons.add(btnReload);
        searchButtons.add(btnExportExcel);
        searchBar.add(searchButtons, BorderLayout.EAST);

        topPanel.add(searchBar, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        btnSearch.addActionListener(e -> loadCustomers());
        txtSearch.addActionListener(e -> loadCustomers());
        btnReload.addActionListener(e -> {
            txtSearch.setText("");
            loadCustomers();
        });

        // 2. Bảng dữ liệu khách hàng
        JPanel centerCard = UIUtils.createCardPanel("DANH SÁCH KHÁCH HÀNG");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(45);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(center);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);
        table.getColumnModel().getColumn(5).setCellRenderer(center);

        table.getSelectionModel().addListSelectionListener(e -> handleSelectRow());
        centerCard.add(new JScrollPane(table), BorderLayout.CENTER);
        add(centerCard, BorderLayout.CENTER);

        // 3. Form thông tin khách hàng bên phải
        JPanel rightCard = UIUtils.createCardPanel("THÔNG TIN KHÁCH HÀNG");
        rightCard.setPreferredSize(new Dimension(380, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        formBody.add(UIUtils.formRow("Mã KH *:", txtCode));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Họ tên *:", txtFullName));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Điện thoại:", txtPhone));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Địa chỉ:", txtAddress));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Điểm tích lũy:", txtPoints));
        formBody.add(Box.createVerticalStrut(18));

        // Nút thao tác
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 8, 8));
        buttonPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Lưu");
        JButton btnClear = UIUtils.createSecondaryButton("+ Mới");
        JButton btnDelete = UIUtils.createDangerButton("Xóa");

        btnSave.addActionListener(e -> handleSave());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> handleDelete());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnDelete);

        formBody.add(buttonPanel);
        rightCard.add(formBody, BorderLayout.CENTER);
        add(rightCard, BorderLayout.EAST);
    }

    private String getMemberLevel(int points) {
        if (points >= 300) return "💎 Kim cương";
        if (points >= 150) return "🥇 Vàng";
        if (points >= 50) return "🥈 Bạc";
        return "🥉 Đồng";
    }

    private void loadCustomers() {
        try {
            tableModel.setRowCount(0);
            List<Customer> list = customerDAO.findAll(txtSearch.getText().trim());
            for (Customer c : list) {
                tableModel.addRow(new Object[]{
                        c.getId(),
                        c.getCode(),
                        c.getFullName(),
                        c.getPhone() != null ? c.getPhone() : "",
                        c.getAddress() != null ? c.getAddress() : "",
                        c.getPoints() + " điểm",
                        getMemberLevel(c.getPoints())
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleSelectRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        selectedCustomerId = (int) tableModel.getValueAt(row, 0);
        txtCode.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        txtFullName.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        txtPhone.setText(String.valueOf(tableModel.getValueAt(row, 3)));
        txtAddress.setText(String.valueOf(tableModel.getValueAt(row, 4)));

        String pointsStr = String.valueOf(tableModel.getValueAt(row, 5)).replace(" điểm", "").trim();
        txtPoints.setText(pointsStr);
    }

    private void handleSave() {
        String code = txtCode.getText().trim();
        String name = txtFullName.getText().trim();
        String phone = txtPhone.getText().trim();
        String address = txtAddress.getText().trim();
        String pointsText = txtPoints.getText().trim();

        if (code.isEmpty() || name.isEmpty()) {
            UIUtils.warning(this, "Vui lòng nhập đầy đủ Mã khách hàng và Họ tên.");
            return;
        }

        int points = 0;
        try {
            points = pointsText.isEmpty() ? 0 : Integer.parseInt(pointsText);
            if (points < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            UIUtils.warning(this, "Điểm tích lũy phải là số nguyên không âm (≥ 0).");
            txtPoints.requestFocus();
            return;
        }

        try {
            if (customerDAO.isCodeExists(code, selectedCustomerId)) {
                UIUtils.warning(this, "Mã khách hàng '" + code + "' đã tồn tại trong hệ thống.");
                txtCode.requestFocus();
                return;
            }

            Customer c = new Customer();
            c.setId(selectedCustomerId);
            c.setCode(code);
            c.setFullName(name);
            c.setPhone(phone);
            c.setAddress(address);
            c.setPoints(points);

            if (selectedCustomerId == 0) {
                customerDAO.insert(c);
                UIUtils.info(this, "Thêm mới khách hàng thành công!");
            } else {
                customerDAO.update(c);
                UIUtils.info(this, "Cập nhật thông tin khách hàng thành công!");
            }

            clearForm();
            loadCustomers();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleDelete() {
        if (selectedCustomerId == 0) {
            UIUtils.warning(this, "Vui lòng chọn khách hàng cần xóa từ bảng.");
            return;
        }

        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn xóa khách hàng này?", "Xác nhận xóa")) {
            try {
                customerDAO.delete(selectedCustomerId);
                UIUtils.info(this, "Xóa khách hàng thành công!");
                clearForm();
                loadCustomers();
            } catch (Exception e) {
                UIUtils.error(this, new Exception("Khách hàng này đã phát sinh hóa đơn bán hàng trong hệ thống. Không thể xóa."));
            }
        }
    }

    private void clearForm() {
        selectedCustomerId = 0;
        txtCode.setText("");
        txtFullName.setText("");
        txtPhone.setText("");
        txtAddress.setText("");
        txtPoints.setText("0");
        table.clearSelection();
        txtCode.requestFocus();
    }
}

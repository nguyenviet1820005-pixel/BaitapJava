package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Sản phẩm / Đồ uống (Products).
 */
public class ProductDAO {

    private static boolean schemaChecked = false;

    private static synchronized void ensureImageColumnExists() {
        if (schemaChecked) return;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "ALTER TABLE products ADD COLUMN IF NOT EXISTS image VARCHAR(255) DEFAULT 'default_drink.png'")) {
            ps.executeUpdate();
            schemaChecked = true;
        } catch (Exception ignored) {
            schemaChecked = true;
        }
    }

    private Product mapResultSet(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setId(rs.getInt("id"));
        p.setCode(rs.getString("code"));
        p.setName(rs.getString("name"));
        p.setCategoryId(rs.getInt("category_id"));
        p.setCategoryName(rs.getString("category_name"));
        p.setUnit(rs.getString("unit"));
        p.setPrice(rs.getDouble("price"));
        p.setStock(rs.getInt("stock"));
        p.setActive(rs.getBoolean("active"));
        try {
            String img = rs.getString("image");
            p.setImage(img != null && !img.trim().isEmpty() ? img : "default_drink.png");
        } catch (SQLException e) {
            p.setImage("default_drink.png");
        }
        return p;
    }

    /**
     * Lấy danh sách sản phẩm theo từ khóa tìm kiếm (Mã hoặc Tên) và danh mục (nếu có).
     */
    public List<Product> findAll(String keyword, Integer categoryId) throws SQLException {
        ensureImageColumnExists();
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT p.id, p.code, p.name, p.category_id, c.name AS category_name, " +
                "p.unit, p.price, p.stock, p.active, p.image " +
                "FROM products p " +
                "JOIN categories c ON p.category_id = c.id " +
                "WHERE 1=1 "
        );

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (p.code LIKE ? OR p.name LIKE ?) ");
        }
        if (categoryId != null && categoryId > 0) {
            sql.append("AND p.category_id = ? ");
        }
        sql.append("ORDER BY p.id DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                String k = "%" + keyword.trim() + "%";
                ps.setString(paramIndex++, k);
                ps.setString(paramIndex++, k);
            }
            if (categoryId != null && categoryId > 0) {
                ps.setInt(paramIndex++, categoryId);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    /**
     * Lấy danh sách sản phẩm theo từ khóa tìm kiếm (tương thích method cũ).
     */
    public List<Product> findAll(String keyword) throws SQLException {
        return findAll(keyword, null);
    }

    /**
     * Lấy danh sách tất cả sản phẩm đang kinh doanh (active = 1).
     */
    public List<Product> findActive() throws SQLException {
        ensureImageColumnExists();
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.id, p.code, p.name, p.category_id, c.name AS category_name, " +
                     "p.unit, p.price, p.stock, p.active, p.image " +
                     "FROM products p " +
                     "JOIN categories c ON p.category_id = c.id " +
                     "WHERE p.active = 1 " +
                     "ORDER BY p.category_id ASC, p.id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    /**
     * Lấy danh sách sản phẩm theo ID danh mục.
     */
    public List<Product> findByCategoryId(int categoryId) throws SQLException {
        return findAll(null, categoryId);
    }

    /**
     * Kiểm tra mã sản phẩm đã tồn tại hay chưa.
     */
    public boolean isCodeExists(String code, int excludeId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM products WHERE code = ? AND id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code.trim());
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Thêm mới sản phẩm vào cơ sở dữ liệu.
     */
    public void insert(Product p) throws SQLException {
        ensureImageColumnExists();
        String sql = "INSERT INTO products(code, name, category_id, unit, price, stock, active, image) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, p.getCode().trim().toUpperCase());
            ps.setString(2, p.getName().trim());
            ps.setInt(3, p.getCategoryId());
            ps.setString(4, p.getUnit().trim());
            ps.setDouble(5, p.getPrice());
            ps.setInt(6, p.getStock());
            ps.setBoolean(7, p.isActive());
            ps.setString(8, p.getImageOrDefault());
            ps.executeUpdate();
        }
    }

    /**
     * Cập nhật thông tin sản phẩm theo ID.
     */
    public void update(Product p) throws SQLException {
        ensureImageColumnExists();
        String sql = "UPDATE products SET code = ?, name = ?, category_id = ?, unit = ?, price = ?, stock = ?, active = ?, image = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, p.getCode().trim().toUpperCase());
            ps.setString(2, p.getName().trim());
            ps.setInt(3, p.getCategoryId());
            ps.setString(4, p.getUnit().trim());
            ps.setDouble(5, p.getPrice());
            ps.setInt(6, p.getStock());
            ps.setBoolean(7, p.isActive());
            ps.setString(8, p.getImageOrDefault());
            ps.setInt(9, p.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Xóa sản phẩm khỏi CSDL.
     */
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM products WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

package com.coffeeland.ui;

import com.coffeeland.util.UIUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Component vẽ biểu đồ Donut phân bổ Doanh thu theo Danh mục sản phẩm bằng Java 2D Graphics.
 * Cải tiến: Viền trắng giữa các lát, nội dung lỗ giữa đẹp hơn, legend với progress bar mini.
 */
public class CategoryRevenueChartPanel extends JPanel {

    private List<Object[]> data = new ArrayList<>();

    // Bảng màu hài hòa phong cách đồ uống & cà phê
    private static final Color[] SLICE_COLORS = {
            new Color(111, 78,  55),   // Nâu cà phê đậm
            new Color(200, 130, 60),   // Vàng caramel
            new Color(34,  139, 34),   // Xanh Matcha trà
            new Color(218, 98,  43),   // Cam đào
            new Color(138, 43, 226),   // Tím nho
            new Color(41,  128, 185),  // Xanh biển
            new Color(230, 126, 34),   // Cam tươi
            new Color(142, 68, 173)    // Tím berry
    };

    public CategoryRevenueChartPanel() {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(380, 240));
    }

    public void setData(List<Object[]> data) {
        this.data = (data != null) ? data : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int width  = getWidth();
        int height = getHeight();

        if (data == null || data.isEmpty()) {
            g2.setFont(UIUtils.FONT_BODY);
            g2.setColor(UIUtils.TEXT_MUTED);
            String emptyMsg = "Chưa có dữ liệu phân bổ danh mục";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(emptyMsg, (width - fm.stringWidth(emptyMsg)) / 2, height / 2);
            g2.dispose();
            return;
        }

        // Layout: trái Donut, phải Legend
        int chartDiameter = Math.min(width / 2 - 16, height - 24);
        int chartX = 12;
        int chartY = (height - chartDiameter) / 2;

        // Tổng doanh thu
        double totalRev = 0;
        for (Object[] item : data) totalRev += (Double) item[1];

        // 1. Vẽ bóng nhẹ cho donut
        g2.setColor(new Color(0, 0, 0, 12));
        g2.fillOval(chartX + 4, chartY + 5, chartDiameter, chartDiameter);

        // 2. Vẽ các lát Donut
        double currentAngle = 90.0; // bắt đầu từ 12 giờ
        for (int i = 0; i < data.size(); i++) {
            Object[] item   = data.get(i);
            double percent  = (Double) item[2];
            double arcAngle = (percent / 100.0) * 360.0;
            Color color     = SLICE_COLORS[i % SLICE_COLORS.length];

            g2.setColor(color);
            Arc2D.Double arc = new Arc2D.Double(
                    chartX, chartY, chartDiameter, chartDiameter,
                    currentAngle, -arcAngle, Arc2D.PIE
            );
            g2.fill(arc);

            // Đường viền trắng phân cách lát
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(2.5f));
            g2.draw(arc);

            currentAngle -= arcAngle;
        }

        // 3. Lỗ Donut ở giữa (vẽ sau đường viền)
        int holeDiameter = (int) (chartDiameter * 0.52);
        int holeX = chartX + (chartDiameter - holeDiameter) / 2;
        int holeY = chartY + (chartDiameter - holeDiameter) / 2;

        // Bóng trong lỗ
        g2.setColor(new Color(245, 242, 238));
        g2.fillOval(holeX, holeY, holeDiameter, holeDiameter);
        g2.setColor(Color.WHITE);
        g2.fillOval(holeX + 3, holeY + 3, holeDiameter - 6, holeDiameter - 6);

        // Văn bản ở giữa lỗ
        int centerX = holeX + holeDiameter / 2;
        int centerY = holeY + holeDiameter / 2;

        g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        FontMetrics fmEmoji = g2.getFontMetrics();
        String coffeeEmoji = "☕";
        g2.drawString(coffeeEmoji, centerX - fmEmoji.stringWidth(coffeeEmoji) / 2, centerY - 2);

        g2.setFont(new Font("Segoe UI", Font.BOLD, 9));
        g2.setColor(UIUtils.TEXT_MUTED);
        FontMetrics fmSmall = g2.getFontMetrics();
        String centerSub = "DANH MỤC";
        g2.drawString(centerSub, centerX - fmSmall.stringWidth(centerSub) / 2, centerY + 14);

        // 4. Legend bên phải
        int legendX   = chartX + chartDiameter + 18;
        int legendMaxW = width - legendX - 8;
        int itemH     = Math.max(24, (height - 16) / Math.min(data.size(), 7));
        int legendY   = (height - Math.min(data.size(), 7) * itemH) / 2;

        int maxItems = Math.min(data.size(), 7);
        for (int i = 0; i < maxItems; i++) {
            Object[] item  = data.get(i);
            String catName = (String) item[0];
            double rev     = (Double) item[1];
            double percent = (Double) item[2];
            Color color    = SLICE_COLORS[i % SLICE_COLORS.length];

            int yPos = legendY + (i * itemH);

            // Chấm tròn màu
            g2.setColor(color);
            g2.fillOval(legendX, yPos + 2, 10, 10);

            // Tên danh mục
            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            g2.setColor(UIUtils.TEXT_DARK);
            String nameText = catName.length() > 16 ? catName.substring(0, 14) + "…" : catName;
            g2.drawString(nameText, legendX + 15, yPos + 11);

            // Mini progress bar
            int barY    = yPos + 14;
            int barH    = 5;
            int maxBarW = legendMaxW - 15;
            int barW    = (int) ((percent / 100.0) * maxBarW);

            g2.setColor(new Color(230, 225, 220));
            g2.fillRoundRect(legendX + 15, barY, maxBarW, barH, 4, 4);
            g2.setColor(color);
            g2.fillRoundRect(legendX + 15, barY, Math.max(4, barW), barH, 4, 4);

            // % và số tiền nhỏ
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            g2.setColor(UIUtils.TEXT_MUTED);
            String detail = String.format("%.1f%% · %s", percent, formatShortMoney(rev));
            g2.drawString(detail, legendX + 15, yPos + itemH - 3);
        }

        g2.dispose();
    }

    private String formatShortMoney(double value) {
        if (value >= 1_000_000) {
            return String.format("%.1fM", value / 1_000_000.0).replace(".0M", "M");
        } else if (value >= 1_000) {
            return String.format("%.0fk", value / 1_000.0);
        }
        return String.format("%.0f", value);
    }
}

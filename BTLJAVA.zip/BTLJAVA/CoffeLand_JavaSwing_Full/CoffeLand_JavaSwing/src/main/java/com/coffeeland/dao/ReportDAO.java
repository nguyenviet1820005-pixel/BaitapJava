package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý các truy vấn báo cáo nhanh cho hệ thống.
 */
public class ReportDAO {

    /**
     * Lấy 100 hóa đơn gần nhất cho màn hình theo dõi nhanh.
     */
    public List<Object[]> recentInvoices() throws SQLException {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT i.id, i.code, i.created_at, " +
                     "COALESCE(c.full_name, 'Khách lẻ') AS customer, " +
                     "COALESCE(e.full_name, '-') AS employee, " +
                     "i.total, i.payment_method " +
                     "FROM invoices i " +
                     "LEFT JOIN customers c ON i.customer_id = c.id " +
                     "LEFT JOIN employees e ON i.employee_id = e.id " +
                     "ORDER BY i.id DESC " +
                     "LIMIT 100";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Object[]{
                        rs.getInt("id"),
                        rs.getString("code"),
                        rs.getTimestamp("created_at"),
                        rs.getString("customer"),
                        rs.getString("employee"),
                        rs.getDouble("total"),
                        rs.getString("payment_method")
                });
            }
        }
        return list;
    }
}

package com.coffeeland.model;

/**
 * Model đại diện cho chi tiết một mặt hàng trong phiếu nhập kho.
 */
public class StockReceiptItem {
    private int id;
    private int receiptId;
    private int productId;
    private String productCode;
    private String productName;
    private String unit;
    private int quantity;
    private double costPrice;
    private double lineTotal;

    public StockReceiptItem() {
    }

    public StockReceiptItem(int id, int receiptId, int productId, String productCode, String productName, String unit, int quantity, double costPrice, double lineTotal) {
        this.id = id;
        this.receiptId = receiptId;
        this.productId = productId;
        this.productCode = productCode;
        this.productName = productName;
        this.unit = unit;
        this.quantity = quantity;
        this.costPrice = costPrice;
        this.lineTotal = lineTotal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReceiptId() {
        return receiptId;
    }

    public void setReceiptId(int receiptId) {
        this.receiptId = receiptId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(double costPrice) {
        this.costPrice = costPrice;
    }

    public double getLineTotal() {
        return lineTotal;
    }

    public void setLineTotal(double lineTotal) {
        this.lineTotal = lineTotal;
    }
}

package com.coffeeland.model;

/**
 * Model đại diện cho một mục trong giỏ hàng thanh toán.
 */
public class CartItem {
    private Product product;
    private int quantity;
    private String note = "";

    public CartItem() {
    }

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.note = "";
    }

    public CartItem(Product product, int quantity, String note) {
        this.product = product;
        this.quantity = quantity;
        this.note = (note != null) ? note.trim() : "";
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getNote() {
        return note != null ? note : "";
    }

    public void setNote(String note) {
        this.note = (note != null) ? note.trim() : "";
    }

    public double getLineTotal() {
        return (product != null) ? product.getPrice() * quantity : 0;
    }
}

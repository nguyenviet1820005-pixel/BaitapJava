package com.coffeeland.ui;

import com.coffeeland.model.User;
import com.coffeeland.util.UIUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Cửa sổ làm việc chính (Main Application Window) của hệ thống CoffeLand:
 * - Điều hướng Sidebar dọc phong cách Espresso Dark sang trọng.
 * - Quản lý trang trung tâm bằng CardLayout mượt mà.
 * - Thông tin tài khoản, đồng hồ thời gian thực và đăng xuất nhanh.
 */
public class MainFrame extends JFrame {

    private final User currentUser;
    private final JLabel lblClock = new JLabel();

    // CardLayout container
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);

    // Sidebar items tracking
    private final List<NavItem> navItems = new ArrayList<>();
    private final JPanel navButtonsContainer = new JPanel();

    // Views
    private DashboardPanel dashboardPanel;
    private SalesPanel salesPanel;
    private TableManagementPanel tablePanel;
    private ProductPanel productPanel;
    private CategoryPanel categoryPanel;
    private CustomerPanel customerPanel;
    private InventoryPanel inventoryPanel;
    private InvoicePanel invoicePanel;
    private EmployeePanel employeePanel;

    public MainFrame(User user) {
        this.currentUser = user;

        setTitle("CoffeLand - Hệ thống Quản lý Bán Cà phê & Kho hàng");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1360, 840);
        setMinimumSize(new Dimension(1160, 720));
        setLocationRelativeTo(null);

        initUI();
        startClock();
    }

    /**
     * Tải logo từ resources, scale về kích thước size x size px.
     */
    private JLabel loadLogoLabel(int size) {
        try {
            URL imgUrl = getClass().getClassLoader().getResource("images/logo.jpg");
            if (imgUrl == null) return null;
            BufferedImage original = ImageIO.read(imgUrl);
            Image scaled = original.getScaledInstance(size, size, Image.SCALE_SMOOTH);
            return new JLabel(new ImageIcon(scaled));
        } catch (Exception e) {
            return null;
        }
    }

    private void initUI() {
        setLayout(new BorderLayout());

        // 1. Sidebar dọc bên trái (Espresso Dark Navigation)
        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        // 2. Nội dung các màn hình bên phải (CardLayout)
        initPages();
        add(contentPanel, BorderLayout.CENTER);

        // Mặc định kích hoạt tab đầu tiên (Dashboard)
        switchPage("dashboard");
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout(0, 10));
        sidebar.setBackground(UIUtils.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(245, 0));
        sidebar.setBorder(new EmptyBorder(14, 10, 14, 10));

        // --- 1. Header Sidebar: Logo & Thương hiệu ---
        JPanel topSection = new JPanel();
        topSection.setOpaque(false);
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));

        JPanel brandRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        brandRow.setOpaque(false);

        JLabel logoImg = loadLogoLabel(40);
        if (logoImg != null) {
            brandRow.add(logoImg);
        }

        JLabel lblBrand = new JLabel("COFFEELAND");
        lblBrand.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblBrand.setForeground(Color.WHITE);
        brandRow.add(lblBrand);
        topSection.add(brandRow);

        JLabel lblTag = new JLabel("COFFEE & POS SYSTEM", SwingConstants.CENTER);
        lblTag.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblTag.setForeground(UIUtils.SIDEBAR_TEXT_MUTED);
        lblTag.setAlignmentX(Component.CENTER_ALIGNMENT);
        topSection.add(Box.createVerticalStrut(2));
        topSection.add(lblTag);
        topSection.add(Box.createVerticalStrut(10));

        // --- 2. Thẻ User Profile nhỏ gọn ---
        JPanel userCard = new JPanel(new BorderLayout(8, 0));
        userCard.setBackground(UIUtils.SIDEBAR_CARD_BG);
        userCard.setBorder(new CompoundBorder(
                new LineBorder(new Color(60, 35, 18), 1, true),
                new EmptyBorder(8, 10, 8, 10)
        ));
        userCard.setMaximumSize(new Dimension(225, 48));

        JLabel lblAvatar = new JLabel(currentUser.isAdmin() ? "👑" : "👤");
        lblAvatar.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblAvatar.setForeground(UIUtils.ACCENT_COLOR);
        userCard.add(lblAvatar, BorderLayout.WEST);

        String displayName = (currentUser.getEmployeeName() != null && !currentUser.getEmployeeName().isBlank())
                ? currentUser.getEmployeeName()
                : currentUser.getUsername();
        String roleText = currentUser.isAdmin() ? "Quản trị viên" : "Thu ngân / Bán hàng";

        JPanel userText = new JPanel();
        userText.setOpaque(false);
        userText.setLayout(new BoxLayout(userText, BoxLayout.Y_AXIS));

        JLabel lblName = new JLabel(displayName);
        lblName.setFont(UIUtils.FONT_BODY_BOLD);
        lblName.setForeground(Color.WHITE);

        JLabel lblRole = new JLabel(roleText);
        lblRole.setFont(UIUtils.FONT_SMALL);
        lblRole.setForeground(UIUtils.SIDEBAR_TEXT_MUTED);

        userText.add(lblName);
        userText.add(lblRole);
        userCard.add(userText, BorderLayout.CENTER);

        topSection.add(userCard);
        topSection.add(Box.createVerticalStrut(12));

        sidebar.add(topSection, BorderLayout.NORTH);

        // --- 3. Danh sách Menu Điều hướng ---
        navButtonsContainer.setOpaque(false);
        navButtonsContainer.setLayout(new BoxLayout(navButtonsContainer, BoxLayout.Y_AXIS));

        addNavButton("dashboard", "Tổng quan", "📊");
        addNavButton("pos", "Bán hàng (POS)", "🛒");
        addNavButton("tables", "Sơ đồ bàn", "🪑");
        addNavButton("products", "Menu đồ uống", "☕");
        addNavButton("categories", "Danh mục", "📋");
        addNavButton("customers", "Khách hàng", "👥");
        addNavButton("inventory", "Kho hàng", "📦");
        addNavButton("invoices", "Hóa đơn", "🧾");

        if (currentUser.isAdmin()) {
            addNavButton("employees", "Nhân viên", "👨‍💼");
        }

        JScrollPane menuScroll = new JScrollPane(navButtonsContainer);
        menuScroll.setBorder(null);
        menuScroll.setOpaque(false);
        menuScroll.getViewport().setOpaque(false);
        menuScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        menuScroll.getVerticalScrollBar().setUnitIncrement(12);
        sidebar.add(menuScroll, BorderLayout.CENTER);

        // --- 4. Footer Sidebar: Đồng hồ, Đổi mật khẩu, Đăng xuất ---
        JPanel bottomSection = new JPanel();
        bottomSection.setOpaque(false);
        bottomSection.setLayout(new BoxLayout(bottomSection, BoxLayout.Y_AXIS));

        lblClock.setFont(UIUtils.FONT_SMALL);
        lblClock.setForeground(new Color(220, 205, 190));
        lblClock.setAlignmentX(Component.CENTER_ALIGNMENT);
        bottomSection.add(lblClock);
        bottomSection.add(Box.createVerticalStrut(8));

        JPanel bottomBtns = new JPanel(new GridLayout(1, 2, 6, 0));
        bottomBtns.setOpaque(false);
        bottomBtns.setMaximumSize(new Dimension(225, 34));

        JButton btnChangePass = UIUtils.createCustomButton("Đổi mật khẩu", new Color(75, 42, 20), UIUtils.PRIMARY_HOVER, Color.WHITE);
        btnChangePass.setFont(UIUtils.FONT_SMALL);
        btnChangePass.addActionListener(e -> new ChangePasswordDialog(this, currentUser).setVisible(true));

        JButton btnLogout = UIUtils.createCustomButton("Đăng xuất", new Color(155, 25, 25), new Color(110, 10, 10), Color.WHITE);
        btnLogout.setFont(UIUtils.FONT_SMALL);
        btnLogout.addActionListener(e -> handleLogout());

        bottomBtns.add(btnChangePass);
        bottomBtns.add(btnLogout);
        bottomSection.add(bottomBtns);

        sidebar.add(bottomSection, BorderLayout.SOUTH);

        return sidebar;
    }

    private void addNavButton(String pageKey, String label, String icon) {
        JButton btn = UIUtils.createSidebarNavButton(label, icon, false);
        btn.addActionListener(e -> switchPage(pageKey));
        navButtonsContainer.add(btn);
        navButtonsContainer.add(Box.createVerticalStrut(3));
        navItems.add(new NavItem(pageKey, label, icon, btn));
    }

    private void initPages() {
        dashboardPanel = new DashboardPanel();
        salesPanel = new SalesPanel(currentUser, dashboardPanel::refresh);
        tablePanel = new TableManagementPanel();
        productPanel = new ProductPanel();
        categoryPanel = new CategoryPanel();
        customerPanel = new CustomerPanel();
        inventoryPanel = new InventoryPanel(currentUser);
        invoicePanel = new InvoicePanel();

        contentPanel.add(dashboardPanel, "dashboard");
        contentPanel.add(salesPanel, "pos");
        contentPanel.add(tablePanel, "tables");
        contentPanel.add(productPanel, "products");
        contentPanel.add(categoryPanel, "categories");
        contentPanel.add(customerPanel, "customers");
        contentPanel.add(inventoryPanel, "inventory");
        contentPanel.add(invoicePanel, "invoices");

        if (currentUser.isAdmin()) {
            employeePanel = new EmployeePanel();
            contentPanel.add(employeePanel, "employees");
        }
    }

    private void switchPage(String pageKey) {
        cardLayout.show(contentPanel, pageKey);

        // Cập nhật trạng thái active cho nút trên sidebar
        for (NavItem item : navItems) {
            boolean isActive = item.key.equals(pageKey);
            item.button.putClientProperty("active", isActive);
            item.button.setForeground(isActive ? Color.WHITE : new Color(220, 205, 190));
            item.button.setFont(new Font("Segoe UI", isActive ? Font.BOLD : Font.PLAIN, 14));
            item.button.repaint();
        }

        // Tự động làm mới dữ liệu khi chuyển tab
        if ("dashboard".equals(pageKey) && dashboardPanel != null) {
            dashboardPanel.refresh();
        } else if ("pos".equals(pageKey) && salesPanel != null) {
            salesPanel.loadData();
        } else if ("tables".equals(pageKey) && tablePanel != null) {
            tablePanel.loadTables();
        }
    }

    private void startClock() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Timer timer = new Timer(1000, e -> lblClock.setText(sdf.format(new Date())));
        timer.start();
    }

    private void handleLogout() {
        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn đăng xuất khỏi hệ thống?", "Xác nhận đăng xuất")) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }

    private static class NavItem {
        final String key;
        final String label;
        final String icon;
        final JButton button;

        NavItem(String key, String label, String icon, JButton button) {
            this.key = key;
            this.label = label;
            this.icon = icon;
            this.button = button;
        }
    }
}

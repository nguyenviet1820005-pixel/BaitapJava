package com.coffeeland.ui;

import com.coffeeland.dao.InventoryDAO;
import com.coffeeland.model.StockReceipt;
import com.coffeeland.model.StockReceiptItem;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Hộp thoại hiển thị chi tiết phiếu nhập kho hàng.
 */
public class StockReceiptDetailDialog extends JDialog {

    private final StockReceipt receipt;
    private final InventoryDAO inventoryDAO = new InventoryDAO();

    public StockReceiptDetailDialog(Window parent, StockReceipt receipt) {
        super(parent, "Chi tiết phiếu nhập kho - " + (receipt != null ? receipt.getCode() : ""), ModalityType.APPLICATION_MODAL);
        this.receipt = receipt;

        setSize(560, 520);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        initUI();
    }

    private void initUI() {
        if (receipt == null) {
            JLabel err = new JLabel("Không tìm thấy thông tin phiếu nhập kho.", SwingConstants.CENTER);
            add(err, BorderLayout.CENTER);
            return;
        }

        JPanel mainPanel = new JPanel(new BorderLayout(0, 10));
        mainPanel.setBackground(UIUtils.BG_MAIN);
        mainPanel.setBorder(new EmptyBorder(14, 16, 14, 16));

        JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                new EmptyBorder(16, 16, 16, 16)
        ));

        // Header thông tin phiếu nhập
        JPanel top = new JPanel(new GridLayout(3, 2, 8, 4));
        top.setOpaque(false);
        top.add(new JLabel("Mã phiếu nhập: " + receipt.getCode()));
        top.add(new JLabel("Ngày lập: " + UIUtils.formatDateTime(receipt.getCreatedAt())));
        top.add(new JLabel("Người lập: " + (receipt.getEmployeeName() != null ? receipt.getEmployeeName() : "Hệ thống")));
        top.add(new JLabel("Ghi chú: " + (receipt.getNote() != null && !receipt.getNote().isBlank() ? receipt.getNote() : "Không")));
        top.add(new JLabel("Tổng số lượng nhập: " + receipt.getTotalQuantity()));
        JLabel lblTotal = new JLabel("Tổng chi phí nhập: " + UIUtils.money(receipt.getTotalAmount()));
        lblTotal.setFont(UIUtils.FONT_BODY_BOLD);
        lblTotal.setForeground(UIUtils.PRIMARY_COLOR);
        top.add(lblTotal);

        card.add(top, BorderLayout.NORTH);

        // Bảng chi tiết mặt hàng
        String[] cols = {"STT", "Mã món", "Tên mặt hàng", "ĐVT", "Số lượng", "Giá nhập", "Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(26);
        table.setFont(UIUtils.FONT_BODY);
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(35);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setCellRenderer(center);
        table.getColumnModel().getColumn(4).setCellRenderer(center);

        loadItems(model);

        card.add(new JScrollPane(table), BorderLayout.CENTER);
        mainPanel.add(card, BorderLayout.CENTER);

        // Nút đóng
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        JButton btnClose = UIUtils.createSecondaryButton("Đóng");
        btnClose.addActionListener(e -> dispose());
        bottom.add(btnClose);

        mainPanel.add(bottom, BorderLayout.SOUTH);
        add(mainPanel, BorderLayout.CENTER);
    }

    private void loadItems(DefaultTableModel model) {
        try {
            List<StockReceiptItem> items = inventoryDAO.getReceiptDetails(receipt.getId());
            int stt = 1;
            for (StockReceiptItem item : items) {
                model.addRow(new Object[]{
                        stt++,
                        item.getProductCode(),
                        item.getProductName(),
                        item.getUnit(),
                        item.getQuantity(),
                        UIUtils.money(item.getCostPrice()),
                        UIUtils.money(item.getLineTotal())
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }
}

package com.coffeeland.ui;

import com.coffeeland.dao.CategoryDAO;
import com.coffeeland.model.Category;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Màn hình Quản lý Danh mục sản phẩm (Categories).
 */
public class CategoryPanel extends JPanel {

    private final CategoryDAO categoryDAO = new CategoryDAO();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Tên danh mục", "Mô tả", "Số món hiện có"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    private final JTextField txtName = new JTextField();
    private final JTextField txtDescription = new JTextField();
    private int selectedCategoryId = 0;

    public CategoryPanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadCategories();
    }

    private void initUI() {
        // 1. Tiêu đề
        JLabel lblTitle = new JLabel("QUAN LY DANH MUC SAN PHAM");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        add(lblTitle, BorderLayout.NORTH);

        // 2. Bảng dữ liệu bên trái
        JPanel leftCard = UIUtils.createCardPanel("DANH SÁCH DANH MỤC");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(center);

        table.getSelectionModel().addListSelectionListener(e -> handleSelectRow());
        leftCard.add(new JScrollPane(table), BorderLayout.CENTER);
        add(leftCard, BorderLayout.CENTER);

        // 3. Form thông tin bên phải
        JPanel rightCard = UIUtils.createCardPanel("THÔNG TIN DANH MỤC");
        rightCard.setPreferredSize(new Dimension(360, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        formBody.add(UIUtils.formRow("Tên danh mục *:", txtName));
        formBody.add(Box.createVerticalStrut(10));
        formBody.add(UIUtils.formRow("Mô tả chi tiết:", txtDescription));
        formBody.add(Box.createVerticalStrut(18));

        // Hàng nút bấm
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 8, 8));
        buttonPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Lưu");
        JButton btnClear = UIUtils.createSecondaryButton("+ Mới");
        JButton btnDelete = UIUtils.createDangerButton("Xóa");

        btnSave.addActionListener(e -> handleSave());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> handleDelete());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnDelete);

        formBody.add(buttonPanel);
        rightCard.add(formBody, BorderLayout.CENTER);
        add(rightCard, BorderLayout.EAST);
    }

    private void loadCategories() {
        try {
            tableModel.setRowCount(0);
            List<Category> list = categoryDAO.findAll();
            for (Category c : list) {
                tableModel.addRow(new Object[]{
                        c.getId(),
                        c.getName(),
                        c.getDescription() != null ? c.getDescription() : "",
                        c.getProductCount() + " món"
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleSelectRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        selectedCategoryId = (int) tableModel.getValueAt(row, 0);
        txtName.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        txtDescription.setText(String.valueOf(tableModel.getValueAt(row, 2)));
    }

    private void handleSave() {
        String name = txtName.getText().trim();
        String desc = txtDescription.getText().trim();

        if (name.isEmpty()) {
            UIUtils.warning(this, "Vui lòng nhập tên danh mục.");
            txtName.requestFocus();
            return;
        }

        try {
            Category category = new Category();
            category.setId(selectedCategoryId);
            category.setName(name);
            category.setDescription(desc);

            if (selectedCategoryId == 0) {
                categoryDAO.insert(category);
                UIUtils.info(this, "Thêm danh mục mới thành công!");
            } else {
                categoryDAO.update(category);
                UIUtils.info(this, "Cập nhật danh mục thành công!");
            }

            clearForm();
            loadCategories();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleDelete() {
        if (selectedCategoryId == 0) {
            UIUtils.warning(this, "Vui lòng chọn danh mục cần xóa từ bảng.");
            return;
        }

        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn xóa danh mục này?", "Xác nhận xóa")) {
            try {
                categoryDAO.delete(selectedCategoryId);
                UIUtils.info(this, "Xóa danh mục thành công!");
                clearForm();
                loadCategories();
            } catch (Exception e) {
                UIUtils.error(this, new Exception("Không thể xóa danh mục đang có sản phẩm. Hãy xóa hoặc chuyển danh mục cho các sản phẩm liên quan trước."));
            }
        }
    }

    private void clearForm() {
        selectedCategoryId = 0;
        txtName.setText("");
        txtDescription.setText("");
        table.clearSelection();
        txtName.requestFocus();
    }
}

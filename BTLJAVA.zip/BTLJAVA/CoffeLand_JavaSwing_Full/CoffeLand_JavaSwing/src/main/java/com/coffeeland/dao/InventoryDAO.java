package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.StockReceipt;
import com.coffeeland.model.StockReceiptItem;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Quản lý kho hàng & Phiếu nhập kho (Stock Receipts).
 */
public class InventoryDAO {

    /**
     * Lập phiếu nhập kho và tăng tồn kho cho sản phẩm.
     * Sử dụng Transaction để đảm bảo tính toàn vẹn dữ liệu.
     *
     * @param employeeId ID nhân viên lập phiếu
     * @param productId ID sản phẩm được nhập
     * @param quantity Số lượng nhập (> 0)
     * @param costPrice Giá vốn / Giá nhập mỗi đơn vị
     * @param note Ghi chú nhập kho
     * @return Mã phiếu nhập vừa tạo (Ví dụ: PN2608201020)
     */
    public String importStock(Integer employeeId, int productId, int quantity, double costPrice, String note) throws SQLException {
        if (quantity <= 0) {
            throw new SQLException("Số lượng nhập phải lớn hơn 0.");
        }
        if (costPrice < 0) {
            throw new SQLException("Giá nhập không được âm.");
        }

        String timestampStr = new SimpleDateFormat("yyMMddHHmmss").format(new Date());
        String receiptCode = "PN" + timestampStr;

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // Bắt đầu Transaction

            try {
                // 1. Thêm phiếu nhập kho
                String insertReceiptSql = "INSERT INTO stock_receipts(code, employee_id, note, created_at) VALUES(?, ?, ?, NOW())";
                int receiptId;
                try (PreparedStatement ps = conn.prepareStatement(insertReceiptSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, receiptCode);
                    if (employeeId == null || employeeId <= 0) {
                        ps.setNull(2, Types.INTEGER);
                    } else {
                        ps.setInt(2, employeeId);
                    }
                    ps.setString(3, note != null ? note.trim() : "");
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            receiptId = rs.getInt(1);
                        } else {
                            throw new SQLException("Không thể lấy mã định danh của phiếu nhập kho.");
                        }
                    }
                }

                // 2. Thêm chi tiết mặt hàng nhập kho
                String insertItemSql = "INSERT INTO stock_receipt_items(receipt_id, product_id, quantity, cost_price) VALUES(?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(insertItemSql)) {
                    ps.setInt(1, receiptId);
                    ps.setInt(2, productId);
                    ps.setInt(3, quantity);
                    ps.setDouble(4, costPrice);
                    ps.executeUpdate();
                }

                // 3. Tăng số lượng tồn kho của sản phẩm
                String updateStockSql = "UPDATE products SET stock = stock + ? WHERE id = ?";
                try (PreparedStatement ps = conn.prepareStatement(updateStockSql)) {
                    ps.setInt(1, quantity);
                    ps.setInt(2, productId);
                    ps.executeUpdate();
                }

                conn.commit(); // Hoàn tất Transaction
                return receiptCode;

            } catch (Exception e) {
                conn.rollback(); // Hoàn tác nếu xảy ra lỗi
                if (e instanceof SQLException) {
                    throw (SQLException) e;
                }
                throw new SQLException("Lỗi khi lập phiếu nhập kho: " + e.getMessage(), e);
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Lấy toàn bộ danh sách lịch sử phiếu nhập kho đã tạo.
     */
    public List<StockReceipt> getAllReceipts() throws SQLException {
        List<StockReceipt> list = new ArrayList<>();
        String sql = "SELECT sr.id, sr.code, sr.employee_id, COALESCE(e.full_name, 'Hệ thống') AS employee_name, " +
                     "sr.note, sr.created_at, " +
                     "COALESCE(SUM(sri.quantity), 0) AS total_qty, " +
                     "COALESCE(SUM(sri.quantity * sri.cost_price), 0) AS total_amount " +
                     "FROM stock_receipts sr " +
                     "LEFT JOIN employees e ON sr.employee_id = e.id " +
                     "LEFT JOIN stock_receipt_items sri ON sr.id = sri.receipt_id " +
                     "GROUP BY sr.id, sr.code, sr.employee_id, e.full_name, sr.note, sr.created_at " +
                     "ORDER BY sr.id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                StockReceipt r = new StockReceipt();
                r.setId(rs.getInt("id"));
                r.setCode(rs.getString("code"));
                int empId = rs.getInt("employee_id");
                r.setEmployeeId(rs.wasNull() ? null : empId);
                r.setEmployeeName(rs.getString("employee_name"));
                r.setNote(rs.getString("note"));
                r.setCreatedAt(rs.getTimestamp("created_at"));
                r.setTotalQuantity(rs.getInt("total_qty"));
                r.setTotalAmount(rs.getDouble("total_amount"));
                list.add(r);
            }
        }
        return list;
    }

    /**
     * Lấy chi tiết các mặt hàng trong một phiếu nhập kho.
     */
    public List<StockReceiptItem> getReceiptDetails(int receiptId) throws SQLException {
        List<StockReceiptItem> items = new ArrayList<>();
        String sql = "SELECT sri.id, sri.receipt_id, sri.product_id, p.code AS product_code, " +
                     "p.name AS product_name, p.unit, sri.quantity, sri.cost_price, " +
                     "(sri.quantity * sri.cost_price) AS line_total " +
                     "FROM stock_receipt_items sri " +
                     "JOIN products p ON sri.product_id = p.id " +
                     "WHERE sri.receipt_id = ? " +
                     "ORDER BY sri.id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, receiptId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    StockReceiptItem item = new StockReceiptItem();
                    item.setId(rs.getInt("id"));
                    item.setReceiptId(rs.getInt("receipt_id"));
                    item.setProductId(rs.getInt("product_id"));
                    item.setProductCode(rs.getString("product_code"));
                    item.setProductName(rs.getString("product_name"));
                    item.setUnit(rs.getString("unit"));
                    item.setQuantity(rs.getInt("quantity"));
                    item.setCostPrice(rs.getDouble("cost_price"));
                    item.setLineTotal(rs.getDouble("line_total"));
                    items.add(item);
                }
            }
        }
        return items;
    }
}

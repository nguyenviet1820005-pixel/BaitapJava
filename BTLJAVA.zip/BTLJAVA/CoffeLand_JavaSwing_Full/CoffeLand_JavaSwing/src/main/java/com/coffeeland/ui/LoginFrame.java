package com.coffeeland.ui;

import com.coffeeland.dao.UserDAO;
import com.coffeeland.model.User;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;

/**
 * Màn hình Đăng nhập hệ thống quản lý CoffeLand.
 */
public class LoginFrame extends JFrame {

    private final JTextField txtUsername = new JTextField("admin", 18);
    private final JPasswordField txtPassword = new JPasswordField("admin123", 18);
    private final JCheckBox chkShowPassword = new JCheckBox("Hiện mật khẩu");
    private final UserDAO userDAO = new UserDAO();

    public LoginFrame() {
        setTitle("CoffeLand - Đăng nhập hệ thống");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 560);
        setLocationRelativeTo(null);
        setResizable(false);

        initUI();
    }

    /**
     * Tải logo từ resources, scale về kích thước size x size px.
     * Trả về null nếu không tìm thấy file.
     */
    private JLabel loadLogoLabel(int size) {
        try {
            URL imgUrl = getClass().getClassLoader().getResource("images/logo.jpg");
            if (imgUrl == null) return null;
            BufferedImage original = ImageIO.read(imgUrl);
            Image scaled = original.getScaledInstance(size, size, Image.SCALE_SMOOTH);
            return new JLabel(new ImageIcon(scaled));
        } catch (Exception e) {
            return null; // Fallback an toàn, không crash app
        }
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UIUtils.BG_MAIN);

        // 1. Header Banner phong cách Quán Cà Phê — nền nâu đậm sang trọng
        JPanel banner = new JPanel();
        banner.setBackground(new Color(42, 22, 8));   // Nâu espresso rất đậm
        banner.setBorder(new EmptyBorder(20, 20, 20, 20));
        banner.setLayout(new BoxLayout(banner, BoxLayout.Y_AXIS));

        // Logo hình ảnh 100px — nổi bật trên nền đậm
        JLabel logoImgLabel = loadLogoLabel(100);
        if (logoImgLabel != null) {
            logoImgLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            banner.add(logoImgLabel);
            banner.add(Box.createVerticalStrut(12));
        }

        JLabel logoIcon = new JLabel("COFFEELAND", SwingConstants.CENTER);
        logoIcon.setFont(new Font("Segoe UI", Font.BOLD, 26));
        logoIcon.setForeground(Color.WHITE);
        logoIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Đường kẻ phân cách trắng mờ
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(255, 255, 255, 60));
        sep.setMaximumSize(new Dimension(200, 1));

        JLabel subTitle = new JLabel("HỆ THỐNG QUẢN LÝ BÁN CÀ PHÊ & KHO HÀNG", SwingConstants.CENTER);
        subTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        subTitle.setForeground(new Color(210, 185, 155));   // Kem cà phê sữa
        subTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        banner.add(logoIcon);
        banner.add(Box.createVerticalStrut(6));
        banner.add(sep);
        banner.add(Box.createVerticalStrut(6));
        banner.add(subTitle);

        root.add(banner, BorderLayout.NORTH);

        // 2. Thẻ Form đăng nhập
        JPanel formCard = new JPanel();
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(new CompoundBorder(
                new EmptyBorder(16, 24, 20, 24),
                new CompoundBorder(
                        new LineBorder(UIUtils.BORDER_COLOR, 1, true),
                        new EmptyBorder(18, 20, 18, 20)
                )
        ));
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));

        JLabel lblFormTitle = new JLabel("ĐĂNG NHẬP HỆ THỐNG");
        lblFormTitle.setFont(UIUtils.FONT_HEADER);
        lblFormTitle.setForeground(UIUtils.PRIMARY_COLOR);
        lblFormTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Logo nhỏ bên trong form card
        JLabel logoInForm = loadLogoLabel(56);
        if (logoInForm != null) {
            logoInForm.setAlignmentX(Component.CENTER_ALIGNMENT);
            formCard.add(logoInForm);
            formCard.add(Box.createVerticalStrut(8));
        }
        formCard.add(lblFormTitle);
        formCard.add(Box.createVerticalStrut(16));

        formCard.add(UIUtils.formRow("Tài khoản:", txtUsername));
        formCard.add(Box.createVerticalStrut(10));
        formCard.add(UIUtils.formRow("Mật khẩu:", txtPassword));
        formCard.add(Box.createVerticalStrut(6));

        // Hiện / ẩn mật khẩu
        chkShowPassword.setOpaque(false);
        chkShowPassword.setFont(UIUtils.FONT_SMALL);
        chkShowPassword.setForeground(UIUtils.TEXT_MUTED);
        chkShowPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });
        formCard.add(chkShowPassword);
        formCard.add(Box.createVerticalStrut(14));

        // Nút Đăng nhập - màu cam đỏ nổi bật nhất
        JButton btnLogin = UIUtils.createLoginButton("  🔑  ĐĂNG NHẬP  ");
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.setPreferredSize(new Dimension(220, 46));
        btnLogin.setMaximumSize(new Dimension(220, 46));
        btnLogin.addActionListener(e -> handleLogin());
        getRootPane().setDefaultButton(btnLogin);
        formCard.add(btnLogin);

        root.add(formCard, BorderLayout.CENTER);
        add(root);
    }

    private void handleLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            UIUtils.warning(this, "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.");
            return;
        }

        try {
            User user = userDAO.login(username, password);
            if (user == null) {
                UIUtils.warning(this, "Sai tên đăng nhập hoặc mật khẩu! Vui lòng thử lại.");
                txtPassword.setText("");
                txtPassword.requestFocus();
                return;
            }

            dispose(); // Đóng LoginFrame
            new MainFrame(user).setVisible(true); // Mở MainFrame

        } catch (Exception ex) {
            UIUtils.error(this, new Exception("Không thể kết nối cơ sở dữ liệu MySQL.\n" +
                    "1. Hãy đảm bảo MySQL Server đang chạy (XAMPP / MySQL Service).\n" +
                    "2. Đã import file database/coffeeland.sql.\n" +
                    "3. Chi tiết: " + ex.getMessage()));
        }
    }
}

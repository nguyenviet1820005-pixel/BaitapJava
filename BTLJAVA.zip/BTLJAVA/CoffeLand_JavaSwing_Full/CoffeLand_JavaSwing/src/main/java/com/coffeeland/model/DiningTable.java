package com.coffeeland.model;

/**
 * Model đại diện cho Bàn phục vụ / Khu vực quán cà phê CoffeLand.
 */
public class DiningTable {
    private int id;
    private String code;
    private String name;
    private String area;
    private String status; // EMPTY, OCCUPIED, RESERVED
    private boolean active;

    public DiningTable() {
        this.status = "EMPTY";
        this.area = "Tầng 1";
        this.active = true;
    }

    public DiningTable(int id, String code, String name, String area, String status, boolean active) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.area = area;
        this.status = status;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isOccupied() {
        return "OCCUPIED".equalsIgnoreCase(status);
    }

    public boolean isReserved() {
        return "RESERVED".equalsIgnoreCase(status);
    }

    public boolean isEmpty() {
        return "EMPTY".equalsIgnoreCase(status) || status == null;
    }

    public String getStatusDisplay() {
        if ("OCCUPIED".equalsIgnoreCase(status)) {
            return "🔴 Có khách";
        } else if ("RESERVED".equalsIgnoreCase(status)) {
            return "🟡 Đã đặt";
        }
        return "🟢 Trống";
    }

    @Override
    public String toString() {
        return name + " (" + area + " - " + getStatusDisplay() + ")";
    }
}

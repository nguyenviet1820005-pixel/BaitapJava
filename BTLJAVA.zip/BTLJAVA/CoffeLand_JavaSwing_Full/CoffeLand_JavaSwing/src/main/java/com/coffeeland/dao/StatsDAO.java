package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Xử lý truy vấn thống kê, báo cáo và dữ liệu Dashboard cho CoffeLand.
 */
public class StatsDAO {

    /**
     * Lấy các chỉ số KPI thống kê tổng quan của hệ thống.
     */
    public Map<String, Number> getDashboard() throws SQLException {
        Map<String, Number> stats = new LinkedHashMap<>();

        try (Connection conn = DBConnection.getConnection()) {
            stats.put("products", queryScalarInt(conn, "SELECT COUNT(*) FROM products WHERE active = 1"));
            stats.put("customers", queryScalarInt(conn, "SELECT COUNT(*) FROM customers"));
            stats.put("lowStock",
                    queryScalarInt(conn, "SELECT COUNT(*) FROM products WHERE active = 1 AND stock <= 10"));
            stats.put("ordersToday",
                    queryScalarInt(conn, "SELECT COUNT(*) FROM invoices WHERE DATE(created_at) = CURDATE()"));
            stats.put("revenueToday", queryScalarDouble(conn,
                    "SELECT COALESCE(SUM(total), 0) FROM invoices WHERE DATE(created_at) = CURDATE()"));
            stats.put("ordersMonth", queryScalarInt(conn,
                    "SELECT COUNT(*) FROM invoices WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"));
            stats.put("revenueMonth", queryScalarDouble(conn,
                    "SELECT COALESCE(SUM(total), 0) FROM invoices WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"));
        }
        return stats;
    }

    /**
     * Lấy danh sách Top sản phẩm bán chạy nhất kèm số lượng và doanh thu.
     */
    public List<Object[]> getTopSellingProducts(int limit) throws SQLException {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT p.code, p.name, c.name AS category_name, " +
                "COALESCE(SUM(ii.quantity), 0) AS total_sold, " +
                "COALESCE(SUM(ii.line_total), 0) AS total_sales " +
                "FROM invoice_items ii " +
                "JOIN products p ON ii.product_id = p.id " +
                "JOIN categories c ON p.category_id = c.id " +
                "GROUP BY p.id, p.code, p.name, c.name " +
                "ORDER BY total_sold DESC " +
                "LIMIT ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit > 0 ? limit : 5);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Object[] {
                            rs.getString("code"),
                            rs.getString("name"),
                            rs.getString("category_name"),
                            rs.getInt("total_sold"),
                            rs.getDouble("total_sales")
                    });
                }
            }
        }
        return list;
    }

    /**
     * Lấy doanh thu từng ngày trong 7 ngày gần nhất để vẽ biểu đồ cột.
     * 
     * @return Danh sách [Ngày (dd/MM), Doanh thu (Double)]
     */
    public List<Object[]> getRevenueLast7Days() throws SQLException {
        List<Object[]> result = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM");
        SimpleDateFormat sqlDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        Map<String, Double> dbData = new LinkedHashMap<>();
        String sql = "SELECT DATE(created_at) AS order_date, COALESCE(SUM(total), 0) AS daily_rev " +
                "FROM invoices " +
                "WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) " +
                "GROUP BY DATE(created_at) " +
                "ORDER BY order_date ASC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                dbData.put(rs.getString("order_date"), rs.getDouble("daily_rev"));
            }
        }

        // Tạo đủ 7 ngày liên tục (kể cả những ngày doanh thu = 0)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -6);
        for (int i = 0; i < 7; i++) {
            Date date = cal.getTime();
            String key = sqlDateFormat.format(date);
            String label = sdf.format(date);
            double val = dbData.getOrDefault(key, 0.0);
            result.add(new Object[] { label, val });
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        return result;
    }

    /**
     * Lấy tỷ trọng doanh thu theo từng danh mục sản phẩm để vẽ biểu đồ tròn/Donut.
     * @return Danh sách [Tên danh mục (String), Doanh thu (Double), Tỷ lệ phần trăm (Double)]
     */
    public List<Object[]> getRevenueByCategory() throws SQLException {
        List<Object[]> result = new ArrayList<>();
        String sql = "SELECT c.name AS category_name, COALESCE(SUM(ii.line_total), 0) AS total_revenue " +
                     "FROM categories c " +
                     "JOIN products p ON c.id = p.category_id " +
                     "JOIN invoice_items ii ON p.id = ii.product_id " +
                     "GROUP BY c.id, c.name " +
                     "HAVING total_revenue > 0 " +
                     "ORDER BY total_revenue DESC";

        double totalAll = 0.0;
        List<Object[]> rawList = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String catName = rs.getString("category_name");
                double rev = rs.getDouble("total_revenue");
                totalAll += rev;
                rawList.add(new Object[]{catName, rev});
            }
        }

        if (totalAll > 0) {
            for (Object[] item : rawList) {
                String name = (String) item[0];
                double rev = (Double) item[1];
                double percent = (rev / totalAll) * 100.0;
                result.add(new Object[]{name, rev, percent});
            }
        }

        return result;
    }

    private int queryScalarInt(Connection conn, String sql) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private double queryScalarDouble(Connection conn, String sql) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }
}

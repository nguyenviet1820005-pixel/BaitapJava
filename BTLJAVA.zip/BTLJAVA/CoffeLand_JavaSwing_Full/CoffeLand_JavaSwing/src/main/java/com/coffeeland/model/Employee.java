package com.coffeeland.model;

/**
 * Model đại diện cho thông tin nhân viên quán cà phê.
 */
public class Employee {
    private int id;
    private String code;
    private String fullName;
    private String phone;
    private String email;
    private String position;
    private boolean active;
    private String username; // Tài khoản hệ thống liên kết

    public Employee() {
        this.active = true;
        this.position = "Nhân viên";
    }

    public Employee(int id, String code, String fullName, String phone, String email, String position, boolean active) {
        this.id = id;
        this.code = code;
        this.fullName = fullName;
        this.phone = phone;
        this.email = email;
        this.position = position;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return code + " - " + fullName + " (" + position + ")";
    }
}

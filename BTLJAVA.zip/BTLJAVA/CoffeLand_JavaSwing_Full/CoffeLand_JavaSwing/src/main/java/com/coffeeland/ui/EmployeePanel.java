package com.coffeeland.ui;

import com.coffeeland.dao.EmployeeDAO;
import com.coffeeland.model.Employee;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Màn hình Quản lý Nhân sự & Nhân viên (Dành cho Quản trị viên ADMIN).
 */
public class EmployeePanel extends JPanel {

    private final EmployeeDAO employeeDAO = new EmployeeDAO();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Mã NV", "Họ và tên", "Số điện thoại", "Email", "Chức vụ", "Tài khoản hệ thống", "Trạng thái"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    private final JTextField txtCode = new JTextField();
    private final JTextField txtFullName = new JTextField();
    private final JTextField txtPhone = new JTextField();
    private final JTextField txtEmail = new JTextField();
    private final JComboBox<String> cboPosition = new JComboBox<>(new String[]{"Quản lý", "Thu ngân", "Pha chế (Barista)", "Phục vụ", "Tạp vụ"});
    private final JCheckBox chkActive = new JCheckBox("Đang làm việc", true);
    private int selectedEmployeeId = 0;

    public EmployeePanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadEmployees();
    }

    private void initUI() {
        // 1. Tiêu đề
        JLabel lblTitle = new JLabel("QUAN LY NHAN SU & NHAN VIEN");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        add(lblTitle, BorderLayout.NORTH);

        // 2. Bảng dữ liệu nhân viên
        JPanel centerCard = UIUtils.createCardPanel("DANH SÁCH NHÂN SỰ");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(45);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(center);
        table.getColumnModel().getColumn(5).setPreferredWidth(110);
        table.getColumnModel().getColumn(5).setCellRenderer(center);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);
        table.getColumnModel().getColumn(6).setCellRenderer(center);

        table.getSelectionModel().addListSelectionListener(e -> handleSelectRow());
        centerCard.add(new JScrollPane(table), BorderLayout.CENTER);
        add(centerCard, BorderLayout.CENTER);

        // 3. Form thông tin nhân viên bên phải
        JPanel rightCard = UIUtils.createCardPanel("THÔNG TIN NHÂN VIÊN");
        rightCard.setPreferredSize(new Dimension(380, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        formBody.add(UIUtils.formRow("Mã NV *:", txtCode));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Họ và tên *:", txtFullName));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Số điện thoại:", txtPhone));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Email:", txtEmail));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Chức vụ:", cboPosition));
        formBody.add(Box.createVerticalStrut(8));

        chkActive.setOpaque(false);
        chkActive.setFont(UIUtils.FONT_BODY_BOLD);
        chkActive.setForeground(UIUtils.PRIMARY_COLOR);
        formBody.add(chkActive);
        formBody.add(Box.createVerticalStrut(18));

        // Nút thao tác
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 8, 8));
        buttonPanel.setOpaque(false);

        JButton btnSave = UIUtils.createPrimaryButton("Lưu");
        JButton btnClear = UIUtils.createSecondaryButton("+ Mới");
        JButton btnDelete = UIUtils.createDangerButton("Xóa");

        btnSave.addActionListener(e -> handleSave());
        btnClear.addActionListener(e -> clearForm());
        btnDelete.addActionListener(e -> handleDelete());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnDelete);

        formBody.add(buttonPanel);
        rightCard.add(formBody, BorderLayout.CENTER);
        add(rightCard, BorderLayout.EAST);
    }

    private void loadEmployees() {
        try {
            tableModel.setRowCount(0);
            List<Employee> list = employeeDAO.findAll();
            for (Employee e : list) {
                tableModel.addRow(new Object[]{
                        e.getId(),
                        e.getCode(),
                        e.getFullName(),
                        e.getPhone() != null ? e.getPhone() : "",
                        e.getEmail() != null ? e.getEmail() : "",
                        e.getPosition(),
                        e.getUsername() != null ? "👤 " + e.getUsername() : "-",
                        e.isActive() ? "✅ Đang làm việc" : "❌ Đã nghỉ việc"
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleSelectRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        selectedEmployeeId = (int) tableModel.getValueAt(row, 0);
        txtCode.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        txtFullName.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        txtPhone.setText(String.valueOf(tableModel.getValueAt(row, 3)));
        txtEmail.setText(String.valueOf(tableModel.getValueAt(row, 4)));

        String pos = String.valueOf(tableModel.getValueAt(row, 5));
        cboPosition.setSelectedItem(pos);

        String activeStr = String.valueOf(tableModel.getValueAt(row, 7));
        chkActive.setSelected(activeStr.contains("Đang làm việc"));
    }

    private void handleSave() {
        String code = txtCode.getText().trim();
        String name = txtFullName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        String position = String.valueOf(cboPosition.getSelectedItem());
        boolean active = chkActive.isSelected();

        if (code.isEmpty() || name.isEmpty()) {
            UIUtils.warning(this, "Vui lòng nhập đầy đủ Mã nhân viên và Họ tên.");
            return;
        }

        try {
            if (employeeDAO.isCodeExists(code, selectedEmployeeId)) {
                UIUtils.warning(this, "Mã nhân viên '" + code + "' đã tồn tại trong hệ thống.");
                txtCode.requestFocus();
                return;
            }

            Employee e = new Employee();
            e.setId(selectedEmployeeId);
            e.setCode(code);
            e.setFullName(name);
            e.setPhone(phone);
            e.setEmail(email);
            e.setPosition(position);
            e.setActive(active);

            if (selectedEmployeeId == 0) {
                employeeDAO.insert(e);
                UIUtils.info(this, "Thêm mới nhân viên thành công!");
            } else {
                employeeDAO.update(e);
                UIUtils.info(this, "Cập nhật nhân viên thành công!");
            }

            clearForm();
            loadEmployees();

        } catch (Exception ex) {
            UIUtils.error(this, ex);
        }
    }

    private void handleDelete() {
        if (selectedEmployeeId == 0) {
            UIUtils.warning(this, "Vui lòng chọn nhân viên cần xóa từ bảng.");
            return;
        }

        if (UIUtils.confirm(this, "Bạn có chắc chắn muốn xóa nhân viên này?", "Xác nhận xóa")) {
            try {
                employeeDAO.delete(selectedEmployeeId);
                UIUtils.info(this, "Xóa nhân viên thành công!");
                clearForm();
                loadEmployees();
            } catch (Exception e) {
                UIUtils.error(this, new Exception("Nhân viên này đã liên kết với hóa đơn hoặc tài khoản đăng nhập. Hãy tắt trạng thái 'Đang làm việc' thay vì xóa."));
            }
        }
    }

    private void clearForm() {
        selectedEmployeeId = 0;
        txtCode.setText("");
        txtFullName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        cboPosition.setSelectedIndex(0);
        chkActive.setSelected(true);
        table.clearSelection();
        txtCode.requestFocus();
    }
}

package com.coffeeland.ui;

import com.coffeeland.dao.InvoiceDAO;
import com.coffeeland.model.Invoice;
import com.coffeeland.util.ExcelExporter;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Màn hình Quản lý Danh sách Hóa đơn Bán hàng, Tra cứu Chi tiết & Xuất Excel (Invoices).
 */
public class InvoicePanel extends JPanel {

    private final InvoiceDAO invoiceDAO = new InvoiceDAO();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Mã hóa đơn", "Thời gian", "Bàn phục vụ", "Khách hàng", "Thu ngân", "Tạm tính", "Giảm giá", "Tổng thanh toán", "Hình thức"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    // Bộ lọc
    private final JTextField txtSearch = new JTextField();
    private final JComboBox<String> cboDateFilter = new JComboBox<>(new String[]{"Tất cả thời gian", "Hôm nay", "7 ngày gần nhất", "Tháng này"});

    // Thống kê chân bảng
    private final JLabel lblTotalCount = new JLabel("Tổng đơn: 0");
    private final JLabel lblTotalRevenue = new JLabel("Tổng doanh thu: 0 ₫");

    private List<Invoice> cachedInvoices;

    public InvoicePanel() {
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadInvoices();
    }

    private void initUI() {
        // 1. Tiêu đề và Bộ lọc tìm kiếm
        JPanel topPanel = new JPanel(new BorderLayout(12, 12));
        topPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("QUAN LY HOA DON BAN HANG");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        topPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel filterBar = new JPanel(new BorderLayout(10, 0));
        filterBar.setOpaque(false);

        JPanel filterInputs = new JPanel(new GridLayout(1, 2, 10, 0));
        filterInputs.setOpaque(false);

        JPanel p1 = new JPanel(new BorderLayout(6, 0));
        p1.setOpaque(false);
        p1.add(new JLabel("Từ khóa:"), BorderLayout.WEST);
        p1.add(txtSearch, BorderLayout.CENTER);

        JPanel p2 = new JPanel(new BorderLayout(6, 0));
        p2.setOpaque(false);
        p2.add(new JLabel("Thời gian:"), BorderLayout.WEST);
        p2.add(cboDateFilter, BorderLayout.CENTER);

        filterInputs.add(p1);
        filterInputs.add(p2);
        filterBar.add(filterInputs, BorderLayout.CENTER);

        JPanel filterButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        filterButtons.setOpaque(false);
        JButton btnSearch = UIUtils.createPrimaryButton("🔍 Tìm");
        JButton btnReload = UIUtils.createSecondaryButton("🔄 Tải lại");
        JButton btnExportExcel = UIUtils.createSuccessButton("📊 Xuất Excel");

        btnExportExcel.addActionListener(e -> ExcelExporter.exportTableToExcel(this, table, "Danh_sach_hoa_don_CoffeLand"));

        filterButtons.add(btnSearch);
        filterButtons.add(btnReload);
        filterButtons.add(btnExportExcel);
        filterBar.add(filterButtons, BorderLayout.EAST);

        topPanel.add(filterBar, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        btnSearch.addActionListener(e -> loadInvoices());
        txtSearch.addActionListener(e -> loadInvoices());
        cboDateFilter.addActionListener(e -> loadInvoices());
        btnReload.addActionListener(e -> {
            txtSearch.setText("");
            cboDateFilter.setSelectedIndex(0);
            loadInvoices();
        });

        // 2. Bảng dữ liệu hóa đơn
        JPanel centerCard = UIUtils.createCardPanel("DANH SÁCH HÓA ĐƠN");
        UIUtils.styleTable(table);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(0).setCellRenderer(center);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(1).setCellRenderer(center);
        table.getColumnModel().getColumn(2).setPreferredWidth(125);
        table.getColumnModel().getColumn(2).setCellRenderer(center);
        table.getColumnModel().getColumn(3).setPreferredWidth(95);
        table.getColumnModel().getColumn(3).setCellRenderer(center);
        table.getColumnModel().getColumn(9).setPreferredWidth(90);
        table.getColumnModel().getColumn(9).setCellRenderer(center);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(6).setPreferredWidth(90);
        table.getColumnModel().getColumn(6).setCellRenderer(right);
        table.getColumnModel().getColumn(7).setPreferredWidth(80);
        table.getColumnModel().getColumn(7).setCellRenderer(right);
        table.getColumnModel().getColumn(8).setPreferredWidth(105);
        table.getColumnModel().getColumn(8).setCellRenderer(right);

        // Double click để xem chi tiết hóa đơn
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    handleViewDetail();
                }
            }
        });

        centerCard.add(new JScrollPane(table), BorderLayout.CENTER);

        // 3. Thanh tổng kết và nút xem chi tiết
        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setOpaque(false);
        bottomBar.setBorder(new EmptyBorder(8, 0, 0, 0));

        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 0));
        statsPanel.setOpaque(false);
        lblTotalCount.setFont(UIUtils.FONT_BODY_BOLD);
        lblTotalRevenue.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalRevenue.setForeground(UIUtils.PRIMARY_COLOR);
        statsPanel.add(lblTotalCount);
        statsPanel.add(lblTotalRevenue);
        bottomBar.add(statsPanel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonPanel.setOpaque(false);
        JButton btnViewDetail = UIUtils.createPrimaryButton("🔍 Xem chi tiết & In hóa đơn");
        btnViewDetail.addActionListener(e -> handleViewDetail());
        buttonPanel.add(btnViewDetail);
        bottomBar.add(buttonPanel, BorderLayout.EAST);

        centerCard.add(bottomBar, BorderLayout.SOUTH);
        add(centerCard, BorderLayout.CENTER);
    }

    private void loadInvoices() {
        try {
            tableModel.setRowCount(0);
            String keyword = txtSearch.getText().trim();

            Date fromDate = null;
            Date toDate = null;
            Calendar cal = Calendar.getInstance();

            int dateOption = cboDateFilter.getSelectedIndex();
            if (dateOption == 1) { // Hôm nay
                fromDate = cal.getTime();
                toDate = cal.getTime();
            } else if (dateOption == 2) { // 7 ngày gần nhất
                toDate = cal.getTime();
                cal.add(Calendar.DAY_OF_YEAR, -7);
                fromDate = cal.getTime();
            } else if (dateOption == 3) { // Tháng này
                toDate = cal.getTime();
                cal.set(Calendar.DAY_OF_MONTH, 1);
                fromDate = cal.getTime();
            }

            cachedInvoices = invoiceDAO.findInvoices(keyword, fromDate, toDate);

            double sumRevenue = 0;
            for (Invoice inv : cachedInvoices) {
                sumRevenue += inv.getTotal();
                tableModel.addRow(new Object[]{
                        inv.getId(),
                        inv.getCode(),
                        UIUtils.formatDateTime(inv.getCreatedAt()),
                        inv.getTableName() != null ? inv.getTableName() : "Mang về",
                        inv.getCustomerName(),
                        inv.getEmployeeName(),
                        UIUtils.money(inv.getSubtotal()),
                        inv.getDiscount() > 0 ? UIUtils.money(inv.getDiscount()) : "-",
                        UIUtils.money(inv.getTotal()),
                        inv.getPaymentMethod()
                });
            }

            lblTotalCount.setText("Tổng hóa đơn: " + cachedInvoices.size() + " đơn");
            lblTotalRevenue.setText("Tổng doanh thu: " + UIUtils.money(sumRevenue));

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleViewDetail() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtils.warning(this, "Vui lòng chọn một hóa đơn từ bảng để xem chi tiết.");
            return;
        }

        int invoiceId = (int) tableModel.getValueAt(row, 0);
        if (cachedInvoices != null) {
            for (Invoice inv : cachedInvoices) {
                if (inv.getId() == invoiceId) {
                    Window parent = SwingUtilities.getWindowAncestor(this);
                    new InvoiceDetailDialog(parent, inv).setVisible(true);
                    return;
                }
            }
        }
    }
}

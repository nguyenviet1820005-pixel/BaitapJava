package com.coffeeland.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Tiện ích băm mật khẩu bằng thuật toán SHA-256 an toàn.
 */
public final class PasswordUtils {

    private PasswordUtils() {
    }

    /**
     * Băm chuỗi mật khẩu đầu vào sang chuỗi Hex SHA-256.
     * @param password Mật khẩu gốc dạng chuỗi
     * @return Chuỗi băm hex 64 ký tự
     */
    public static String sha256(String password) {
        if (password == null) {
            password = "";
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Thuật toán SHA-256 không được hỗ trợ", e);
        }
    }
}

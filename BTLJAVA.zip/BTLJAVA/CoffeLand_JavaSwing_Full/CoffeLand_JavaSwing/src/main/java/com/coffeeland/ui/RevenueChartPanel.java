package com.coffeeland.ui;

import com.coffeeland.util.UIUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Component vẽ biểu đồ cột Doanh thu 7 ngày gần nhất bằng Java 2D Graphics.
 * Cải tiến: Highlight cột hôm nay, bóng đổ nhẹ, tooltip doanh thu trên đỉnh cột.
 */
public class RevenueChartPanel extends JPanel {

    private List<Object[]> chartData = new ArrayList<>();

    public RevenueChartPanel() {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(500, 240));
    }

    public void setData(List<Object[]> data) {
        this.chartData = (data != null) ? data : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        int padLeft = 55;
        int padRight = 20;
        int padTop = 32;
        int padBottom = 44;

        int plotWidth  = width  - padLeft - padRight;
        int plotHeight = height - padTop  - padBottom;

        // Trống dữ liệu
        if (chartData == null || chartData.isEmpty()) {
            g2.setFont(UIUtils.FONT_BODY);
            g2.setColor(UIUtils.TEXT_MUTED);
            String msg = "Chưa có dữ liệu doanh thu trong 7 ngày gần nhất";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            g2.dispose();
            return;
        }

        // Tìm doanh thu max để tính tỉ lệ
        double maxRev = 100_000.0;
        for (Object[] item : chartData) {
            double val = (Double) item[1];
            if (val > maxRev) maxRev = val;
        }
        maxRev = Math.ceil(maxRev / 100_000.0) * 100_000.0;

        // 1. Vẽ nền vùng biểu đồ
        g2.setColor(new Color(252, 250, 248));
        g2.fillRect(padLeft, padTop, plotWidth, plotHeight);

        // 2. Vẽ các đường lưới ngang (Grid Lines)
        int gridCount = 4;
        for (int i = 0; i <= gridCount; i++) {
            int y = padTop + (int) (plotHeight * (1.0 - (double) i / gridCount));

            // Đường lưới
            if (i == 0) {
                g2.setColor(UIUtils.BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
            } else {
                g2.setColor(new Color(230, 228, 225));
                g2.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f,
                        new float[]{4f, 4f}, 0f));
            }
            g2.drawLine(padLeft, y, width - padRight, y);

            // Nhãn trục Y
            double val = (maxRev / gridCount) * i;
            String label = formatShortMoney(val);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2.setColor(UIUtils.TEXT_MUTED);
            g2.setStroke(new BasicStroke(1f));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, padLeft - fm.stringWidth(label) - 6, y + 4);
        }

        // 3. Vẽ từng cột
        int n = chartData.size();
        int barWidth  = Math.max(22, (plotWidth / n) - 20);
        int gap       = plotWidth / n;
        // Cột cuối cùng = hôm nay (theo thứ tự query giảm dần → index 0 là mới nhất)
        // tùy theo data order; thường index n-1 = hôm nay nếu tăng dần ngày
        int todayIndex = n - 1;

        for (int i = 0; i < n; i++) {
            Object[] item     = chartData.get(i);
            String dateLabel  = (String) item[0];
            double rev        = (Double) item[1];
            boolean isToday   = (i == todayIndex);

            int barHeight = (rev > 0) ? Math.max(4, (int) ((rev / maxRev) * plotHeight)) : 0;
            int x = padLeft + (i * gap) + (gap - barWidth) / 2;
            int y = padTop + plotHeight - barHeight;

            // Track nền
            g2.setColor(isToday ? new Color(255, 244, 230) : new Color(245, 242, 238));
            g2.setStroke(new BasicStroke(1f));
            g2.fill(new RoundRectangle2D.Float(x, padTop, barWidth, plotHeight, 8, 8));

            // Cột chính
            if (barHeight > 0) {
                Color colorTop    = isToday ? new Color(200, 130, 60)  : new Color(111, 78, 55);
                Color colorBottom = isToday ? new Color(240, 200, 140) : new Color(160, 110, 70);
                GradientPaint gp  = new GradientPaint(x, y, colorTop, x, y + barHeight, colorBottom);
                g2.setPaint(gp);
                RoundRectangle2D rect = new RoundRectangle2D.Float(x, y, barWidth, barHeight, 8, 8);
                g2.fill(rect);

                // Viền cột
                g2.setColor(isToday ? new Color(180, 110, 40, 200) : new Color(80, 52, 30, 160));
                g2.setStroke(new BasicStroke(1f));
                g2.draw(rect);
            }

            // Giá trị tiền trên đỉnh cột
            g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
            FontMetrics fm = g2.getFontMetrics();
            if (rev > 0) {
                g2.setColor(isToday ? UIUtils.ACCENT_COLOR : UIUtils.PRIMARY_COLOR);
                String revText = formatShortMoney(rev);
                int textX = x + (barWidth - fm.stringWidth(revText)) / 2;
                int textY = (barHeight > 18) ? (y - 4) : (y - 14);
                // Nền nhỏ cho label tiền
                g2.setColor(new Color(255, 255, 255, 200));
                g2.fillRoundRect(textX - 3, textY - fm.getAscent(), fm.stringWidth(revText) + 6, fm.getHeight() + 2, 4, 4);
                g2.setColor(isToday ? UIUtils.ACCENT_COLOR : UIUtils.PRIMARY_COLOR);
                g2.drawString(revText, textX, textY);
            }

            // Nhãn ngày
            g2.setFont(new Font("Segoe UI", isToday ? Font.BOLD : Font.PLAIN, 10));
            g2.setColor(isToday ? UIUtils.ACCENT_COLOR : UIUtils.TEXT_DARK);
            FontMetrics fmDay = g2.getFontMetrics();
            int labelX = x + (barWidth - fmDay.stringWidth(dateLabel)) / 2;
            g2.drawString(dateLabel, labelX, padTop + plotHeight + 16);

            // Chấm tròn đánh dấu "Hôm nay"
            if (isToday) {
                g2.setColor(UIUtils.ACCENT_COLOR);
                int dotX = x + barWidth / 2 - 4;
                int dotY  = padTop + plotHeight + 22;
                g2.fillOval(dotX, dotY, 8, 8);
            }
        }

        // 4. Trục X
        g2.setColor(UIUtils.BORDER_COLOR);
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawLine(padLeft, padTop + plotHeight, width - padRight, padTop + plotHeight);

        g2.dispose();
    }

    private String formatShortMoney(double value) {
        if (value >= 1_000_000) {
            return String.format("%.1fM", value / 1_000_000.0).replace(".0M", "M");
        } else if (value >= 1_000) {
            return String.format("%.0fk", value / 1_000.0);
        }
        return String.format("%.0f", value);
    }
}

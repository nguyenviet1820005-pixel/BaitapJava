package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.CartItem;
import com.coffeeland.model.Invoice;
import com.coffeeland.model.InvoiceItem;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Hóa đơn bán hàng (Invoices) và Chi tiết hóa đơn (Invoice Items).
 */
public class InvoiceDAO {

    /**
     * Tạo hóa đơn bán hàng mới kèm trừ tồn kho tự động, đổi điểm tích lũy và cập nhật trạng thái bàn.
     * Sử dụng Transaction để đảm bảo tính toàn vẹn dữ liệu.
     *
     * @param customerId ID khách hàng (có thể null nếu là khách lẻ)
     * @param employeeId ID nhân viên tạo đơn
     * @param tableId ID bàn phục vụ (có thể null nếu mang về)
     * @param items Danh sách các món trong giỏ hàng
     * @param discount Số tiền giảm giá
     * @param usedPoints Số điểm tích lũy khách hàng sử dụng để giảm giá (1 điểm = 1.000 ₫)
     * @param paymentMethod Phương thức thanh toán (Tiền mặt, Chuyển khoản, Thẻ)
     * @return Mã hóa đơn vừa tạo (Ví dụ: HD2608201015)
     */
    private static volatile boolean noteColumnChecked = false;

    private static void ensureNoteColumn(Connection conn) {
        if (noteColumnChecked) return;
        synchronized (InvoiceDAO.class) {
            if (noteColumnChecked) return;
            try (Statement st = conn.createStatement()) {
                st.executeUpdate("ALTER TABLE invoice_items ADD COLUMN note VARCHAR(255) NULL DEFAULT ''");
            } catch (SQLException ignored) {
                // Đã tồn tại cột note
            }
            noteColumnChecked = true;
        }
    }

    public String createInvoice(Integer customerId, Integer employeeId, Integer tableId, List<CartItem> items, double discount, int usedPoints, String paymentMethod) throws SQLException {
        if (items == null || items.isEmpty()) {
            throw new SQLException("Giỏ hàng đang trống, không thể thanh toán.");
        }

        // Tạo mã hóa đơn dựa trên thời gian thực
        String timestampStr = new SimpleDateFormat("yyMMddHHmmss").format(new Date());
        String invoiceCode = "HD" + timestampStr;

        try (Connection conn = DBConnection.getConnection()) {
            ensureNoteColumn(conn);
            conn.setAutoCommit(false); // Bắt đầu Transaction

            try {
                double subtotal = items.stream().mapToDouble(CartItem::getLineTotal).sum();
                double pointDiscount = usedPoints * 1000.0;
                double totalDiscount = discount + pointDiscount;
                double total = Math.max(0, subtotal - totalDiscount);

                // 1. Thêm bản ghi vào bảng invoices
                String insertInvoiceSql = "INSERT INTO invoices(code, customer_id, employee_id, table_id, subtotal, discount, total, payment_method, created_at) " +
                                          "VALUES(?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                int invoiceId;
                try (PreparedStatement ps = conn.prepareStatement(insertInvoiceSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, invoiceCode);
                    if (customerId == null || customerId <= 0) {
                        ps.setNull(2, Types.INTEGER);
                    } else {
                        ps.setInt(2, customerId);
                    }
                    if (employeeId == null || employeeId <= 0) {
                        ps.setNull(3, Types.INTEGER);
                    } else {
                        ps.setInt(3, employeeId);
                    }
                    if (tableId == null || tableId <= 0) {
                        ps.setNull(4, Types.INTEGER);
                    } else {
                        ps.setInt(4, tableId);
                    }
                    ps.setDouble(5, subtotal);
                    ps.setDouble(6, totalDiscount);
                    ps.setDouble(7, total);
                    ps.setString(8, paymentMethod != null ? paymentMethod : "Tiền mặt");
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            invoiceId = rs.getInt(1);
                        } else {
                            throw new SQLException("Không thể lấy mã định danh của hóa đơn vừa tạo.");
                        }
                    }
                }

                // 2. Thêm từng món vào invoice_items và trừ tồn kho trong products
                String checkStockSql = "SELECT name, stock FROM products WHERE id = ? FOR UPDATE";
                String insertItemSql = "INSERT INTO invoice_items(invoice_id, product_id, quantity, unit_price, line_total, note) VALUES(?, ?, ?, ?, ?, ?)";
                String updateStockSql = "UPDATE products SET stock = stock - ? WHERE id = ?";

                for (CartItem item : items) {
                    int prodId = item.getProduct().getId();
                    int buyQty = item.getQuantity();

                    // Kiểm tra tồn kho khóa dòng
                    try (PreparedStatement psCheck = conn.prepareStatement(checkStockSql)) {
                        psCheck.setInt(1, prodId);
                        try (ResultSet rs = psCheck.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException("Sản phẩm không tồn tại trong hệ thống: " + item.getProduct().getName());
                            }
                            int currentStock = rs.getInt("stock");
                            if (currentStock < buyQty) {
                                throw new SQLException("Món '" + rs.getString("name") + "' không đủ tồn kho (Còn lại: " + currentStock + ", Cần: " + buyQty + ").");
                            }
                        }
                    }

                    // Lưu chi tiết hóa đơn
                    try (PreparedStatement psItem = conn.prepareStatement(insertItemSql)) {
                        psItem.setInt(1, invoiceId);
                        psItem.setInt(2, prodId);
                        psItem.setInt(3, buyQty);
                        psItem.setDouble(4, item.getProduct().getPrice());
                        psItem.setDouble(5, item.getLineTotal());
                        psItem.setString(6, item.getNote() != null ? item.getNote() : "");
                        psItem.executeUpdate();
                    }

                    // Trừ tồn kho
                    try (PreparedStatement psStock = conn.prepareStatement(updateStockSql)) {
                        psStock.setInt(1, buyQty);
                        psStock.setInt(2, prodId);
                        psStock.executeUpdate();
                    }
                }

                // 3. Xử lý điểm tích lũy của khách hàng: Trừ điểm đã dùng và cộng điểm mới (10.000 ₫ = 1 điểm)
                if (customerId != null && customerId > 0) {
                    int earnedPoints = (int) (total / 10000);
                    int netPointChange = earnedPoints - usedPoints;

                    String pointSql = "UPDATE customers SET points = GREATEST(0, points + ?) WHERE id = ?";
                    try (PreparedStatement psPoint = conn.prepareStatement(pointSql)) {
                        psPoint.setInt(1, netPointChange);
                        psPoint.setInt(2, customerId);
                        psPoint.executeUpdate();
                    }
                }

                // 4. Giải phóng bàn về trạng thái EMPTY (Trống)
                if (tableId != null && tableId > 0) {
                    String tableSql = "UPDATE dining_tables SET status = 'EMPTY' WHERE id = ?";
                    try (PreparedStatement psTable = conn.prepareStatement(tableSql)) {
                        psTable.setInt(1, tableId);
                        psTable.executeUpdate();
                    }
                }

                conn.commit(); // Hoàn tất Transaction
                return invoiceCode;

            } catch (Exception e) {
                conn.rollback(); // Hoàn tác nếu có lỗi
                if (e instanceof SQLException) {
                    throw (SQLException) e;
                }
                throw new SQLException("Lỗi trong quá trình tạo hóa đơn: " + e.getMessage(), e);
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Tương thích method cũ cho các component khác.
     */
    public String createInvoice(Integer customerId, Integer employeeId, List<CartItem> items, double discount, String paymentMethod) throws SQLException {
        return createInvoice(customerId, employeeId, null, items, discount, 0, paymentMethod);
    }

    /**
     * Lấy danh sách hóa đơn kèm lọc tìm kiếm từ khóa và khoảng thời gian.
     */
    public List<Invoice> findInvoices(String keyword, Date fromDate, Date toDate) throws SQLException {
        List<Invoice> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT i.id, i.code, i.customer_id, COALESCE(c.full_name, 'Khách lẻ') AS customer_name, " +
                "c.phone AS customer_phone, i.employee_id, COALESCE(e.full_name, '-') AS employee_name, " +
                "i.table_id, COALESCE(dt.name, 'Mang về') AS table_name, " +
                "i.created_at, i.subtotal, i.discount, i.total, i.payment_method " +
                "FROM invoices i " +
                "LEFT JOIN customers c ON i.customer_id = c.id " +
                "LEFT JOIN employees e ON i.employee_id = e.id " +
                "LEFT JOIN dining_tables dt ON i.table_id = dt.id " +
                "WHERE 1=1 "
        );

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (i.code LIKE ? OR c.full_name LIKE ? OR e.full_name LIKE ? OR dt.name LIKE ?) ");
        }
        if (fromDate != null) {
            sql.append("AND DATE(i.created_at) >= ? ");
        }
        if (toDate != null) {
            sql.append("AND DATE(i.created_at) <= ? ");
        }
        sql.append("ORDER BY i.id DESC LIMIT 200");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                String k = "%" + keyword.trim() + "%";
                ps.setString(idx++, k);
                ps.setString(idx++, k);
                ps.setString(idx++, k);
                ps.setString(idx++, k);
            }
            if (fromDate != null) {
                ps.setDate(idx++, new java.sql.Date(fromDate.getTime()));
            }
            if (toDate != null) {
                ps.setDate(idx++, new java.sql.Date(toDate.getTime()));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Invoice inv = new Invoice();
                    inv.setId(rs.getInt("id"));
                    inv.setCode(rs.getString("code"));
                    int cId = rs.getInt("customer_id");
                    inv.setCustomerId(rs.wasNull() ? null : cId);
                    inv.setCustomerName(rs.getString("customer_name"));
                    inv.setCustomerPhone(rs.getString("customer_phone"));
                    int eId = rs.getInt("employee_id");
                    inv.setEmployeeId(rs.wasNull() ? null : eId);
                    inv.setEmployeeName(rs.getString("employee_name"));
                    int tId = rs.getInt("table_id");
                    inv.setTableId(rs.wasNull() ? null : tId);
                    inv.setTableName(rs.getString("table_name"));
                    inv.setCreatedAt(rs.getTimestamp("created_at"));
                    inv.setSubtotal(rs.getDouble("subtotal"));
                    inv.setDiscount(rs.getDouble("discount"));
                    inv.setTotal(rs.getDouble("total"));
                    inv.setPaymentMethod(rs.getString("payment_method"));
                    list.add(inv);
                }
            }
        }
        return list;
    }

    /**
     * Lấy chi tiết các món trong một hóa đơn theo ID hóa đơn.
     */
    public List<InvoiceItem> getInvoiceItems(int invoiceId) throws SQLException {
        List<InvoiceItem> items = new ArrayList<>();
        String sql = "SELECT ii.id, ii.invoice_id, ii.product_id, p.code AS product_code, " +
                     "p.name AS product_name, p.unit, ii.quantity, ii.unit_price, ii.line_total, " +
                     "COALESCE(ii.note, '') AS note " +
                     "FROM invoice_items ii " +
                     "JOIN products p ON ii.product_id = p.id " +
                     "WHERE ii.invoice_id = ? " +
                     "ORDER BY ii.id ASC";

        try (Connection conn = DBConnection.getConnection()) {
            ensureNoteColumn(conn);
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, invoiceId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        InvoiceItem item = new InvoiceItem();
                        item.setId(rs.getInt("id"));
                        item.setInvoiceId(rs.getInt("invoice_id"));
                        item.setProductId(rs.getInt("product_id"));
                        item.setProductCode(rs.getString("product_code"));
                        item.setProductName(rs.getString("product_name"));
                        item.setUnit(rs.getString("unit"));
                        item.setQuantity(rs.getInt("quantity"));
                        item.setUnitPrice(rs.getDouble("unit_price"));
                        item.setLineTotal(rs.getDouble("line_total"));
                        item.setNote(rs.getString("note"));
                        items.add(item);
                    }
                }
            }
        }
        return items;
    }

    /**
     * Lấy đầy đủ hóa đơn kèm chi tiết món theo mã hóa đơn.
     */
    public Invoice getInvoiceByCode(String code) throws SQLException {
        String sql = "SELECT i.id, i.code, i.customer_id, COALESCE(c.full_name, 'Khách lẻ') AS customer_name, " +
                     "c.phone AS customer_phone, i.employee_id, COALESCE(e.full_name, '-') AS employee_name, " +
                     "i.table_id, COALESCE(dt.name, 'Mang về') AS table_name, " +
                     "i.created_at, i.subtotal, i.discount, i.total, i.payment_method " +
                     "FROM invoices i " +
                     "LEFT JOIN customers c ON i.customer_id = c.id " +
                     "LEFT JOIN employees e ON i.employee_id = e.id " +
                     "LEFT JOIN dining_tables dt ON i.table_id = dt.id " +
                     "WHERE i.code = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Invoice inv = new Invoice();
                    inv.setId(rs.getInt("id"));
                    inv.setCode(rs.getString("code"));
                    int cId = rs.getInt("customer_id");
                    inv.setCustomerId(rs.wasNull() ? null : cId);
                    inv.setCustomerName(rs.getString("customer_name"));
                    inv.setCustomerPhone(rs.getString("customer_phone"));
                    int eId = rs.getInt("employee_id");
                    inv.setEmployeeId(rs.wasNull() ? null : eId);
                    inv.setEmployeeName(rs.getString("employee_name"));
                    int tId = rs.getInt("table_id");
                    inv.setTableId(rs.wasNull() ? null : tId);
                    inv.setTableName(rs.getString("table_name"));
                    inv.setCreatedAt(rs.getTimestamp("created_at"));
                    inv.setSubtotal(rs.getDouble("subtotal"));
                    inv.setDiscount(rs.getDouble("discount"));
                    inv.setTotal(rs.getDouble("total"));
                    inv.setPaymentMethod(rs.getString("payment_method"));
                    inv.setItems(getInvoiceItems(inv.getId()));
                    return inv;
                }
            }
        }
        return null;
    }
}

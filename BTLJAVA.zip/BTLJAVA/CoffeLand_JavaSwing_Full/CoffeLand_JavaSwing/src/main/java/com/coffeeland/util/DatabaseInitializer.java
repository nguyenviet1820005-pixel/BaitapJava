package com.coffeeland.util;

import com.coffeeland.config.DBConnection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitializer {
    public static void main(String[] args) {
        System.out.println("Checking MySQL connection...");
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement()) {
            System.out.println("Connected to MySQL successfully! Executing database/coffeeland.sql...");

            BufferedReader reader = new BufferedReader(new FileReader("database/coffeeland.sql"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().startsWith("--") || line.trim().isEmpty()) continue;
                sb.append(line).append(" ");
                if (line.trim().endsWith(";")) {
                    String sql = sb.toString().trim();
                    if (!sql.toLowerCase().startsWith("create database") && !sql.toLowerCase().startsWith("use ")) {
                        try {
                            st.execute(sql);
                        } catch (Exception ex) {
                            System.err.println("Notice on statement: " + ex.getMessage());
                        }
                    }
                    sb.setLength(0);
                }
            }
            reader.close();
            System.out.println("Database initialization / update finished successfully!");
        } catch (Exception e) {
            System.out.println("MySQL is currently not active or not yet started: " + e.getMessage());
        }
    }
}

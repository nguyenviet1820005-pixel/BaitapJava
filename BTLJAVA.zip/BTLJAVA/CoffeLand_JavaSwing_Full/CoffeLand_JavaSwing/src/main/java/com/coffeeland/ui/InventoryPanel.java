package com.coffeeland.ui;

import com.coffeeland.dao.InventoryDAO;
import com.coffeeland.dao.ProductDAO;
import com.coffeeland.model.Product;
import com.coffeeland.model.StockReceipt;
import com.coffeeland.model.User;
import com.coffeeland.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Màn hình Quản lý Kho hàng & Nhập kho (Inventory).
 * Gồm 2 tab con: (1) Lập phiếu nhập kho nhanh, (2) Lịch sử phiếu nhập & Chi tiết.
 */
public class InventoryPanel extends JPanel {

    private final ProductDAO productDAO = new ProductDAO();
    private final InventoryDAO inventoryDAO = new InventoryDAO();
    private final User currentUser;

    // --- Tab 1: Nhập kho ---
    private final DefaultTableModel stockModel = new DefaultTableModel(
            new String[]{"ID", "Mã món", "Tên sản phẩm / Đồ uống", "Danh mục", "ĐVT", "Tồn kho hiện tại"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable stockTable = new JTable(stockModel);
    private final JComboBox<Product> cboProduct = new JComboBox<>();
    private final JSpinner spinQuantity = new JSpinner(new SpinnerNumberModel(10, 1, 100000, 1));
    private final JTextField txtCostPrice = new JTextField("0");
    private final JTextField txtNote = new JTextField();
    private final JLabel lblEstimatedTotal = new JLabel("0 ₫");

    // Bộ lọc tồn kho nhanh
    private final JTextField txtSearchStock = new JTextField();
    private final JCheckBox chkOnlyLowStock = new JCheckBox("Chỉ xem món sắp hết (≤ 10)");
    private List<Product> cachedStockProducts = new java.util.ArrayList<>();

    // --- Tab 2: Lịch sử phiếu nhập ---
    private final DefaultTableModel historyModel = new DefaultTableModel(
            new String[]{"ID", "Mã phiếu nhập", "Thời gian", "Người lập phiếu", "Tổng SL nhập", "Tổng chi phí", "Ghi chú"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable historyTable = new JTable(historyModel);
    private List<StockReceipt> cachedReceipts;

    public InventoryPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout(14, 14));
        setBackground(UIUtils.BG_MAIN);
        setBorder(new EmptyBorder(16, 18, 16, 18));

        initUI();
        loadProducts();
        loadHistory();
    }

    private void initUI() {
        // 1. Tiêu đề
        JLabel lblTitle = new JLabel("QUẢN LÝ KHO HÀNG & NHẬP HÀNG");
        lblTitle.setFont(UIUtils.FONT_TITLE);
        lblTitle.setForeground(UIUtils.PRIMARY_COLOR);
        add(lblTitle, BorderLayout.NORTH);

        // 2. TabbedPane chuyển giữa Lập phiếu nhập và Lịch sử
        JTabbedPane subTabs = new JTabbedPane();
        subTabs.setFont(UIUtils.FONT_BODY_BOLD);

        subTabs.addTab("Lập phiếu nhập kho", createImportTab());
        subTabs.addTab("Lịch sử phiếu nhập kho", createHistoryTab());

        add(subTabs, BorderLayout.CENTER);
    }

    private JPanel createImportTab() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBackground(UIUtils.BG_MAIN);
        panel.setBorder(new EmptyBorder(12, 4, 4, 4));

        // Bảng tồn kho bên trái
        JPanel leftCard = UIUtils.createCardPanel("TỒN KHO SẢN PHẨM HIỆN TẠI");
        leftCard.setLayout(new BorderLayout(0, 8));

        // Thanh tìm kiếm & lọc tồn kho nhanh
        JPanel filterRow = new JPanel(new BorderLayout(8, 0));
        filterRow.setOpaque(false);
        filterRow.setBorder(new EmptyBorder(0, 0, 4, 0));

        JPanel searchP = new JPanel(new BorderLayout(6, 0));
        searchP.setOpaque(false);
        searchP.add(new JLabel("Tìm món:"), BorderLayout.WEST);
        txtSearchStock.putClientProperty("JTextField.placeholderText", "Tìm theo tên hoặc mã món...");
        searchP.add(txtSearchStock, BorderLayout.CENTER);

        filterRow.add(searchP, BorderLayout.CENTER);
        chkOnlyLowStock.setOpaque(false);
        chkOnlyLowStock.setFont(UIUtils.FONT_BODY_BOLD);
        chkOnlyLowStock.setForeground(UIUtils.DANGER_COLOR);
        filterRow.add(chkOnlyLowStock, BorderLayout.EAST);
        leftCard.add(filterRow, BorderLayout.NORTH);

        // Lắng nghe tìm kiếm tồn kho tức thì
        txtSearchStock.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filterStockTable(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filterStockTable(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterStockTable(); }
        });
        chkOnlyLowStock.addActionListener(e -> filterStockTable());

        UIUtils.styleTable(stockTable);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        stockTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        stockTable.getColumnModel().getColumn(0).setCellRenderer(center);
        stockTable.getColumnModel().getColumn(1).setPreferredWidth(75);
        stockTable.getColumnModel().getColumn(1).setCellRenderer(center);
        stockTable.getColumnModel().getColumn(4).setPreferredWidth(55);
        stockTable.getColumnModel().getColumn(4).setCellRenderer(center);
        stockTable.getColumnModel().getColumn(5).setPreferredWidth(120);

        // Row-level color renderer dựa trên tồn kho
        stockTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, col);
                l.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                l.setFont(UIUtils.FONT_BODY);

                if (isSelected) return l;

                // Lấy giá trị tồn kho từ cột 5 để quyết định màu hàng
                Object stockCell = stockModel.getValueAt(row, 5);
                String stockText = (stockCell != null) ? stockCell.toString() : "";

                if (stockText.contains("❌") || stockText.contains("Hết hàng")) {
                    l.setBackground(new Color(255, 225, 225)); // Đỏ nhạt
                    l.setForeground(UIUtils.DANGER_COLOR);
                    if (col == 5) l.setFont(UIUtils.FONT_BODY_BOLD);
                } else if (stockText.contains("⚠") || stockText.contains("Sắp hết")) {
                    l.setBackground(new Color(255, 245, 210)); // Vàng nhạt
                    l.setForeground(UIUtils.WARNING_COLOR);
                    if (col == 5) l.setFont(UIUtils.FONT_BODY_BOLD);
                } else {
                    l.setBackground(row % 2 == 0 ? Color.WHITE : new Color(250, 248, 245));
                    l.setForeground(UIUtils.TEXT_DARK);
                }

                if (col == 0 || col == 1 || col == 4) {
                    l.setHorizontalAlignment(SwingConstants.CENTER);
                } else {
                    l.setHorizontalAlignment(SwingConstants.LEFT);
                }
                return l;
            }
        });

        // Khi bấm vào dòng trên bảng -> Tự chọn sản phẩm tương ứng trong ComboBox
        stockTable.getSelectionModel().addListSelectionListener(e -> {
            int row = stockTable.getSelectedRow();
            if (row >= 0) {
                int prodId = (int) stockModel.getValueAt(row, 0);
                for (int i = 0; i < cboProduct.getItemCount(); i++) {
                    if (cboProduct.getItemAt(i).getId() == prodId) {
                        cboProduct.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });

        leftCard.add(new JScrollPane(stockTable), BorderLayout.CENTER);
        panel.add(leftCard, BorderLayout.CENTER);

        // Form lập phiếu nhập bên phải
        JPanel rightCard = UIUtils.createCardPanel("LẬP PHIẾU NHẬP KHO");
        rightCard.setPreferredSize(new Dimension(380, 0));

        JPanel formBody = new JPanel();
        formBody.setOpaque(false);
        formBody.setLayout(new BoxLayout(formBody, BoxLayout.Y_AXIS));

        formBody.add(UIUtils.formRow("Sản phẩm *:", cboProduct));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Số lượng nhập *:", spinQuantity));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Giá nhập / đơn vị:", txtCostPrice));
        formBody.add(Box.createVerticalStrut(8));
        formBody.add(UIUtils.formRow("Ghi chú nhập:", txtNote));
        formBody.add(Box.createVerticalStrut(10));

        // Tính tạm tính
        lblEstimatedTotal.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblEstimatedTotal.setForeground(UIUtils.PRIMARY_COLOR);
        formBody.add(UIUtils.formRow("Tổng tiền nhập:", lblEstimatedTotal));
        formBody.add(Box.createVerticalStrut(18));

        // Lắng nghe tính tiền tạm tính
        spinQuantity.addChangeListener(e -> calcEstimatedTotal());
        txtCostPrice.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { calcEstimatedTotal(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { calcEstimatedTotal(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { calcEstimatedTotal(); }
        });

        JButton btnSubmit = UIUtils.createPrimaryButton("📥 XÁC NHẬN NHẬP KHO");
        btnSubmit.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSubmit.setPreferredSize(new Dimension(220, 40));
        btnSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnSubmit.addActionListener(e -> handleSubmitImport());

        formBody.add(btnSubmit);
        rightCard.add(formBody, BorderLayout.CENTER);
        panel.add(rightCard, BorderLayout.EAST);

        return panel;
    }

    private JPanel createHistoryTab() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBackground(UIUtils.BG_MAIN);
        panel.setBorder(new EmptyBorder(12, 4, 4, 4));

        JPanel card = UIUtils.createCardPanel("DANH SÁCH CÁC PHIẾU NHẬP KHO ĐÃ LẬP");
        UIUtils.styleTable(historyTable);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        historyTable.getColumnModel().getColumn(0).setPreferredWidth(45);
        historyTable.getColumnModel().getColumn(0).setCellRenderer(center);
        historyTable.getColumnModel().getColumn(1).setPreferredWidth(120);
        historyTable.getColumnModel().getColumn(1).setCellRenderer(center);
        historyTable.getColumnModel().getColumn(2).setPreferredWidth(130);
        historyTable.getColumnModel().getColumn(2).setCellRenderer(center);
        historyTable.getColumnModel().getColumn(4).setPreferredWidth(80);
        historyTable.getColumnModel().getColumn(4).setCellRenderer(center);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        historyTable.getColumnModel().getColumn(5).setPreferredWidth(110);
        historyTable.getColumnModel().getColumn(5).setCellRenderer(right);

        card.add(new JScrollPane(historyTable), BorderLayout.CENTER);

        // Thanh nút bấm bên dưới
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        bottomBar.setOpaque(false);

        JButton btnViewDetail = UIUtils.createPrimaryButton("Xem chi tiết phiếu");
        JButton btnReload = UIUtils.createSecondaryButton("Tải lại lịch sử");

        btnViewDetail.addActionListener(e -> handleViewDetail());
        btnReload.addActionListener(e -> loadHistory());

        bottomBar.add(btnViewDetail);
        bottomBar.add(btnReload);
        card.add(bottomBar, BorderLayout.SOUTH);

        panel.add(card, BorderLayout.CENTER);
        return panel;
    }

    private void loadProducts() {
        try {
            cboProduct.removeAllItems();
            cachedStockProducts = productDAO.findActive();
            for (Product p : cachedStockProducts) {
                cboProduct.addItem(p);
            }
            filterStockTable();
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void filterStockTable() {
        stockModel.setRowCount(0);
        String kw = txtSearchStock.getText().trim().toLowerCase();
        boolean onlyLow = chkOnlyLowStock.isSelected();

        for (Product p : cachedStockProducts) {
            if (onlyLow && p.getStock() > 10) {
                continue;
            }
            if (!kw.isEmpty()) {
                boolean matchCode = p.getCode() != null && p.getCode().toLowerCase().contains(kw);
                boolean matchName = p.getName() != null && p.getName().toLowerCase().contains(kw);
                if (!matchCode && !matchName) continue;
            }

            String stockDisplay;
            if (p.getStock() == 0) {
                stockDisplay = "❌ Hết hàng";
            } else if (p.getStock() <= 10) {
                stockDisplay = "⚠️ Sắp hết (" + p.getStock() + ")";
            } else {
                stockDisplay = "✅ Còn (" + p.getStock() + ")";
            }

            stockModel.addRow(new Object[]{
                    p.getId(),
                    p.getCode(),
                    p.getName(),
                    p.getCategoryName(),
                    p.getUnit(),
                    stockDisplay
            });
        }
    }

    private void loadHistory() {
        try {
            historyModel.setRowCount(0);
            cachedReceipts = inventoryDAO.getAllReceipts();

            for (StockReceipt r : cachedReceipts) {
                historyModel.addRow(new Object[]{
                        r.getId(),
                        r.getCode(),
                        UIUtils.formatDateTime(r.getCreatedAt()),
                        r.getEmployeeName() != null ? r.getEmployeeName() : "-",
                        r.getTotalQuantity(),
                        UIUtils.money(r.getTotalAmount()),
                        r.getNote() != null ? r.getNote() : ""
                });
            }
        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void calcEstimatedTotal() {
        try {
            int q = (int) spinQuantity.getValue();
            double cost = Double.parseDouble(txtCostPrice.getText().replaceAll("[^0-9.]", ""));
            lblEstimatedTotal.setText(UIUtils.money(q * cost));
        } catch (Exception e) {
            lblEstimatedTotal.setText("0 ₫");
        }
    }

    private void handleSubmitImport() {
        Product p = (Product) cboProduct.getSelectedItem();
        if (p == null) {
            UIUtils.warning(this, "Vui lòng chọn sản phẩm cần nhập kho.");
            return;
        }

        int qty = (int) spinQuantity.getValue();
        if (qty <= 0) {
            UIUtils.warning(this, "Số lượng nhập phải lớn hơn 0.");
            return;
        }

        double cost = 0;
        try {
            cost = Double.parseDouble(txtCostPrice.getText().trim());
            if (cost < 0) throw new NumberFormatException();
        } catch (Exception e) {
            UIUtils.warning(this, "Giá nhập không hợp lệ (phải là số ≥ 0).");
            txtCostPrice.requestFocus();
            return;
        }

        String note = txtNote.getText().trim();

        try {
            String receiptCode = inventoryDAO.importStock(
                    currentUser.getEmployeeId(),
                    p.getId(),
                    qty,
                    cost,
                    note
            );

            UIUtils.info(this, "Lập phiếu nhập kho thành công!\nMã phiếu: " + receiptCode + "\nĐã cộng " + qty + " vào tồn kho của món: " + p.getName());

            // Reset form
            spinQuantity.setValue(10);
            txtCostPrice.setText("0");
            txtNote.setText("");
            lblEstimatedTotal.setText("0 ₫");

            loadProducts();
            loadHistory();

        } catch (Exception e) {
            UIUtils.error(this, e);
        }
    }

    private void handleViewDetail() {
        int row = historyTable.getSelectedRow();
        if (row < 0) {
            UIUtils.warning(this, "Vui lòng chọn một phiếu nhập từ bảng lịch sử để xem chi tiết.");
            return;
        }

        int receiptId = (int) historyModel.getValueAt(row, 0);
        if (cachedReceipts != null) {
            for (StockReceipt r : cachedReceipts) {
                if (r.getId() == receiptId) {
                    Window parent = SwingUtilities.getWindowAncestor(this);
                    new StockReceiptDetailDialog(parent, r).setVisible(true);
                    return;
                }
            }
        }
    }
}

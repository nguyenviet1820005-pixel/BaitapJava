package com.coffeeland.model;

/**
 * Model đại diện cho thông tin khách hàng và điểm tích lũy.
 */
public class Customer {
    private int id;
    private String code;
    private String fullName;
    private String phone;
    private String address;
    private int points;

    public Customer() {
        this.points = 0;
    }

    public Customer(int id, String code, String fullName, String phone, String address, int points) {
        this.id = id;
        this.code = code;
        this.fullName = fullName;
        this.phone = phone;
        this.address = address;
        this.points = points;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
    public String toString() {
        if (phone != null && !phone.isBlank()) {
            return fullName + " (" + phone + ") - " + points + " điểm";
        }
        return fullName + " - " + points + " điểm";
    }
}

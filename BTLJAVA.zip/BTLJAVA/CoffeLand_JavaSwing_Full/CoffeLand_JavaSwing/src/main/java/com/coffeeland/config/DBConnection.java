package com.coffeeland.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Lớp quản lý kết nối CSDL MySQL / MariaDB (Tối ưu hóa sẵn cho XAMPP).
 */
public final class DBConnection {

    // === CẤU HÌNH KẾT NỐI XAMPP MẶC ĐỊNH ===
    // XAMPP mặc định chạy MySQL tại localhost, cổng 3306, user "root", password rỗng ""
    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String DATABASE = "coffeeland";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Mặc định XAMPP để trống ""

    // Chuỗi kết nối JDBC hỗ trợ tiếng Việt UTF-8, múi giờ Việt Nam và tương thích MySQL / MariaDB của XAMPP
    private static final String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE
            + "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Ho_Chi_Minh&allowPublicKeyRetrieval=true&useSSL=false";

    private DBConnection() {
        // Private constructor để ngăn tạo instance
    }

    /**
     * Mở kết nối tới cơ sở dữ liệu MySQL trên XAMPP.
     * @return Connection đối tượng kết nối JDBC
     * @throws SQLException nếu XAMPP MySQL chưa bật hoặc chưa import database
     */
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ignored) {
        }

        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new SQLException(
                    "LỖI KẾT NỐI CƠ SỞ DỮ LIỆU XAMPP:\n" +
                    "1. Hãy mở 'XAMPP Control Panel' và nhấn [Start] ở mục 'MySQL'.\n" +
                    "2. Truy cập 'http://localhost/phpmyadmin' và kiểm tra đã import file 'database/coffeeland.sql' chưa.\n" +
                    "3. Chi tiết lỗi kỹ thuật: " + e.getMessage(), e
            );
        }
    }
}

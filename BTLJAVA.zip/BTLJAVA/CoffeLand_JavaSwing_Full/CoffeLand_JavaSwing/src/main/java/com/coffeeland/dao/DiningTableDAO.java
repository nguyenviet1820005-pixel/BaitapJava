package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.DiningTable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Bàn phục vụ & Sơ đồ bàn (Dining Tables).
 */
public class DiningTableDAO {

    private DiningTable mapResultSet(ResultSet rs) throws SQLException {
        DiningTable t = new DiningTable();
        t.setId(rs.getInt("id"));
        t.setCode(rs.getString("code"));
        t.setName(rs.getString("name"));
        t.setArea(rs.getString("area"));
        t.setStatus(rs.getString("status"));
        t.setActive(rs.getBoolean("active"));
        return t;
    }

    /**
     * Lấy toàn bộ danh sách bàn đang hoạt động theo khu vực.
     */
    public List<DiningTable> findAll(String area) throws SQLException {
        List<DiningTable> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM dining_tables WHERE active = 1 ");
        if (area != null && !area.trim().isEmpty() && !area.equalsIgnoreCase("Tất cả")) {
            sql.append("AND area = ? ");
        }
        sql.append("ORDER BY id ASC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            if (area != null && !area.trim().isEmpty() && !area.equalsIgnoreCase("Tất cả")) {
                ps.setString(1, area.trim());
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    public List<DiningTable> findAll() throws SQLException {
        return findAll(null);
    }

    /**
     * Cập nhật trạng thái bàn (EMPTY, OCCUPIED, RESERVED).
     */
    public void updateStatus(int tableId, String status) throws SQLException {
        String sql = "UPDATE dining_tables SET status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, tableId);
            ps.executeUpdate();
        }
    }

    /**
     * Thêm mới một bàn vào sơ đồ.
     */
    public void insert(DiningTable t) throws SQLException {
        String sql = "INSERT INTO dining_tables(code, name, area, status, active) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getCode().trim().toUpperCase());
            ps.setString(2, t.getName().trim());
            ps.setString(3, t.getArea().trim());
            ps.setString(4, t.getStatus());
            ps.setBoolean(5, t.isActive());
            ps.executeUpdate();
        }
    }

    /**
     * Cập nhật thông tin bàn.
     */
    public void update(DiningTable t) throws SQLException {
        String sql = "UPDATE dining_tables SET code = ?, name = ?, area = ?, status = ?, active = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getCode().trim().toUpperCase());
            ps.setString(2, t.getName().trim());
            ps.setString(3, t.getArea().trim());
            ps.setString(4, t.getStatus());
            ps.setBoolean(5, t.isActive());
            ps.setInt(6, t.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Xóa hoặc ẩn bàn khỏi sơ đồ.
     */
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM dining_tables WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

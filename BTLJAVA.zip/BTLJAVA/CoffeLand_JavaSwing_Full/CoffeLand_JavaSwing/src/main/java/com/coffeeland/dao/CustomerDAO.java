package com.coffeeland.dao;

import com.coffeeland.config.DBConnection;
import com.coffeeland.model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Xử lý truy vấn cơ sở dữ liệu cho Khách hàng (Customers).
 */
public class CustomerDAO {

    private Customer mapResultSet(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setId(rs.getInt("id"));
        c.setCode(rs.getString("code"));
        c.setFullName(rs.getString("full_name"));
        c.setPhone(rs.getString("phone"));
        c.setAddress(rs.getString("address"));
        c.setPoints(rs.getInt("points"));
        return c;
    }

    /**
     * Tìm kiếm khách hàng theo mã, họ tên hoặc số điện thoại.
     */
    public List<Customer> findAll(String keyword) throws SQLException {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers " +
                     "WHERE code LIKE ? OR full_name LIKE ? OR phone LIKE ? " +
                     "ORDER BY id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String k = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            ps.setString(1, k);
            ps.setString(2, k);
            ps.setString(3, k);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    /**
     * Lấy toàn bộ danh sách khách hàng.
     */
    public List<Customer> findAll() throws SQLException {
        return findAll("");
    }

    /**
     * Kiểm tra mã khách hàng đã tồn tại hay chưa.
     */
    public boolean isCodeExists(String code, int excludeId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM customers WHERE code = ? AND id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code.trim());
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Thêm mới một khách hàng.
     */
    public void insert(Customer c) throws SQLException {
        String sql = "INSERT INTO customers(code, full_name, phone, address, points) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getCode().trim().toUpperCase());
            ps.setString(2, c.getFullName().trim());
            ps.setString(3, c.getPhone() != null ? c.getPhone().trim() : "");
            ps.setString(4, c.getAddress() != null ? c.getAddress().trim() : "");
            ps.setInt(5, c.getPoints());
            ps.executeUpdate();
        }
    }

    /**
     * Cập nhật thông tin khách hàng.
     */
    public void update(Customer c) throws SQLException {
        String sql = "UPDATE customers SET code = ?, full_name = ?, phone = ?, address = ?, points = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getCode().trim().toUpperCase());
            ps.setString(2, c.getFullName().trim());
            ps.setString(3, c.getPhone() != null ? c.getPhone().trim() : "");
            ps.setString(4, c.getAddress() != null ? c.getAddress().trim() : "");
            ps.setInt(5, c.getPoints());
            ps.setInt(6, c.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Xóa khách hàng theo ID.
     */
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM customers WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

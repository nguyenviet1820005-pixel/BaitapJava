package com.coffeeland.model;

/**
 * Model đại diện cho thông tin sản phẩm / món đồ uống trong menu quán.
 */
public class Product {
    private int id;
    private String code;
    private String name;
    private int categoryId;
    private String categoryName;
    private String unit;
    private double price;
    private int stock;
    private boolean active;
    private String image;

    public Product() {
        this.unit = "Ly";
        this.active = true;
        this.image = "default_drink.png";
    }

    public Product(int id, String code, String name, int categoryId, String categoryName, String unit, double price, int stock, boolean active) {
        this(id, code, name, categoryId, categoryName, unit, price, stock, active, "default_drink.png");
    }

    public Product(int id, String code, String name, int categoryId, String categoryName, String unit, double price, int stock, boolean active, String image) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.unit = unit;
        this.price = price;
        this.stock = stock;
        this.active = active;
        this.image = (image != null && !image.trim().isEmpty()) ? image.trim() : "default_drink.png";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = (image != null && !image.trim().isEmpty()) ? image.trim() : "default_drink.png";
    }

    public String getImageOrDefault() {
        return (image != null && !image.trim()  .isEmpty()) ? image.trim() : "default_drink.png";
    }

    @Override
    public String toString() {
        return code + " - " + name + " (" + String.format("%,.0f", price) + " ₫ | Tồn: " + stock + ")";
    }
}
